// Iniciar na 468
let homologacaoRuim = location.href.includes('-web-hm') ? true : false

async function rotaAssinaTudo() {
    // quando a homologação está ruim, TRUE para poder usar em outra página.
    let janelaInicial = homologacaoRuim ? JANELA.painelGlobal : JANELA.gim
    // Se estiver na janela de assinar todos, para a função que assina
    let janelaCiclo = confereJanela(JANELA.gimAssinarTodos)
    if (janelaCiclo) {
        rotaCicloAssinatura()
        return
    }
    // Se estiver na janela de tarefa (assina), vai ver se é processo sinalizado
    let janelaSinalizados = confereJanela(JANELA.tarefaAssinar)
    if (janelaSinalizados){
        rota_assinarTudo_sinalizadoAberto()        
        return
    }
    // Se não for nenhum dos três retorna, caso contrário prossegue
    let janela = confereJanela(janelaInicial)
    if (!janela) return
    console.log('%c[Rota PJE]%c assina Janela: ' + JSON.stringify(4), LOG.info, 'color:inherit')
    // Insere botão ao lado dos botões que já existem
    let ancestral = homologacaoRuim ? 'pje-painel-global .cabecalho' : '.centralizado-botoes'
    let elemento = await aguardarElemento(ancestral)
    if (!elemento) return
    console.log('%c[Rota PJE]%c assina Elemento: ' + JSON.stringify(elemento), LOG.info, 'color:inherit', elemento)
    let idBotaoExibe = id('assinaTudo', 'botao', 'exibe')
    document.getElementById(idBotaoExibe)?.remove()
    let botaoExibe = criaBotaoLaranja({
        id: idBotaoExibe,
        ancestral: ancestral,
        texto: 'Exibir todos de todas as OJs',
        acao: () => assinaTudo()
    })
    botaoExibe.style.display = 'inline'
    botaoExibe.style.verticalAlign = 'middle'
    criaTooltip({
        id: idBotaoExibe + 'tooltip', 
        texto: 'Exibe todos os documentos disponíveis para assinatura em todas as OJs para leitura, seleção e assinatura.',
        elemento: idBotaoExibe
    })
    async function assinaTudo() {
        //assinaTudo - quando o botão é clicado, lê os perfis do usuário para fazer busca nas OJs.
        let sinalizados = [] // para reunir os sinalizados e apresentá-los depois.
        let orgaos = interceptador_ler('gim_orgaos_julgadores') || null
        if (!orgaos) orgaos = await rota_fetch(location.origin + '/pje-comum-api/api/gim/orgaosjulgadores')
        console.log('%c[Rota PJE]%c orgaos: ' + JSON.stringify(orgaos), LOG.info, 'color:inherit')
        if (!orgaos) {
            rota_avisoTemporario('Ocorreu um erro.', 'erro', 3000)
            console.log('%c[Rota PJE]%c interceptador: erro 29', LOG.info, 'color:inherit')
            return false
        }
        let data = Date.now()
        // se não consegue ler nas meta-tags, busca de novo no PJE.
        let perfis = await interceptador_lerPerfis() || []
        if (!perfis.length) {
            perfis = await rota_fetch(location.origin + '/pje-seguranca/api/token/perfis') || []
            if (!perfis.length) {
                rota_avisoTemporario('Ocorreu um erro.', 'erro', 3000)
                console.log('%c[Rota PJE]%c interceptador: erro 38', LOG.info, 'color:inherit')
                return false
            }
        }
        async function separaPerfisEAssina(orgaos, inclusoes = [], sinalizados = []){
            // vai pegar os perfis de acordo com os processos
            let idPerfis = []
            for (let orgao of orgaos){
                let idPerfil = perfis.find(d => d?.idOrgaoJulgador == orgao) || {}
                if (!idPerfil?.idPerfil) continue
                idPerfis.push(idPerfil)
            }
            if (!idPerfis.length) {
                rota_avisoTemporario('Nenhum perfil encontrado para as OJs selecionadas.', 'erro', 3000)
                return false
            }
            await armazenar({rotapje_assinaTudo:{idPerfis: idPerfis, execucao: data, perfilExecucao: idPerfis[0].idPerfil, inclusoes: inclusoes, sinalizados: sinalizados}})
            await rotaAssinaTudo_trocarPerfilENavegar(idPerfis[0], data)
            return true
        }
        // CRIA DIV CENTRALIZADA PARA MOSTRAR OS DESPACHOS
        let idDiv = id('assinaTudo', 'exibirTodos')
        document.getElementById(idDiv)?.remove()
        let div = criaDiv({
            id: idDiv,
            ancestral: 'ffff'
        })
        formataDiv(div)
        // CRIA CABEÇALHO COM TÍTULO E BOTÃO FECHAR
        let idCabecalho = id('assinaTudo', 'cabecalho')
        let cabecalho = criaDiv({
            id: idCabecalho,
            ancestral: idDiv,
            rowColumn: 'row-reverse'
        })
        let botaoFechar = criaBotaoAzul({
            id: id('assinaTudo', 'botao', 'fechar'),
            ancestral: idCabecalho,
            texto: '✕',
            acao: () => {
                document.getElementById(idDiv)?.remove()
                return
            }
        })
        botaoFechar.style.height =          '18px'
        botaoFechar.style.fontSize =        '13px'
        botaoFechar.style.lineHeight =      '1px'
        botaoFechar.style.padding =         '2px 5px'
        botaoFechar.style.borderRadius =    '4px'
        let titulo = criaTitulo({
            id: id('assinaTudo', 'titulo'),
            texto: 'Exibe todos os documentos para assinatura de todas as OJs',
            ancestral: idCabecalho
        })
        titulo.style.width = '100%'
        titulo.style.fontSize = '16px'
        let idSubCabecalho = id('assinaTudo', 'subCabecalho')
        let subCabecalho = criaDiv({
            id: idSubCabecalho,
            ancestral: idDiv,
            rowColumn: 'row-reverse'
        })
        // CRIA DIV ROLANTE PARA POSICIONAR OS DESPACHOS
        let idRolante = id('assinaTudo', 'rolante')
        let rolante = criaDiv({
            id: idRolante,
            ancestral: idDiv
        })
        rolante.style.overflowY = 'auto'
        rolante.style.height = '100%'
        let grade = criaGrade({
            id: idRolante + '_grade',
            ancestral: idRolante,
            numeroColunas: 1
        })
        
        // CRIA RODAPE PARA BOTÃO DE SELECIONAR TODOS E ASSINAR - ATENÇÃO: O RODAPÉ É ROW-REVERSE, ou seja, os elementos inseridos primeiro ficam à direita
        let idRodape = id('assinaTudo', 'rodape')
        let rodape = criaDiv({
            id: idRodape,
            ancestral: idDiv,
            rowColumn: 'row-reverse'
        })
        let idCheck = id('assinaTudo', 'check')
        let idCheckTodos = idCheck + '_selecionaTodos'
        let checkTodos = await criaCheckBox({
            id: idCheckTodos,
            ancestral: idSubCabecalho
        })
        criaTooltip({
            id: idCheckTodos + 'tooltip', 
            texto: 'Seleciona todos.', 
            elemento: idCheckTodos
        })
        if (document.getElementById(idCheckTodos).dataset.marcado == 0){
            console.log('%c[Rota PJE]%c 107' + JSON.stringify(107), LOG.aviso, 'color:inherit')
            clicar(checkTodos)
        }
        checkTodos.addEventListener('click', () => selecionaTodos(checkTodos, idCheck))
        let idSubSeleciona = id('assina', 'subSeleciona')
        let subSeleciona = criaSubTitulo({
            id: idSubSeleciona,
            texto: 'Seleciona todos',
            ancestral: idSubCabecalho
        })
        subSeleciona.style.fontSize = '16px'
        let idDivBotaoFuturo = id('assinaTudo', 'divBotaoFuturo')
        let divBotaoFuturo = criaDiv({
            id: idDivBotaoFuturo,
            ancestral: idRodape,
            rowColumn: 'row-reverse'
        })
        let idContador = id('assinaTudo', 'contador')
        let contador = criaTexto({
            id: idContador,
            texto: '',
            ancestral: idRodape
        })
        
        // fazendo a pesquisa pra trazer todos os que tem para assinatura
        let i = 0
        for (let orgao of orgaos){
            if (!div.isConnected) return // impede a execução se o usuário fechar
            i++
            atualizaContador(i, orgaos.length)
            let url = location.origin + '/pje-comum-api/api/gim/processos/todos?pagina=1&tamanhoPagina=100&ordenacaoCrescente=true&filtrarPorResponsavel=false&data=' + Math.floor(data/1000) + '&idOrgaoJulgador=' + orgao?.idOrgaoJulgador// + '&assinarTodos=true'
            let pesquisa = await rota_fetch(url) || {}
            if (pesquisa?.resultado) {
                await apresentaDespachos(pesquisa?.resultado, idRolante, idCheck, sinalizados, div)
            }
            if (pesquisa?.qtdPaginas > 1) {
                for (let j = 2; j <= pesquisa?.qtdPaginas; j++){
                    let url = location.origin + '/pje-comum-api/api/gim/processos/todos?pagina=' + j + '&tamanhoPagina=100&ordenacaoCrescente=true&filtrarPorResponsavel=false&data=' + Math.floor(data/1000) + '&idOrgaoJulgador=' + orgao?.idOrgaoJulgador// + '&assinarTodos=true'
                    let pesquisaNova = await rota_fetch(url) || {}
                    if (pesquisaNova?.resultado) await apresentaDespachos(pesquisaNova?.resultado, idRolante, idCheck, sinalizados, div)
                }
            }
            // variável que indica se o processo pode ser assinado em lote ou não: minutaPendenteAnalise
            // "temOcorrenciaImpedimento": true, - quando tem impedimento
            // https://pje-web-hm.trt15.jus.br/pje-comum-api/api/processos/id/2193070/documentos/id/305490464/conteudo?incluirAssinatura=false
        }
        if (!div.isConnected) return // impede a execução se o usuário fechar
        atualizaContador(i, orgaos.length, true)
        atualizaContadorDespachos()
        let temDocumentos = document.querySelectorAll(`[id^="${idCheck}_"][data-processo]`).length
        if (!temDocumentos && !sinalizados.length) {
            contador.textContent = 'Nenhum documento disponível para assinatura em lote.'
            return
        }
        let idAssinaSelecionadosESinalizados = id('assinaTudo', 'botao', 'assinaSelecionadosESinalizados')
        let assinaSelecionadosESinalizados = criaBotaoLaranja({
            id: idAssinaSelecionadosESinalizados,
            texto: 'Assinar Selecionados e Sinalizados',
            ancestral: idDivBotaoFuturo,
            acao: async () => {
                assinaSelecionadosESinalizados.disabled = true
                let iniciou = await assinaProcessosSelecionados(idCheck, sinalizados)
                if (!iniciou) assinaSelecionadosESinalizados.disabled = false
            }
        })
        criaTooltip({
            id: idAssinaSelecionadosESinalizados + 'tooltip',
            texto: 'Assina todos os documentos selecionados e sinalizados (aqueles que não podem ser assinados em lote serão mostrados um a um ao final).',
            elemento: idAssinaSelecionadosESinalizados
        })
        async function assinaProcessosSelecionados(elemento, sinalizados = []) {
            let checks = [...document.querySelectorAll(`[id^="${elemento}"]`)]
            let checksValidos = checks.filter(d =>
                !['caixa', '_selecionaTodos', 'tooltip'].some(c => d?.id.includes(c))
            )
            let inclusoes = checksValidos
                .filter(d => d.dataset?.marcado == 1)
                .map(c => ({ processo: c.dataset.processo, oj: String(c.dataset.oj), ojDescricao: c.dataset.ojDescricao || '' }))
            if (!inclusoes.length) {
                if (!sinalizados.length) {
                    rota_avisoTemporario('Nenhum documento selecionado.', 'aviso', 3000)
                    return false
                }
                await tratarSinalizados(sinalizados.map(s => s.processo))
                return true
            }
            let orgaos = [...new Set(inclusoes.map(d => d.oj))]
            return await separaPerfisEAssina(orgaos, inclusoes, sinalizados)
            
        }
        function selecionaTodos(elemento, seletor) {
            console.log('%c[Rota PJE]%c 137 seleciona todos: ' + JSON.stringify(137), LOG.teste, 'color:inherit')
            let dataset = elemento.dataset.marcado
            console.log('%c[Rota PJE]%c dataset: ' + JSON.stringify(dataset), LOG.teste, 'color:inherit')
            let checks = [...document.querySelectorAll('[id^="' + seletor + '"]')]
            for (let check of checks){
                if (['caixa', 'tooltip'].some(c => check.id.includes(c))) continue
                if (check.dataset.marcado !== dataset && check !== elemento){
                    clicar(check)
                }
            }
        }
        function atualizaContador(atual, total, final = false){
            let contador = document.getElementById(idContador)
            contador.textContent = final ? 'Busca finalizada: ' + atual + ' de ' + total + ' OJs.' : 'Buscando ' + atual + '/' + total + ' OJs'
        }
        function atualizaContadorDespachos(){
            let contadores = [...document.querySelectorAll('[id^="' + id('assinaTudo', 'contador', 'cabecalho') + '"]')].filter(d => d.id.match(/cabecalho_\d+/))
            console.log('%c[Rota PJE]%c contadores.length: ' + JSON.stringify(contadores.length), LOG.info, 'color:inherit')
            for (let i = 0; i < contadores.length; i++){
                contadores[i].textContent = (i + 1) + '/' + contadores.length
            }
        }
        
    }
}

//rotaAssinaTudo()



async function apresentaDespachos(dados, idRolante, idCheck, sinalizados, div){
    let bloqueados = await resolveBloqueados(dados)
    console.log('%c[Rota PJE]%c dados: ' + JSON.stringify(dados), LOG.teste, 'color:inherit', dados)
    async function resolveBloqueados(dados) {
        let nomeUsuario = document.querySelector('pje-cabecalho-perfil .nome-usuario')?.textContent || ''
        let usuario = normalizar(nomeUsuario)

        let bloqueados = []
        let impedimentos = dados.filter(d => d?.temOcorrenciaImpedimento && d?.tarefa?.includes('Assinar'))
        for (let imp of impedimentos) {
            let busca = await rota_fetch(location.origin + '/pje-comum-api/api/ocorrenciasimpedimentomagistrado/' + imp?.id)
            if (!Array.isArray(busca)) {           // falha de rede: trata como bloqueado, por segurança
                bloqueados.push(imp)
                continue
            }
            if (busca.some(d => d?.nomeMagistradoAfetado && usuario.includes(normalizar(d.nomeMagistradoAfetado)))) {
                bloqueados.push(imp)
            }
        }
        bloqueados.push(...dados.filter(d => d?.minutaPendenteAnalise && d?.tarefa?.includes('Assinar')))
        return bloqueados
    }
    let bloqueadosIds = new Set(bloqueados.map(d => d.id))

    let filtrados = dados.filter(d => d?.tarefa?.includes('Assinar') && !bloqueadosIds.has(d.id))

    let sinalizadosOJ = bloqueados
        .map(d => ({ processo: d.numeroProcesso, oj: String(d.idOrgaoJulgador), ojDescricao: d.descricaoOrgaoJulgador || '' }))
    sinalizados.push(...sinalizadosOJ)
    for (let processo of filtrados){
        console.log('%c[Rota PJE]%c processo: ' + JSON.stringify(processo), LOG.aviso, 'color:inherit')
        if (!div.isConnected) return // impede a execução se o usuário fechar
        if (!processo.id || !processo.idMinutaKz) continue
        let conteudo = ''
        try {
            conteudo = rota_normalizaHtml(await extrairHtml(processo.id, processo.idMinutaKz))
        } catch (e) {
            console.error('[Rota PJE] erro ao extrair html do documento ' + processo.idMinutaKz + ':', e)
            continue
        }
        if (!div.isConnected) return // impede a execução se o usuário fechar
        if (!conteudo) continue
        let idProcesso = processo?.id
        let idDivProcesso = id('assinaTudo', 'processo', idProcesso)
        let divProcesso = criaDiv({
            id: idDivProcesso,
            ancestral: idRolante + '_grade'
        })
        let idDivCabecalhoProcesso = id('assinaTudo', 'cabecalho', idProcesso)
        let cabecalhoProcesso = criaDiv({
            id: idDivCabecalhoProcesso,
            ancestral: idDivProcesso,
            rowColumn: 'row-reverse'
        })
        let idContadorCabecalho = id('assinaTudo', 'contador', 'cabecalho', idProcesso)
        let contadorCabecalho = criaSubTitulo({
            texto: '',
            id: idContadorCabecalho,
            ancestral: idDivCabecalhoProcesso
        })
        let idAbreDetalhesCabecalho = id('assinaTudo', 'abre_detalhes', idProcesso)
        let botaoAbreDetalhesCabecalho = criaBotaoLaranja({
            id: idAbreDetalhesCabecalho,
            texto: 'Abre os detalhes do processo',
            ancestral: idDivCabecalhoProcesso,
            acao: () => {
                let url = location.origin + '/pjekz/processo/' + idProcesso + '/detalhe'
                window.open(url, '_blank')
            }
        })
        let idTituloProcessoCabecalho = id('assinaTudo', 'titulo_cabecalho', idProcesso)
        let tituloProcessoCabecalho = criaSubTitulo({
            texto: processo?.numeroProcesso,
            id: idTituloProcessoCabecalho,
            ancestral: idDivCabecalhoProcesso
        })
        formataDiv(divProcesso, 'fundo', 'auto', 'auto', 'relative')
        
        //conteudo.querySelector('img')?.remove()
        let idDivConteudo = id('assinaTudo', 'conteudo', idProcesso)
        let divConteudo = criaDiv({
            id: idDivConteudo,
            ancestral: idDivProcesso
        })
        divConteudo.innerHTML = conteudo
        let idDivRodapeProcesso = id('assinaTudo', 'rodape', idProcesso)
        let rodapeProcesso = criaDiv({
            id: idDivRodapeProcesso,
            ancestral: idDivProcesso,
            rowColumn: 'row-reverse'
        })
        let idCheckBoxProcesso = idCheck + '_' + idProcesso
        let checkBoxProcesso = await criaCheckBox({
            id: idCheckBoxProcesso,
            ancestral: idDivRodapeProcesso
        })
        checkBoxProcesso.dataset.processo = processo?.numeroProcesso || ''
        checkBoxProcesso.dataset.oj = processo?.idOrgaoJulgador || ''
        checkBoxProcesso.dataset.ojDescricao = processo?.descricaoOrgaoJulgador || ''
        clicar(checkBoxProcesso)
        let idAbreDetalhesRodape = id('assinaTudo', 'abre_detalhes_rodape', idProcesso)
        let botaoAbreDetalhesRodape = criaBotaoLaranja({
            id: idAbreDetalhesRodape,
            texto: 'Abre os detalhes do processo',
            ancestral: idDivRodapeProcesso,
            acao: () => {
                let url = location.origin + '/pjekz/processo/' + idProcesso + '/detalhe'
                window.open(url, '_blank')
            }
        })
        let idTituloProcesso = id('assinaTudo', 'titulo', idProcesso)
        let tituloProcesso = criaSubTitulo({
            texto: processo?.numeroProcesso,
            id: idTituloProcesso,
            ancestral: idDivRodapeProcesso
        })
        //cabecalhoProcesso.style.gap = '50px'
        contadorCabecalho.style.width      = '50px'
        contadorCabecalho.style.fontSize   = '16px'
        contadorCabecalho.style.margin   = '0px'
        botaoAbreDetalhesCabecalho.style.width = '250px'
        tituloProcessoCabecalho.style.width      = '100%'
        tituloProcessoCabecalho.style.fontSize   = '16px'
        //rodapeProcesso.style.gap = '50px'
        checkBoxProcesso.style.width = '50px'
        botaoAbreDetalhesRodape.style.width = '250px'
        tituloProcesso.style.width      = '100%'
        tituloProcesso.style.fontSize   = '16px'

    }
}

async function rotaAssinaTudo_trocarPerfilENavegar(perfil, data){
    // altera o setor e navega pra OJ correspondente, na página de assinatura
    if (!perfil) return
    await rota_fetchPost(location.origin + '/pje-seguranca/api/token/perfis/trocar', JSON.stringify({ id_perfil: perfil.idPerfil }))
    let url = location.origin + '/pjekz/painel/gim/todos/oj/' + perfil.idOrgaoJulgador + '/lista-processos?assinarTodos=true'
    window.name = 'rotapje_assinaTudo_' + data
    location.href = url
}

async function rotaCicloAssinatura(){
    let janelaCiclo = confereJanela(JANELA.gimAssinarTodos)
    if (!janelaCiclo) return
    let nomeJanela = window.name
    if (!nomeJanela.includes('rotapje_assinaTudo')) return
    let execucao = await obterArmazenamento('rotapje_assinaTudo')
    let timeStamp = execucao?.rotapje_assinaTudo?.execucao
    if(!nomeJanela.includes(timeStamp)) return


    async function assinarTudo(tentativa = 1) {

        await aguardarElemento('table.t-class tbody')
        await suspender(500 * tentativa)   // 500ms, 1s, 1,5s, 2s, 2,5s 

        let perfilAtual = execucao.rotapje_assinaTudo.idPerfis
            .find(p => p.idPerfil === execucao.rotapje_assinaTudo.perfilExecucao)
        let ojAtual = String(perfilAtual?.idOrgaoJulgador)
        let inclusoes = (execucao?.rotapje_assinaTudo?.inclusoes || [])
            .filter(d => d.oj === ojAtual)
            .map(d => d.processo)
        await aguardarElemento('pje-paginador .total-registros')
        await suspender(1000)
        let linhasPorPagina = [...document.querySelectorAll('pje-paginador .mat-table-pagination .mat-select')][1]
        if (!linhasPorPagina) return reciclar(tentativa, 'paginador ausente')
        let quantidade = document.querySelector('pje-paginador .total-registros').textContent.split('de').pop().trim()
        let menor = quantidade > 100 ? 100 : quantidade
        if (Number(menor) > Number(linhasPorPagina.textContent)){
            clicar(linhasPorPagina)
            await aguardarElemento('mat-option')
            await suspender(1000)
            let opcao = [...document.querySelectorAll('mat-option')].find(d => d.textContent.includes('100'))
            if (!opcao) return reciclar(tentativa, 'opção 100 ausente')
            let meta = aguardarMetaAtualizar('agrupamento_tarefas_processos', 30000)
            clicar(opcao)
            await meta
            await suspender(1000)
        }
        let tabela = selecionar('table.t-class')
        let tabelaCorpo = tabela?.querySelector('tbody')
        if (!tabelaCorpo) return reciclar(tentativa, 'tbody ausente')
        let sinalizados = execucao.rotapje_assinaTudo.sinalizados ??= []
        //let sinalizados = execucao?.rotapje_assinaTudo?.sinalizados || [];
        let todasLinhas = [...tabelaCorpo.querySelectorAll('tr')];
        let vazio = todasLinhas.find(d => d.textContent.includes('Não há processos'))
        if (vazio) {
            defineCiclo(execucao?.rotapje_assinaTudo)
            return
        }
        if (todasLinhas.length !== Number(menor)) return reciclar(tentativa, 'não carregou todas as linhas')
        let linhasAssinaveis = [];
        
        for (let d of todasLinhas) {
            let numero = d.textContent.match(ROTA_REGEX_CNJ)?.[0];
            let botaoHabilitado = !d.querySelector('button.botao-icone-tabela-assinar.mat-button-disabled');
            
            if (botaoHabilitado) {
                linhasAssinaveis.push(d);
            } else if (numero && !sinalizados.some(s => s.processo === numero)) {
                sinalizados.push({ processo: numero, oj: ojAtual })
            }
        }
        
        if (!linhasAssinaveis.length) {
            defineCiclo(execucao?.rotapje_assinaTudo)
            return
        }
        for (let linha of linhasAssinaveis) {
            if (!linha.isConnected) return reciclar(tentativa, 'linha órfã')
            let numero = linha.textContent.match(ROTA_REGEX_CNJ)?.[0]
            let caixa = linha.querySelector('input.mat-checkbox-input')
            let deveMarcar = !!numero && inclusoes.includes(numero)
            if (!!caixa?.checked !== deveMarcar) {
                linha.querySelector('.mat-checkbox-inner-container')?.click()
                await suspender(200)
            }
        }
        let marcadas = linhasAssinaveis.filter(l => l.querySelector('input.mat-checkbox-input')?.checked).length
        if (!marcadas) { 
            defineCiclo(execucao?.rotapje_assinaTudo)
            return 
        }
        await armazenar({rotapje_assinaTudo: execucao?.rotapje_assinaTudo})
        let divergentes = linhasAssinaveis.filter(l => {
            let numero = l.textContent.match(ROTA_REGEX_CNJ)?.[0]
            let marcada = !!l.querySelector('input.mat-checkbox-input')?.checked
            return marcada !== (!!numero && inclusoes.includes(numero))
        })
        if (divergentes.length) return reciclar(tentativa, 'marcação divergente da lista')
        let marcadasTotal = tabelaCorpo.querySelectorAll('input.mat-checkbox-input:checked').length
        if (marcadasTotal !== marcadas) return reciclar(tentativa, 'caixa marcada fora da lista')
        let assinaveis = linhasAssinaveis
            .filter(l => l.querySelector('input.mat-checkbox-input')?.checked)
            .map(l => l.textContent.match(ROTA_REGEX_CNJ)?.[0])
            .filter(Boolean)
        await clicar(tabela.querySelector('thead button.botao-icone-tabela-assinar'))
        let dialogo = await aguardarElemento('mat-dialog-container .mat-dialog-content')
        if (dialogo && !dialogo.closest('pje-resposta-assinatura')) {
            let r = execucao.rotapje_assinaTudo
            r.recargasAviso = (r.perfilRecargaAviso === r.perfilExecucao) ? (r.recargasAviso || 0) + 1 : 1
            r.perfilRecargaAviso = r.perfilExecucao
            await armazenar({rotapje_assinaTudo: r})
            console.log('%c[Rota PJE]%c diálogo inesperado:', LOG.aviso, 'color:inherit', dialogo.textContent.trim())
            if (r.recargasAviso <= 3 && !homologacaoRuim) { location.reload(); return }
            defineCiclo(r)
            return
        }
        await suspender(2000)
        if (document.querySelector('mat-dialog-container [aria-label="Fechar"]')) clicar(document.querySelector('mat-dialog-container [aria-label="Fechar"]'))
        let tabelaResultados = execucao.rotapje_assinaTudo.tabelaResultados ??= []
        let assinadoTipo = dialogo?.textContent?.includes('realizadas com sucesso') ? 'SUCESSO' : 'ERRO'
        let resultadoParcial = assinaveis.map(d => {
            let dados = execucao?.rotapje_assinaTudo?.inclusoes.find(c => c.processo == d)
            return {processo: d, oj: dados?.oj || ojAtual, confirmacao: assinadoTipo}
        })
        tabelaResultados.push(...resultadoParcial)
        await armazenar({rotapje_assinaTudo: execucao.rotapje_assinaTudo})
        if (Number(quantidade) > 100) {
            let r = execucao.rotapje_assinaTudo
            r.recargas = (r.perfilRecarga === r.perfilExecucao) ? (r.recargas || 0) + 1 : 1
            r.perfilRecarga = r.perfilExecucao
            await armazenar({rotapje_assinaTudo: r})
            if (r.recargas <= 3) { location.reload(); return }
        }
        defineCiclo(execucao?.rotapje_assinaTudo)
    }

    async function reciclar(tentativa, motivo) {
        if (tentativa >= 5) {
            console.log('%c[Rota PJE]%c desistiu após 5 tentativas:', LOG.info, 'color:inherit', motivo)
            await armazenar({rotapje_assinaTudo: execucao?.rotapje_assinaTudo})
            defineCiclo(execucao?.rotapje_assinaTudo)   // aí sim segue pra próxima OJ
            return
        }
        console.log('%c[Rota PJE]%c retentando:', LOG.info, 'color:inherit', motivo, tentativa + 1)
        return assinarTudo(tentativa + 1)
    }

    await assinarTudo()
    //alert (JSON.stringify(linhasAssinaveis))
    
    async function defineCiclo(execucao) {
        let index = execucao?.idPerfis.findIndex(d => d?.idPerfil === execucao?.perfilExecucao)
        if (index === -1) return
        if (index === execucao?.idPerfis?.length - 1) {
            window.name = ''
            let descricoes = {}
            for (let d of [...(execucao?.inclusoes || []), ...(execucao?.sinalizados || [])]) {
                if (d.ojDescricao) descricoes[d.oj] = d.ojDescricao
            }
            let relatorio = {}
            for (let i of execucao?.inclusoes || [])
                relatorio[i.processo] = { processo: i.processo, oj: i.oj, confirmacao: 'NÃO ASSINADO' }
            for (let s of execucao?.sinalizados || [])
                relatorio[s.processo] = { processo: s.processo, oj: s.oj, confirmacao: 'SINALIZADO' }
            for (let r of execucao?.tabelaResultados || [])
                relatorio[r.processo] = r   // o último registro prevalece
            let linhasRelatorio = Object.values(relatorio)
                .map(r => ({ ...r, oj: descricoes[r.oj] || r.oj }))
            let resultadoBaixar = []
            for (let l = 0; l < linhasRelatorio.length; l++) {
                if (l === 0){
                    resultadoBaixar.push('OJ\tPROCESSO\tCONFIRMAÇÃO')
                }
                resultadoBaixar.push([linhasRelatorio[l].oj, linhasRelatorio[l].processo, linhasRelatorio[l].confirmacao].join('\t'))
            }
            _baixarArquivo(resultadoBaixar.join('\n'), `assinados${Date.now()}.txt`, 'text/plain')
            await tratarSinalizados((execucao?.sinalizados || []).map(s => s.processo))
            await removerArmazenamento('rotapje_assinaTudo')
            return
        }
        execucao.perfilExecucao = execucao?.idPerfis[index + 1].idPerfil
        await armazenar({rotapje_assinaTudo : execucao})
        await rotaAssinaTudo_trocarPerfilENavegar(execucao.idPerfis[index + 1], execucao.execucao)
        
        
    }

}
let CHAVE_SINALIZADOS = 'rotapje_assinaTudo_tratarSinalizados'

async function tratarSinalizados(sinalizados = [], data = Date.now()) {
    let fila = [...new Set(sinalizados)]
    if (!fila.length) return
    await armazenar({[CHAVE_SINALIZADOS]: {sinalizados: fila, execucao: data}})
    await tratarSinalizadosAbrir(false)
}

// mesmaAba = false → primeira abertura (aba nova, via segundo plano)
// mesmaAba = true  → botão "Próximo" (navega na aba atual)
async function tratarSinalizadosAbrir(mesmaAba) {
    let execucao = (await obterArmazenamento(CHAVE_SINALIZADOS))?.[CHAVE_SINALIZADOS]
    let fila = execucao?.sinalizados || []
    while (fila.length) {
        let processo = fila[0]
        let dados = await buscarIdPeloNumeroCNJ(processo) || {}
        let idTarefa = dados?.id ? (await rota_buscarTarefa(dados.id) || '') : ''
        if (dados?.id && idTarefa) {
            await armazenar({[CHAVE_SINALIZADOS]: {...execucao, sinalizados: fila}})
            let trocou = await sinalizadosTrocarPerfil(dados.idOrgaoJulgador)
            if (trocou) {
                let url = location.origin + '/pjekz/processo/' + dados.id + '/tarefa/' + idTarefa
                        + '?rotapje_sinalizado=' + execucao.execucao
                if (mesmaAba) location.href = url
                else abrirURL({url/*, tipo: 'aba'*/})
                return
            }
        }
        console.log('%c[Rota PJE]%c sinalizado não localizado, pulando:', LOG.aviso, 'color:inherit', processo)
        fila.shift()
    }
    await removerArmazenamento(CHAVE_SINALIZADOS)
    rota_avisoTemporario('Não há mais sinalizados.', 'info', 3000)
    if (mesmaAba) {
        window.name = ''
        await suspender(3000)   // tempo para o usuário ver o aviso
        NAVEGADOR.runtime.sendMessage({ acao: 'FecharEstaAba' })
    }
}

async function sinalizadosTrocarPerfil(oj) {
    let perfis = await interceptador_lerPerfis() || []
    if (!perfis.length) perfis = await rota_fetch(location.origin + '/pje-seguranca/api/token/perfis') || []
    let perfil = perfis.find(d => String(d?.idOrgaoJulgador) === String(oj))
    if (!perfil) return false
    await rota_fetchPost(location.origin + '/pje-seguranca/api/token/perfis/trocar', JSON.stringify({ id_perfil: perfil.idPerfil }))
    return true
}

async function rota_assinarTudo_sinalizadoAberto() {
    let paramURL = new URLSearchParams(location.search).get('rotapje_sinalizado') // antes de qualquer await
    let execucao = (await obterArmazenamento(CHAVE_SINALIZADOS))?.[CHAVE_SINALIZADOS]
    if (!execucao?.execucao) return
    let marca = CHAVE_SINALIZADOS + execucao.execucao
    if (!window.name.includes(marca)) {
        if (paramURL !== String(execucao.execucao)) return
        window.name = marca
    }
    await aguardarElemento('mat-tab-header .mat-tab-label')
    await suspender(3000)
    let comentarios = [...document.querySelectorAll('mat-tab-header .mat-tab-label')]
        .find(d => d.textContent.includes('Comentários'))
    if (comentarios) clicar(comentarios)
    rota_tratarSinalizados_criarWidgetProximo(execucao)
}

function rota_tratarSinalizados_criarWidgetProximo(execucao) {
    let idWidget = id('tratarSinalizados', 'widget')
    document.getElementById(idWidget)?.remove()
    let restantes = (execucao.sinalizados?.length || 1) - 1
    _rota_criarWidgetFlutuante({
        id: idWidget,
        titulo: 'Sinalizados',
        largura: '280px'
    })
    let botao = criaBotaoLaranja({
        id: idWidget + '_proximo',
        ancestral: idWidget,   // confira se o conteúdo do widget vai no próprio id ou num filho
        texto: restantes ? '▶ Próximo sinalizado (' + restantes + ' restantes)' : '✔ Encerrar sinalizados',
        acao: async () => {
            botao.disabled = true
            try {
                let atual = (await obterArmazenamento(CHAVE_SINALIZADOS))?.[CHAVE_SINALIZADOS]
                if (!atual) return
                atual.sinalizados.shift()
                await armazenar({[CHAVE_SINALIZADOS]: atual})
                await tratarSinalizadosAbrir(true)
            } catch (e) {
                console.error('[Rota PJE] próximo sinalizado:', e)
                rota_avisoTemporario('Erro ao abrir o próximo sinalizado.', 'erro', 3000)
                botao.disabled = false
            }
        }
    })
    botao.style.width = '100%'
}
