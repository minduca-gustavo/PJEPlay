// criarCaixaDeAviso

// ============================================================
// ui.js
// Biblioteca de componentes visuais do assistente Rota PJE.
//
// Paleta:
//   azul    #0078aa      laranja  #ffa726
//   fundo   #f9f9fa      borda    #dcdcdc
//   texto   #2c3e50      suave    #6b7c93
//
// Convenção:
//   - Todos os componentes recebem um objeto de configuração.
//   - 'ancestral' é sempre o id (string) do elemento pai.
//   - O elemento criado é inserido no ancestral automaticamente.
//   - Todos os componentes retornam o elemento raiz criado.
//   - Ids são obrigatórios para que o roteiro possa acessar
//     os valores por document.getElementById(id).
// ============================================================


// ── Utilitários internos ──────────────────────────────────────

/**
 * Paleta lida de estilos/rotapje-cores.css.
 *
 * As cores saíram do JS: a única fonte de verdade agora é a folha
 * de estilo, no mesmo modelo do SISE (tripla HSL em custom
 * property). Trocar a identidade visual do Rota é editar um
 * arquivo CSS, não caçar hex espalhado por 2 mil linhas.
 *
 * A leitura é feita uma vez, sob demanda, e memorizada — os
 * componentes continuam aplicando estilo inline como antes, então
 * nada mais neste arquivo precisou mudar.
 */
let _ui_paletaCache = null

function rota_ui_lerPaleta(){

	if(_ui_paletaCache) return _ui_paletaCache

	let raiz = getComputedStyle(document.documentElement)

	function cor(nome, reserva){
		let tripla = raiz.getPropertyValue('--extensao-rotapje-cor-' + nome).trim()
		if(!tripla) return reserva
		return 'hsl(' + tripla + ')'
	}

	_ui_paletaCache = {
		azul:         cor('azul',          '#0078aa'),
		azulHover:    cor('azul-hover',    '#005f8a'),
		azulClaro:    cor('azul-claro',    '#2a5a8c'),
		laranja:      cor('laranja',       '#ffa726'),
		laranjaHover: cor('laranja-hover', '#e6941f'),
		fundo:        cor('fundo',         '#f9f9fa'),
		borda:        cor('borda',         '#dcdcdc'),
		texto:        cor('texto',         '#2c3e50'),
		suave:        cor('texto-suave',   '#6b7c93'),
		cinza:        cor('cinza',         '#dddddd'),
		branco:       cor('branco',        '#ffffff'),
		erro:         cor('perigo',        '#c62828'),
		sucesso:      cor('sucesso',       '#2e7d32'),
	}

	return _ui_paletaCache

}

/**
 * Proxy de leitura: UI_CORES.azul continua funcionando em todos os
 * pontos de uso existentes, mas resolve para o valor do CSS.
 */
const UI_CORES = new Proxy({}, {
	get: (_, chave) => rota_ui_lerPaleta()[chave],
	has: (_, chave) => chave in rota_ui_lerPaleta(),
	ownKeys: () => Reflect.ownKeys(rota_ui_lerPaleta()),
	getOwnPropertyDescriptor: () => ({ enumerable:true, configurable:true }),
})

function rota_ui_fonte(){
	return getComputedStyle(document.documentElement)
		.getPropertyValue('--extensao-rotapje-fonte').trim()
		|| "'Segoe UI', system-ui, sans-serif"
}


function _ui_el(tag, estilos = {}) {
    const el = document.createElement(tag)
    Object.assign(el.style, estilos)
    return el
}

// Insere 'el' dentro do elemento com id 'ancestral'.
// Se 'ancestral' não for encontrado, insere no body com aviso.
function _ui_inserir(el, ancestral) {
    // Aceita id simples ('minha-div') ou seletor CSS ('[class*="pje"]')
    if (ancestral === document.body){
        document.body.appendChild(el)
        return
    }
    const pai = ancestral.match(/^[a-zA-Z0-9_-]+$/)
        ? document.getElementById(ancestral)
        : document.querySelector(ancestral)
    if (!pai) {
        console.warn('[ui.js] ancestral não encontrado:', ancestral)
        document.body.appendChild(el)
        return
    }
    pai.appendChild(el)
}

// Estilo base de botão — compartilhado por variantes
function _ui_estiloBotao(cor, corHover, corTexto = '#ffffff') {
    return {
        display:      'block',
        width:        '100% - 6px',
        background:   cor,
        color:        corTexto,
        border:       'none',
        borderRadius: '6px',
        padding:      '8px 12px',
        marginLeft:   '3px',
        marginRight:  '3px',
        fontSize:     '12px',
        fontWeight:   '700',
        fontFamily:   rota_ui_fonte(),
        cursor:       'pointer',
        textAlign:    'center',
        transition:   'background 0.15s',
        boxSizing:    'border-box',
    }
}

function _ui_hoverBotao(btn, cor, corHover) {
    btn.addEventListener('mouseenter', () => btn.style.background = corHover)
    btn.addEventListener('mouseleave', () => btn.style.background = cor)
}


// ── criaDiv ───────────────────────────────────────────────────
//
// Cria uma div genérica com id. Usada como container para
// agrupar outros componentes.
//
// criaDiv({ id, ancestral })

function criaDiv({ id, ancestral , rowColumn = 'column'}) {
    const el = _ui_el('div', {
        display:       'flex',
        flexDirection: rowColumn,
        gap:           '6px',
        marginBottom:  '8px',
    })
    el.id = id
    _ui_inserir(el, ancestral)
    return el
}


// ── criaDivFlutuante ──────────────────────────────────────────
//
// Container flutuante arrastável. O usuário pode mover pela
// barra de título. A posição é salva via armazenar/obterArmazenamento.
//
// O roteiro insere outros componentes usando o id como ancestral.
//
// criaDivFlutuante({ id, titulo, largura, ancestral })
//   largura: opcional, padrão '280px'
//   ancestral: opcional — se omitido, insere em document.body

async function criaDivFlutuante({ id, titulo = '', largura = '280px', ancestral, armazenarRecolhido = false }) {

    // ── posição inicial ───────────────────────────────────────
    const CHAVE   = 'ui_flutuante_pos_' + id
    const POS_PAD = 16
    let posicao   = { top: POS_PAD, left: POS_PAD }

    // ── clamp reutilizável (carregamento + resize) ─────────────
    function _clampPosicaoWidget(pos) {
        const larguraPx = parseInt(largura) || 280
        const alturaBarraPx = 34 // altura aproximada da barra de título (sempre precisa ficar visível)
        const margemMinimaVisivel = 40 // pelo menos essa fatia do widget precisa continuar na tela

        const maxTop  = Math.max(0, window.innerHeight - alturaBarraPx)
        const maxLeft = Math.max(0, window.innerWidth  - margemMinimaVisivel)
        const minLeft = -(larguraPx - margemMinimaVisivel) // permite sair parcialmente pra esquerda, mas não sumir

        const clamped = {
            top:  Math.min(Math.max(0, pos.top), maxTop),
            left: Math.min(Math.max(minLeft, pos.left), maxLeft),
        }

        // guarda extra contra valores corrompidos (NaN, Infinity etc.)
        if (!Number.isFinite(clamped.top))  clamped.top  = POS_PAD
        if (!Number.isFinite(clamped.left)) clamped.left = POS_PAD

        return clamped
    }

    const salvo = await obterArmazenamento([CHAVE])
    if (salvo && salvo[CHAVE] && typeof salvo[CHAVE].top === 'number' && typeof salvo[CHAVE].left === 'number') {
        posicao = _clampPosicaoWidget(salvo[CHAVE])
    }

    // ── wrapper (position:fixed) ──────────────────────────────
    const wrapper = _ui_el('div', {
        position:      'fixed',
        top:           posicao.top  + 'px',
        left:          posicao.left + 'px',
        width:         largura,
        background:    UI_CORES.branco,
        border:        '1px solid ' + UI_CORES.borda,
        borderRadius:  '8px',
        boxShadow:     '0 4px 16px rgba(0,0,0,0.15)',
        zIndex:        String(ROTA_Z.flutuante ?? 9000),
        display:       'flex',
        flexDirection: 'column',
        fontFamily:    "var(--extensao-rotapje-fonte)",
        userSelect:    'none',
        minWidth:      '180px',
        overflow:      'visible',  // não corta os filhos — o scroll fica no corpo
    })
    wrapper.id = id

    // ── barra de título (handle de arrasto) ───────────────────
    const barra = _ui_el('div', {
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'space-between',
        background:     UI_CORES.azul,
        color:          UI_CORES.branco,
        borderRadius:   '7px 7px 0 0',
        padding:        '6px 10px',
        cursor:         'grab',
        fontSize:       '12px',
        fontWeight:     '700',
        flexShrink:     '0',
    })

    const barraTexto = _ui_el('span', {})
    barraTexto.textContent = titulo

    // ── botões (recolher / fechar) ─────────────────────────────
    const barraBotoes = _ui_el('div', {
        display:    'flex',
        alignItems: 'center',
        gap:        '2px',
        flexShrink: '0',
    })

    function _criaBotaoBarra(texto, tituloBotao) {
        const botao = _ui_el('button', {
            background:   'transparent',
            border:       'none',
            color:        UI_CORES.branco,
            cursor:       'pointer',
            fontSize:     '13px',
            lineHeight:   '1',
            padding:      '2px 5px',
            borderRadius: '4px',
        })
        botao.type = 'button'
        botao.textContent = texto
        botao.title = tituloBotao
        botao.addEventListener('mouseenter', () => {
            botao.style.background = 'rgba(255,255,255,0.2)'
        })
        botao.addEventListener('mouseleave', () => {
            botao.style.background = 'transparent'
        })
        return botao
    }
    let recolhido = false
    if (armazenarRecolhido){
        let label = id + 'estado'
        let armazenamento = await obterArmazenamento([label])
        if (armazenamento) recolhido = armazenamento[label]
        console.log('%c[Rota PJE]%c recolhido 230: ' + JSON.stringify(recolhido), LOG.rosa, 'color:inherit')
    }
    let textoBotao = recolhido ? '▢' : '─'
    const botaoRecolher = _criaBotaoBarra(textoBotao, 'Recolher')
    const botaoFechar   = _criaBotaoBarra('✕', 'Fechar')

    barraBotoes.appendChild(botaoRecolher)
    barraBotoes.appendChild(botaoFechar)

    barra.appendChild(barraTexto)
    barra.appendChild(barraBotoes)
    wrapper.appendChild(barra)

    // ── corpo (ancestral dos componentes filhos) ──────────────
    const corpo = _ui_el('div', {
        display:       'flex',
        flexDirection: 'column',
        gap:           '6px',
        padding:       '8px 0 6px 0',
        overflowY:     'auto',
        maxHeight:     '80vh',
        borderRadius:  '0 0 8px 8px',  // cantos de baixo — compensa overflow:visible no wrapper
    })
    corpo.id = id + '-corpo'
    corpo.classList.add('ui-clip-liberavel')
    wrapper.appendChild(corpo)

    // ── recolher / expandir ─────────────────────────────────────

    corpo.style.display    = recolhido ? 'none' : 'flex'

    botaoRecolher.addEventListener('click', (e) => {
        e.stopPropagation()
        recolhido = !recolhido
        if (armazenarRecolhido){
            let label = id + 'estado'
            armazenar({[label]: recolhido})
            console.log('%c[Rota PJE]%c recolhido 239: ' + JSON.stringify(recolhido), LOG.rosa, 'color:inherit')
            console.log('%c[Rota PJE]%c recolhido 230: ' + JSON.stringify(label), LOG.rosa, 'color:inherit')
        }
        corpo.style.display    = recolhido ? 'none' : 'flex'
        botaoRecolher.textContent = recolhido ? '▢' : '─'
        botaoRecolher.title       = recolhido ? 'Expandir' : 'Recolher'
    })

    // ── fechar ───────────────────────────────────────────────────
    botaoFechar.addEventListener('click', (e) => {
        e.stopPropagation()
        wrapper.remove()
    })

    // ── arrasto ───────────────────────────────────────────────
    let arrastando = false
    let origemX, origemY, inicioTop, inicioLeft

    barra.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) return
        arrastando = true
        origemX    = e.clientX
        origemY    = e.clientY
        inicioTop  = parseInt(wrapper.style.top)  || 0
        inicioLeft = parseInt(wrapper.style.left) || 0
        barra.style.cursor = 'grabbing'
        e.preventDefault()
    })

    document.addEventListener('mousemove', (e) => {
        if (!arrastando) return
        const novoTop  = inicioTop  + (e.clientY - origemY)
        const novoLeft = inicioLeft + (e.clientX - origemX)
        wrapper.style.top  = novoTop  + 'px'
        wrapper.style.left = novoLeft + 'px'
    })

    document.addEventListener('mouseup', async () => {
        if (!arrastando) return
        arrastando         = false
        barra.style.cursor = 'grab'
        const top  = parseInt(wrapper.style.top)
        const left = parseInt(wrapper.style.left)
        await armazenar({[CHAVE]:{top: top, left: left}})
    })

    // ── inserção ──────────────────────────────────────────────
    if (ancestral) {
        _ui_inserir(wrapper, ancestral)
    } else {
        document.body.appendChild(wrapper)
    }

    // ── re-clamp em resize da janela ────────────────────────────
    window.addEventListener('resize', () => {
        const topAtual  = parseInt(wrapper.style.top)  || 0
        const leftAtual = parseInt(wrapper.style.left) || 0

        const novaPosicao = _clampPosicaoWidget({ top: topAtual, left: leftAtual })

        if (novaPosicao.top !== topAtual || novaPosicao.left !== leftAtual) {
            wrapper.style.top  = novaPosicao.top  + 'px'
            wrapper.style.left = novaPosicao.left + 'px'
            armazenar({ [CHAVE]: novaPosicao })
        }
    })
    wrapper.corpo = corpo
    return wrapper
}

// ── criaTitulo ────────────────────────────────────────────────
//
// Texto de título (h2 visual). Linha azul à esquerda.
//
// criaTitulo({ id, texto, ancestral })

function criaTitulo({ id, texto, ancestral }) {
    const el = _ui_el('div', {
        fontSize:    '13px',
        fontWeight:  '700',
        color:       UI_CORES.azul,
        borderLeft:  '3px solid ' + UI_CORES.azul,
        paddingLeft: '8px',
        marginBottom:'4px',
        fontFamily:  "var(--extensao-rotapje-fonte)",
    })
    el.id          = id
    el.textContent = texto
    _ui_inserir(el, ancestral)
    return el
}


// ── criaSubTitulo ─────────────────────────────────────────────
//
// Texto de subtítulo menor, cor suave.
//
// criaSubTitulo({ id, texto, ancestral })

function criaSubTitulo({ id, texto, ancestral }) {
    const el = _ui_el('div', {
        fontSize:   '11px',
        fontWeight: '600',
        color:      UI_CORES.suave,
        marginBottom:'2px',
        marginLeft: '8px',
        fontFamily: "var(--extensao-rotapje-fonte)",
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
    })
    el.id          = id
    el.textContent = texto
    _ui_inserir(el, ancestral)
    return el
}


// ── criaTexto ─────────────────────────────────────────────────
//
// Parágrafo de texto simples.
//
// criaTexto({ id, texto, ancestral })

function criaTexto({ id, texto, ancestral }) {
    const el = _ui_el('div', {
        fontSize:   '12px',
        color:      UI_CORES.texto,
        paddingLeft: '8px',
        marginRight:'8px',
        lineHeight: '1.5',
        fontFamily: "var(--extensao-rotapje-fonte)",
        whiteSpace: 'pre-wrap',
    })
    el.id          = id
    el.textContent = texto
    _ui_inserir(el, ancestral)
    return el
}


// ── criaBotaoAzul ─────────────────────────────────────────────
//
// Botão azul primário. Clique chama acao().
//
// criaBotaoAzul({ id, texto, ancestral, acao })

function criaBotaoAzul({ id, texto = 'OK', ancestral, acao }) {
    const btn = _ui_el('button', _ui_estiloBotao(UI_CORES.azul, UI_CORES.azulHover))
    btn.id          = id
    btn.textContent = texto
    btn.type = 'button'
    _ui_hoverBotao(btn, UI_CORES.azul, UI_CORES.azulHover)
    if (typeof acao === 'function') btn.addEventListener('click', acao)
    if (ancestral) _ui_inserir(btn, ancestral)
    return btn
}


// ── criaBotaoLaranja ──────────────────────────────────────────
//
// Botão laranja de ação secundária. Clique chama acao().
//
// criaBotaoLaranja({ id, texto, ancestral, acao })

function criaBotaoLaranja({ id, texto = 'OK', ancestral, acao }) {
    const btn = _ui_el('button', _ui_estiloBotao(UI_CORES.laranja, UI_CORES.laranjaHover))
    btn.id          = id
    btn.textContent = texto
    btn.type = 'button'
    _ui_hoverBotao(btn, UI_CORES.laranja, UI_CORES.laranjaHover)
    if (typeof acao === 'function') btn.addEventListener('click', acao)
    _ui_inserir(btn, ancestral)
    return btn
}


// ── criaBotaoAzulComCheckBox ──────────────────────────────────
//
// Botão azul com checkbox à direita.
// Clicar no botão → executa acao() diretamente.
// O checkbox é lido pelo EXECUTAR da criaDivExecucao.
//
// Layout:
//   [ Texto do botão              ✓ ]
//
// criaBotaoAzulComCheckBox({ id, idCheckbox, texto, ancestral, acao })

function criaBotaoAzulComCheckBox({ id, idCheckbox, texto = 'OK', ancestral, acao, grupo}) {
    return _ui_botaoComCheckBox({
        id, idCheckbox, texto, ancestral, acao, grupo, 
        cor: UI_CORES.azul, corHover: UI_CORES.azulHover,
    })
}


// ── criaBotaoLaranjaComCheckBox ───────────────────────────────
//
// Igual ao azul mas na cor laranja.
//
// criaBotaoLaranjaComCheckBox({ id, idCheckbox, texto, ancestral, acao })

function criaBotaoLaranjaComCheckBox({ id, idCheckbox, texto = 'OK', ancestral, acao, grupo }) {
    return _ui_botaoComCheckBox({
        id, idCheckbox, texto, ancestral, acao, grupo,
        cor: UI_CORES.laranja, corHover: UI_CORES.laranjaHover,
    })
}

// Implementação compartilhada dos botões com checkbox
function _ui_botaoComCheckBox({ id, idCheckbox, texto, ancestral, acao, cor, corHover, grupo }) {
    // Container linha
    const linha = _ui_el('div', {
        display:     'flex',
        alignItems:  'center',
        gap:         '6px',
        marginBottom:'4px',
    })
    linha.id = id + '-linha'

    // Botão
    const btn = _ui_el('button', {
        ..._ui_estiloBotao(cor, corHover),
        flex:   '1',
        width:  'auto',
        display:'block',
    })
    btn.id          = id
    btn.textContent = texto
    btn.type = 'button'
    _ui_hoverBotao(btn, cor, corHover)
    if (typeof acao === 'function') btn.addEventListener('click', acao)

    // Checkbox visual
    const chk = _ui_el('div', {
        width:          '18px',
        height:         '18px',
        flexShrink:     '0',
        border:         '2px solid ' + UI_CORES.borda,
        borderRadius:   '4px',
        background:     UI_CORES.branco,
        cursor:         'pointer',
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'center',
        transition:     'all 0.15s',
        fontSize:       '12px',
    })
    chk.id              = idCheckbox
    chk.dataset.marcado = '0'
    if (grupo) chk.dataset.grupo = grupo

    // Função de desmarcar exposta no elemento
    chk.desmarcar = () => {
        chk.dataset.marcado  = '0'
        chk.style.background = UI_CORES.branco
        chk.style.borderColor= UI_CORES.borda
        chk.textContent      = ''
    }

    chk.addEventListener('click', () => {
        if (chk.dataset.marcado === '1') {
            chk.desmarcar()
        } else {
            // Marca este
            chk.dataset.marcado  = '1'
            chk.style.background = cor
            chk.style.borderColor= cor
            chk.textContent      = '✓'
            chk.style.color      = '#ffffff'

            // Desmarca os demais do mesmo grupo
            if (grupo) {
                document.querySelectorAll(`[data-grupo="${grupo}"]`).forEach(outro => {
                    if (outro !== chk && typeof outro.desmarcar === 'function') {
                        outro.desmarcar()
                    }
                })
            }
        }
    })

    linha.appendChild(btn)
    linha.appendChild(chk)
    _ui_inserir(linha, ancestral)
    return linha
}


// ── criaMenuSuspenso ─────────────────────────────────────────
//
// Menu suspenso (dropdown) com a mesma aparência dos botões —
// mesmo formato, fonte e cor — com uma seta na direita indicando
// abrir/fechar.
//
// O elemento retornado se comporta como um <select> nativo: tem
// `.value` com o valor selecionado, e dispara um evento 'change'
// sempre que o usuário escolhe uma opção. Dá pra reagir tanto pelo
// callback `acao` quanto por addEventListener, como preferir:
//
//   const menu = criaMenuSuspenso({
//       id:       'meu-menu',
//       opcoes:   [
//           { valor: 'a', texto: 'Opção A' },
//           { valor: 'b', texto: 'Opção B' },
//       ],
//       valorInicial: 'a',
//       ancestral:    'meu-container',
//       acao: (valor, opcao) => console.log('mudou para', valor),
//   })
//
//   // alternativa via eventlistener (equivalente ao 'acao' acima) —
//   // útil se você for adicionar o listener em outro lugar do código:
//   document.getElementById('meu-menu').addEventListener('change', (e) => {
//       console.log('mudou para', e.detail.valor, e.detail.opcao)
//   })
//
//   // e a qualquer momento dá pra ler ou setar o valor atual:
//   document.getElementById('meu-menu').value = 'b'
//
// criaMenuSuspenso({ id, opcoes, valorInicial, ancestral, cor, acao })
//   opcoes:       array de { valor, texto } — ou strings simples (valor = texto)
//   valorInicial: opcional — padrão é a primeira opção
//   cor:          'azul' (padrão) | 'laranja' | '#hexadecimal' customizado
//   acao:         opcional — function(valor, opcao) chamada na troca

function _ui_resolveCor(cor) {
    if (cor === 'laranja')          return { cor: UI_CORES.laranja, corHover: UI_CORES.laranjaHover }
    if (cor === 'azul' || !cor)     return { cor: UI_CORES.azul,    corHover: UI_CORES.azulHover }
    return { cor: cor, corHover: _ui_escurecerHex(cor, 15) } // hex customizado
}

// Escurece uma cor hex em X% — usada para gerar o hover de cores customizadas
function _ui_escurecerHex(hex, porcentagem) {
    hex = hex.replace('#', '')
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('')
    const num   = parseInt(hex, 16)
    const fator = 1 - porcentagem / 100
    const r = Math.max(0, Math.min(255, Math.floor(((num >> 16) & 0xff) * fator)))
    const g = Math.max(0, Math.min(255, Math.floor(((num >> 8)  & 0xff) * fator)))
    const b = Math.max(0, Math.min(255, Math.floor(( num        & 0xff) * fator)))
    return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('')
}

function criaMenuSuspenso({ id, opcoes = [], valorInicial, ancestral, cor = 'azul', acao }) {
    const { cor: corBase, corHover } = _ui_resolveCor(cor)

    const opcoesNormalizadas = opcoes.map(o =>
        typeof o === 'string' ? { valor: o, texto: o } : o
    )

    // ── container (posição relativa — ancora a lista) ──────────
    const container = _ui_el('div', {
        position:    'relative',
        marginLeft:  '3px',
        marginRight: '3px',
    })
    container.id = id

    // ── "botão" visível (mesma cara dos demais botões) ─────────
    const botao = _ui_el('div', {
        ..._ui_estiloBotao(corBase, corHover),
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'space-between',
        marginLeft:     '0',
        marginRight:    '0',
        userSelect:     'none',
    })
    botao.tabIndex = 0

    const textoSpan = _ui_el('span', {
        overflow:     'hidden',
        textOverflow: 'ellipsis',
        whiteSpace:   'nowrap',
    })
    textoSpan.id = id + '-texto'

    const seta = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    seta.setAttribute('viewBox', '0 0 10 6')
    seta.setAttribute('width', '10')
    seta.setAttribute('height', '6')
    seta.style.marginLeft = '8px'
    seta.style.flexShrink = '0'
    seta.style.transition = 'transform 0.15s'
    seta.innerHTML = '<path d="M0 0 L5 6 L10 0 Z" fill="#ffffff"></path>'

    botao.appendChild(textoSpan)
    botao.appendChild(seta)
    _ui_hoverBotao(botao, corBase, corHover)

    // ── lista de opções (oculta por padrão) ─────────────────────
    const lista = _ui_el('div', {
        position:     'absolute',
        top:          'calc(100% + 4px)',
        left:         '0',
        right:        '0',
        background:   UI_CORES.branco,
        border:       '1px solid ' + UI_CORES.borda,
        borderRadius: '6px',
        boxShadow:    '0 4px 12px rgba(0,0,0,0.15)',
        maxHeight:    '200px',
        overflowY:    'auto',
        zIndex:       String((typeof ROTA_Z !== 'undefined' ? (ROTA_Z.flutuante ?? 9000) : 9000) + 1),
        display:      'none',
    })
    lista.id = id + '-lista'

    let valorAtual = valorInicial ?? opcoesNormalizadas[0]?.valor

    function _renderTexto() {
        const op = opcoesNormalizadas.find(o => o.valor === valorAtual)
        textoSpan.textContent = op ? op.texto : ''
    }

    function _fechar() {
        lista.style.display  = 'none'
        seta.style.transform = 'rotate(0deg)'
    }

    function _abrir() {
        lista.style.display  = 'block'
        seta.style.transform = 'rotate(180deg)'
    }

    opcoesNormalizadas.forEach(op => {
        const item = _ui_el('div', {
            padding:    '7px 12px',
            fontSize:   '12px',
            fontFamily: "var(--extensao-rotapje-fonte)",
            color:      UI_CORES.texto,
            cursor:     'pointer',
        })
        item.textContent = op.texto
        item.addEventListener('mouseenter', () => item.style.background = UI_CORES.fundo)
        item.addEventListener('mouseleave', () => item.style.background = 'transparent')
        item.addEventListener('click', () => {
            valorAtual = op.valor
            _renderTexto()
            _fechar()
            // dispara 'change' como um <select> nativo faria
            container.dispatchEvent(new CustomEvent('change', { detail: { valor: valorAtual, opcao: op } }))
            if (typeof acao === 'function') acao(valorAtual, op)
        })
        lista.appendChild(item)
    })

    botao.addEventListener('click', (e) => {
        e.stopPropagation()
        lista.style.display === 'none' ? _abrir() : _fechar()
    })

    // fecha ao clicar fora do menu
    document.addEventListener('click', (e) => {
        if (!container.contains(e.target)) _fechar()
    })

    // acessibilidade básica: Enter/Espaço abre-fecha, Esc fecha
    botao.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault()
            lista.style.display === 'none' ? _abrir() : _fechar()
        }
        if (e.key === 'Escape') _fechar()
    })

    // ── expõe .value, como um <select> nativo ────────────────────
    Object.defineProperty(container, 'value', {
        get: () => valorAtual,
        set: (novoValor) => {
            valorAtual = novoValor
            _renderTexto()
        },
    })

    _renderTexto()
    container.appendChild(botao)
    container.appendChild(lista)
    _ui_inserir(container, ancestral)
    return container
}


// ── criaBotaoComInputAzul ─────────────────────────────────────
//
// Input de texto com botão azul abaixo.
//
// Layout:
//   textoEmCima (label, opcional)
//   ┌─────────────┐
//   │    INPUT    │
//   ├─────────────┤
//   │    BOTÃO    │
//   └─────────────┘
//
// criaBotaoComInputAzul({ id, idInput, texto, textoEmCima, ancestral, acao })

function criaBotaoComInputAzul({ id, idInput, texto = 'OK', textoEmCima = '', ancestral, acao }) {
    return _ui_botaoComInput({
        id, idInput, texto, textoEmCima, ancestral, acao,
        cor: UI_CORES.azul, corHover: UI_CORES.azulHover,
    })
}


// ── criaBotaoComInputLaranja ──────────────────────────────────
//
// Igual ao azul mas na cor laranja.
//
// criaBotaoComInputLaranja({ id, idInput, texto, textoEmCima, ancestral, acao })

function criaBotaoComInputLaranja({ id, idInput, texto = 'OK', textoEmCima = '', ancestral, acao }) {
    return _ui_botaoComInput({
        id, idInput, texto, textoEmCima, ancestral, acao,
        cor: UI_CORES.laranja, corHover: UI_CORES.laranjaHover,
    })
}

function _ui_botaoComInput({ id, idInput, texto, textoEmCima, ancestral, acao, cor, corHover }) {
    const container = _ui_el('div', {
        display:       'flex',
        flexDirection: 'column',
        gap:           '0',
        marginBottom:  '6px',
        marginLeft:     '4px',
        marginRight:    '6px',
    })
    container.id = id + '-container'

    // Label acima (opcional)
    if (textoEmCima) {
        const label = _ui_el('div', {
            fontSize:     '11px',
            color:        UI_CORES.suave,
            marginBottom: '3px',
            fontFamily:   rota_ui_fonte(),
            marginLeft:     '4px',
            marginRight:    '6px',
        })
        label.textContent = textoEmCima
        container.appendChild(label)
    }

    // Input
    const input = _ui_el('input', {
        width:        '100%',
        border:       '1px solid ' + UI_CORES.borda,
        borderBottom: 'none',
        borderRadius: '6px 6px 0 0',
        padding:      '7px 10px',
        fontSize:     '12px',
        fontFamily:   rota_ui_fonte(),
        color:        UI_CORES.texto,
        background:   UI_CORES.branco,
        outline:      'none',
        boxSizing:    'border-box',
        marginLeft:     '4px',
        marginRight:    '6px',
    })
    input.id   = idInput
    input.type = 'text'

    // Botão
    const btn = _ui_el('button', {
        ..._ui_estiloBotao(cor, corHover),
        borderRadius: '0 0 6px 6px',
        marginTop:    '0',
    })
    btn.id          = id
    btn.textContent = texto
    btn.type = 'button'
    _ui_hoverBotao(btn, cor, corHover)
    if (typeof acao === 'function') btn.addEventListener('click', acao)

    container.appendChild(input)
    container.appendChild(btn)
    _ui_inserir(container, ancestral)
    return container
}


// ── criaInput ─────────────────────────────────────────────────
//
// Campo de texto simples com label acima.
//
// criaInput({ id, textoEmCima, ancestral, placeholder })

function criaInput({ id, textoEmCima = '', ancestral, placeholder = '' }) {
    const container = _ui_el('div', {
        display:       'flex',
        flexDirection: 'column',
        gap:           '3px',
        marginBottom:  '6px',
    })
    container.id = id + '-container'

    if (textoEmCima) {
        const label = _ui_el('div', {
            fontSize:  '11px',
            color:     UI_CORES.suave,
            fontFamily:"var(--extensao-rotapje-fonte)",
        })
        label.textContent = textoEmCima
        container.appendChild(label)
    }

    const input = _ui_el('input', {
        width:        '100%',
        border:       '1px solid ' + UI_CORES.borda,
        borderRadius: '6px',
        padding:      '7px 10px',
        fontSize:     '12px',
        fontFamily:   rota_ui_fonte(),
        color:        UI_CORES.texto,
        background:   UI_CORES.branco,
        outline:      'none',
        boxSizing:    'border-box',
    })
    input.id          = id
    input.type        = 'text'
    input.placeholder = placeholder
    input.container = container
    

    container.appendChild(input)
    _ui_inserir(container, ancestral)
    return input
}

function criaInputAnotacao({ id, textoEmCima = '', ancestral, placeholder = '' }) {
    const container = _ui_el('div', {
        display:       'flex',
        padding: '8px',
        flexDirection: 'column',
        gap:           '3px',
        marginBottom:  '6px',
    })
    container.id = id + '-container'

    if (textoEmCima) {
        const label = _ui_el('div', {
            fontSize:  '11px',
            color:     UI_CORES.suave,
            fontFamily:"var(--extensao-rotapje-fonte)",
        })
        label.textContent = textoEmCima
        container.appendChild(label)
    }

    const textarea = _ui_el('textarea', {
        width:        '100%',
        border:       '1px solid ' + UI_CORES.borda,
        borderRadius: '6px',
        padding:      '7px 10px',
        fontSize:     '12px',
        fontFamily:   rota_ui_fonte(),
        color:        UI_CORES.texto,
        background:   UI_CORES.branco,
        outline:      'none',
        boxSizing:    'border-box',
        resize:       'none',       // não redimensiona manualmente
        overflow:     'hidden',     // esconde scrollbar enquanto cresce
        minHeight:    '34px',
        lineHeight:   '1.5',
    })
    textarea.id          = id
    textarea.placeholder = placeholder

    // Cresce conforme o conteúdo
    textarea.addEventListener('input', () => {
        textarea.style.height = 'auto'
        textarea.style.height = textarea.scrollHeight + 'px'
    })

    container.textarea = textarea
    container.appendChild(textarea)
    _ui_inserir(container, ancestral)
    return container
}
// ── criaCheckBox ──────────────────────────────────────────────
//
// Checkbox com texto ao lado direito.
//
// Layout:  [✓] Texto ao lado
//
// criaCheckBox({ id, textoAoLado, ancestral })

async function criaCheckBox({ id, textoAoLado = '', ancestral, salvar = false }) {
    const linha = _ui_el('div', {
        display: 'flex', alignItems: 'center', gap: '8px',
        cursor: 'pointer', marginBottom: '4px',
    })
    linha.id = id

    const chk = _ui_el('div', {
        width: '16px', height: '16px', flexShrink: '0',
        border: '2px solid ' + UI_CORES.borda, borderRadius: '4px',
        background: UI_CORES.branco, display: 'flex',
        alignItems: 'center', justifyContent: 'center',
        transition: 'all 0.15s', fontSize: '11px',
    })
    chk.id = id + '-caixa'

    const label = _ui_el('span', {
        fontSize: '12px', color: UI_CORES.texto,
        fontFamily: 'var(--extensao-rotapje-fonte)', userSelect: 'none',
    })
    label.textContent = textoAoLado

    function aplicarVisual(marcado) {
        linha.dataset.marcado = marcado ? '1' : '0'
        chk.style.background  = marcado ? UI_CORES.azul : UI_CORES.branco
        chk.style.borderColor = marcado ? UI_CORES.azul : UI_CORES.borda
        chk.style.color       = '#ffffff'
        chk.textContent       = marcado ? '✓' : ''
    }

    async function alternar() {
        const novoEstado = linha.dataset.marcado !== '1'
        aplicarVisual(novoEstado)
        if (salvar) await armazenar({ [id]: novoEstado })
    }

    aplicarVisual(false)
    linha.addEventListener('click', alternar)
    linha.appendChild(chk)
    linha.appendChild(label)
    _ui_inserir(linha, ancestral)

    if (salvar) {
        const armazenamento = await obterArmazenamento(id)
        if (armazenamento?.[id]) aplicarVisual(true)
    }

    return linha
}


// ── criaTabela ────────────────────────────────────────────────
//
// Tabela com colunas identificadas por id.
// As colunas são criadas pelo array idDasColunas.
// O rótulo de cada coluna é opcional — se não passar 'colunas',
// usa os próprios ids como cabeçalho.
// Linhas são adicionadas depois via ui_adicionarLinhaTabela().
//
// criaTabela({ id, idDasColunas, colunas, ancestral })
//   idDasColunas: ['col-nome', 'col-cpf', 'col-acao']
//   colunas:      ['Nome', 'CPF', 'Ação']  ← opcional

function criaGrade({ id, ancestral, numeroColunas, larguraColunas = {} }) {
    const colunasCss = Array.from({ length: numeroColunas }, (_, i) => {
        const chave = 'coluna' + i
        return larguraColunas[chave] || `${100 / numeroColunas}%`
    }).join(' ')

    const grade = _ui_el('div', {
        display:             'grid',
        gridTemplateColumns: colunasCss,
        marginBottom:        '2px',
        marginRight: '6px',
        gap: '4px'
    })
    grade.id = id
    _ui_inserir(grade, ancestral)
    return grade
}

function criaTabela({ id, idDasColunas = [], colunas, ancestral, semDivisao = false }) {
    const wrapper = _ui_el('div', {
        overflowX:    'auto',
        marginBottom: '8px',
        borderRadius: '6px',
        border:       '1px solid ' + UI_CORES.borda,
    })
    wrapper.id = id + '-wrapper'
    const tabela = _ui_el('table', {
        width:          '100%',
        borderCollapse: 'collapse',
        fontSize:       '12px',
        fontFamily:     "var(--extensao-rotapje-fonte)",
        color:          UI_CORES.texto,
    })
    tabela.id = id

    if (colunas) {
        const thead = document.createElement('thead')
        const trH   = document.createElement('tr')
        idDasColunas.forEach((colId, i) => {
            const th = _ui_el('th', {
                padding:     '7px 10px',
                textAlign:   'left',
                background:  UI_CORES.azul,
                color:       '#ffffff',
                fontWeight:  '700',
                whiteSpace:  'nowrap',
                width:       `${Math.floor(100 / idDasColunas.length)}%`,
                borderRight: (!semDivisao && i < idDasColunas.length - 1)
                    ? '1px solid rgba(255,255,255,0.2)'
                    : 'none',
            })
            th.id          = colId
            th.textContent = colunas[i] || colId
            trH.appendChild(th)
        })
        thead.appendChild(trH)
        tabela.appendChild(thead)
    }

    const tbody = document.createElement('tbody')
    tbody.id = id + '-corpo'
    tbody.dataset.semDivisao  = semDivisao ? '1' : '0'
    tbody.dataset.idDasColunas = JSON.stringify(idDasColunas)  // ← guarda para uso sem cabeçalho
    tabela.appendChild(tbody)
    wrapper.appendChild(tabela)
    _ui_inserir(wrapper, ancestral)
    return wrapper
}



function ui_adicionarLinhaTabela(idTabela, valores = {}) {
    const tbody = document.getElementById(idTabela + '-corpo')
    if (!tbody) { console.warn('[ui.js] tabela não encontrada:', idTabela); return null }
    const semDivisao   = tbody.dataset.semDivisao === '1'

    // Tenta usar thead th; se não houver cabeçalho, usa idDasColunas do dataset
    const tabela       = document.getElementById(idTabela)
    const ths          = tabela?.querySelectorAll('thead th') || []
    const colunas      = ths.length > 0
        ? Array.from(ths).map(th => ({ id: th.id }))
        : JSON.parse(tbody.dataset.idDasColunas || '[]').map(colId => ({ id: colId }))

    const tr  = document.createElement('tr')
    const idx = tbody.children.length
    tr.style.background = idx % 2 === 0 ? UI_CORES.branco : UI_CORES.fundo

    colunas.forEach(({ id: colId }, i) => {
        const td = _ui_el('td', {
            padding:      '6px 10px',
            borderTop:    '1px solid ' + UI_CORES.borda,
            borderRight:  (!semDivisao && i < colunas.length - 1)
                ? '1px solid ' + UI_CORES.borda
                : 'none',
            verticalAlign: 'middle',
            width:         `${Math.floor(100 / colunas.length)}%`,
            textAlign: 'center'
        })
        const valor = valores[colId]
        if (valor instanceof HTMLElement) {
            td.appendChild(valor)
        } else {
            td.textContent = valor ?? ''
        }
        tr.appendChild(td)
    })
    tbody.appendChild(tr)
    return tr
}


// ── criaDivExecucao ───────────────────────────────────────────
//
// Div com duas colunas:
//   - idColuna (esquerda): o roteiro coloca qualquer coisa aqui
//   - idBotaoExecutar (direita): botão EXECUTAR fixo
//
// Layout:
//   ┌──────────────────────┬──────────┐
//   │ idColuna             │ EXECUTAR │
//   └──────────────────────┴──────────┘
//
// criaDivExecucao({ id, idColuna, idBotaoExecutar, acaoBotaoExecutar, ancestral })

function criaDivExecucao({ id, idColuna, idBotaoExecutar, acaoBotaoExecutar, ancestral }) {
    const container = _ui_el('div', {
        display:     'flex',
        gap:         '8px',
        alignItems:  'flex-start',
        marginBottom:'8px',
        marginLeft:  '4px',
        marginRight: '6px',
        borderRadius:'6px',
        background:  UI_CORES.fundo,
        border:      '1px solid ' + UI_CORES.borda,
        borderRadius:'6px',
        padding:     '8px',
    })
    container.id = id

    // Coluna esquerda — livre para o roteiro
    const coluna = _ui_el('div', {
        flex:          '1',
        display:       'flex',
        flexDirection: 'column',
        gap:           '6px',
        minWidth:      '0',
    })
    coluna.id = idColuna

    // Botão EXECUTAR — fixo à direita
    const btn = _ui_el('button', {
        ..._ui_estiloBotao(UI_CORES.laranja, UI_CORES.laranjaHover),
        width:     'auto',
        flexShrink:'0',
        padding:   '8px 14px',
        alignSelf: 'stretch',  // ocupa a altura da coluna esquerda
        writingMode: 'vertical-rl',
        fontSize:     '12px',
    })
    btn.id          = idBotaoExecutar
    btn.textContent = 'Executar todos ➡️'
    
    _ui_hoverBotao(btn, UI_CORES.laranja, UI_CORES.laranjaHover)
    if (typeof acaoBotaoExecutar === 'function') {
        btn.addEventListener('click', acaoBotaoExecutar)
    }

    container.appendChild(coluna)
    container.appendChild(btn)
    _ui_inserir(container, ancestral)
    return container
}


// ── criaTextoQueAbrePassandoOMouse ────────────────────────────
//
// Texto/rótulo que, ao passar o mouse, exibe um box com conteúdo.
// Equivalente ao antigo infoPJE.
//
// corDoBox: 'azul' | 'laranja' | 'verde' | 'vermelho'
//
// criaTextoQueAbrePassandoOMouse({ id, texto, ancestral, corDoBox })
function criaTextoQueAbrePassandoOMouse({ id, texto = '📋 Passe o mouse', ancestral, corDoBox = 'azul', textoBox = '' }) {
    const CORES_BOX = {
        azul:     { bg: '#e3f2fd', borda: UI_CORES.azul    },
        laranja:  { bg: '#fff3e0', borda: UI_CORES.laranja  },
        verde:    { bg: '#e8f5e9', borda: '#2e7d32'         },
        vermelho: { bg: '#fdecea', borda: UI_CORES.erro     },
    }
    const cor = CORES_BOX[corDoBox] || CORES_BOX.azul

    let fixado = false  // ← estado que persiste no closure

    const wrapper = _ui_el('div', { position: 'relative', marginBottom: '4px' })
    wrapper.id = id + '-wrapper'
    
    const rotulo = _ui_el('div', {
        fontSize: '12px', color: UI_CORES.azul, cursor: 'pointer',
        fontFamily: "var(--extensao-rotapje-fonte)", userSelect: 'none',
        display: 'inline-block', borderBottom: '1px dashed ' + UI_CORES.azul,
        paddingBottom: '1px', paddingLeft: '8px', whiteSpace: 'pre-wrap',
    })
    rotulo.id = id
    rotulo.textContent = texto

    const box = _ui_el('div', {
        display: 'none', position: 'absolute', top: 'calc(100% + 4px)', left: '0',
        zIndex: '9999', background: cor.bg, border: '1px solid ' + cor.borda,
        borderRadius: '6px', padding: '10px 12px', fontSize: '12px',
        color: UI_CORES.texto, fontFamily: "var(--extensao-rotapje-fonte)",
        lineHeight: '1.5', whiteSpace: 'pre-wrap', maxWidth: parseInt(window.innerWidth * 0.97) + 'px',
        boxShadow: '0 4px 16px rgba(0,0,0,0.10)', minWidth: '180px',
        textAlign: 'justify',
        cursor: 'pointer',
    })
    box.id = id + '-box'
    box.textContent = textoBox

    // Enquanto o box está visível, libera o overflow de qualquer ancestral
    // marcado como '.ui-clip-liberavel' — o corpo recolhível de uma
    // await criaSecaoMostraRecolhe, o wrapper externo dela (que corta cantos
    // arredondados), ou o corpo scrollável de um criaDivFlutuante — pra
    // nenhum deles recortar o box. Guarda os valores originais em dataset
    // e restaura ao fechar. Assim o box continua filho do wrapper (rola e
    // se comporta como qualquer elemento normal da página), sem cálculo
    // de posição manual.
    function _ajustarOverflowAncestrais(mostrar) {
        let el = wrapper.parentElement
        while (el) {
            if (el.classList && el.classList.contains('ui-clip-liberavel')) {
                if (mostrar) {
                    if (el.dataset.uiOverflowOriginal === undefined) {
                        el.dataset.uiOverflowOriginal  = el.style.overflow  || ''
                        el.dataset.uiOverflowYOriginal = el.style.overflowY || ''
                    }
                    el.style.overflow  = 'visible'
                    el.style.overflowY = 'visible'
                } else if (el.dataset.uiOverflowOriginal !== undefined) {
                    el.style.overflow  = el.dataset.uiOverflowOriginal
                    el.style.overflowY = el.dataset.uiOverflowYOriginal
                    delete el.dataset.uiOverflowOriginal
                    delete el.dataset.uiOverflowYOriginal
                }
            }
            el = el.parentElement
        }
    }

    function _mostrarBox() {
        box.style.display = 'block'
        _ajustarOverflowAncestrais(true)
    }
    function _esconderBox() {
        box.style.display = 'none'
        _ajustarOverflowAncestrais(false)
    }

    // Hover: só age se não estiver fixado
    rotulo.addEventListener('mouseenter', () => {
        if (!fixado) _mostrarBox()
    })
    rotulo.addEventListener('mouseleave', () => {
        if (!fixado) setTimeout(() => { if (!box.matches(':hover')) _esconderBox() }, 100)
    })
    box.addEventListener('mouseleave', () => {
        if (!fixado) _esconderBox()
    })

    // Clique no rótulo: alterna fixação
    rotulo.addEventListener('click', () => {
        fixado = !fixado
        if (fixado) _mostrarBox(); else _esconderBox()
        rotulo.style.fontWeight = fixado ? 'bold' : 'normal'  // feedback visual opcional
        rotulo.textContent = texto + (fixado ? '▲' : '')  // seta para indicar fixação
    })

    // Clique no box enquanto fixado: desfixa e fecha
    box.addEventListener('click', () => {
        if (fixado) {
            fixado = false
            _esconderBox()
            rotulo.style.fontWeight = 'normal'
            rotulo.textContent = texto
        } else {
            fixado = true
            rotulo.style.fontWeight = 'bold'
            rotulo.textContent = texto + '▲'
        }
    })

    wrapper.appendChild(rotulo)
    wrapper.appendChild(box)
    _ui_inserir(wrapper, ancestral)

    wrapper.atualizarConteudo = (conteudo) => { box.textContent = conteudo }

    return wrapper
}


// ── criaBotaoProximoEEncerrar ─────────────────────────────────
//
// Par de botões Encerrar + Próximo lado a lado.
// Usados no rodapé do assistente e no widget das janelas filhas.
// Acionam rota_sinalizar() com a sessão atual.
//
// A sessao é lida do storage (rotaExecucaoAtual) no momento do clique.
//
// criaBotaoProximoEEncerrar({ id, ancestral })

function criaBotaoProximoEEncerrar({ id, ancestral }) {
    const linha = _ui_el('div', {
        display: 'flex',
        gap:     '6px',
    })
    linha.id = id

    const btnEncerrar = _ui_el('button', {
        ..._ui_estiloBotao(UI_CORES.fundo, '#ececec', UI_CORES.texto),
        flex:   '1',
        border: '1px solid ' + UI_CORES.borda,
        width:  'auto',
    })
    btnEncerrar.id          = id + '-encerrar'
    btnEncerrar.textContent = '■ Encerrar'
    btnEncerrar.type = 'button'
    btnEncerrar.addEventListener('mouseenter', () => btnEncerrar.style.background = '#ececec')
    btnEncerrar.addEventListener('mouseleave', () => btnEncerrar.style.background = UI_CORES.fundo)

    const btnProximo = _ui_el('button', {
        ..._ui_estiloBotao(UI_CORES.laranja, UI_CORES.laranjaHover),
        flex:  '1',
        width: 'auto',
    })
    btnProximo.id          = id + '-proximo'
    btnProximo.textContent = '▶ Próximo'
    btnProximo.type = 'button'
    _ui_hoverBotao(btnProximo, UI_CORES.laranja, UI_CORES.laranjaHover)

    // Lê a sessão no momento do clique para garantir o valor atual
    const execucao = () => new URL(location.href).searchParams.get('rotapje_execucao') || ''

    btnProximo.addEventListener('click', async () => {
        if (btnProximo.disabled) return
        btnProximo.disabled = btnEncerrar.disabled = true   // evita clique duplo
        await armazenar({ rotaSinalAssistente: { execucao: execucao(), acao: 'proximo' } })
    })

    btnEncerrar.addEventListener('click', async () => {
        if (btnEncerrar.disabled) return
        btnProximo.disabled = btnEncerrar.disabled = true
        await armazenar({ rotaSinalAssistente: { execucao: execucao(), acao: 'encerrar' } })
        await armazenar({ rotaAssistenteFechar: true })
    })
    linha.appendChild(btnEncerrar)
    linha.appendChild(btnProximo)
    _ui_inserir(linha, ancestral)
    return linha
}


// ── criarCarregando / removerCarregando ───────────────────────
//
// Exibe/remove um indicador de carregamento na área rolável.
// O elemento pai é 'rota_corpo' (área rolável do assistente).

const _UI_ID_CARREGANDO = 'rota-carregando'

function criarCarregando(ancestral = 'rota_corpo') {
    removerCarregando()

    const el = _ui_el('div', {
        display:        'flex',
        flexDirection:  'column',
        alignItems:     'center',
        justifyContent: 'center',
        gap:            '10px',
        padding:        '32px 16px',
        color:          UI_CORES.suave,
        fontSize:       '12px',
        fontFamily:     "var(--extensao-rotapje-fonte)",
    })
    el.id = _UI_ID_CARREGANDO

    // Spinner CSS simples
    const spinner = _ui_el('div', {
        width:       '24px',
        height:      '24px',
        border:      '3px solid ' + UI_CORES.borda,
        borderTop:   '3px solid ' + UI_CORES.azul,
        borderRadius:'50%',
        animation:   'rota-spin 0.8s linear infinite',
    })

    // Injeta keyframe se ainda não existir
    if (!document.getElementById('rota-spin-style')) {
        const style = document.createElement('style')
        style.id = 'rota-spin-style'
        style.textContent = '@keyframes rota-spin { to { transform: rotate(360deg) } }'
        document.head.appendChild(style)
    }

    const msg = _ui_el('span', {})
    msg.textContent = 'Aguardando dados…'

    el.appendChild(spinner)
    el.appendChild(msg)
    _ui_inserir(el, ancestral)
    return el
}

function removerCarregando() {
    document.getElementById(_UI_ID_CARREGANDO)?.remove()
}


// ── ui_checkboxMarcado ────────────────────────────────────────
//
// Utilitário: retorna true se o checkbox com o id dado
// estiver marcado. Usado pelo roteiro para verificar
// o estado dos botões com checkbox.
//
// ui_checkboxMarcado('chk-reclamante')  →  true | false

function ui_checkboxMarcado(idCheckbox) {
    const el = document.getElementById(idCheckbox)
    return el?.dataset?.marcado === '1'
}

// ── criaPlaquinha ─────────────────────────────────────────────
//
// Plaquinha colorida para destacar informações.
// cor: 'azul' | 'laranja' | 'amarelo' | 'verde'
//
// criaPlaquinha({ id, texto, cor, ancestral })

function criaPlaquinha({ id, texto = '', cor = 'azul', ancestral }) {
    const CORES_PLAQUINHA = {
        azul:    { bg: '#90caf9' , borda: '#1e88e5', texto: '#03071e'},
        laranja: { bg: '#e65100' , borda: '#ffa726', texto: '#fff3e0'},
        vermelho:{ bg: '#780000' , borda: '#c1121f', texto: '#fdf0d5'},
        amarelo: { bg: '#ffd500' , borda: '#fdc500', texto: '#03071e'},
        verde:   { bg: '#386641' , borda: '#6a994e', texto: '#e8f5e9'},
    }
    const c = CORES_PLAQUINHA[cor] || CORES_PLAQUINHA.azul

    const el = _ui_el('span', {
        display:       'inline-block',
        background:    c.bg,
        border:        '1px solid ' + c.borda,
        borderRadius:  '4px',
        padding:       '2px 8px',
        fontSize:      '11px',
        fontWeight:    '700',
        color:         c.texto,
        fontFamily:    "var(--extensao-rotapje-fonte)",
        whiteSpace:    'normal',
        marginRight:   '4px',
        marginBottom:  '4px',
        letterSpacing: '0.02em',
    })
    el.id          = id
    el.textContent = texto
    if (ancestral) _ui_inserir(el, ancestral)
    return el
}


// ── criaPlaquinhaComTooltip ───────────────────────────────────
//
// Plaquinha colorida com tooltip ao passar o mouse.
// cor: 'azul' | 'laranja' | 'amarelo' | 'verde'
//
// criaPlaquinhaComTooltip({ id, texto, cor, tooltip, ancestral })

/**
 * Cria e anexa um tooltip a qualquer elemento existente.
 * @param {Object} opts
 * @param {string}           opts.id       - id base (usado no tip)
 * @param {string}           opts.texto    - texto do tooltip
 * @param {string|HTMLElement} opts.elemento - o elemento-alvo ou seu id
 * @returns {{ remover: Function, atualizar: Function }}
 */
function criaTooltip({ id, texto = '', elemento }) {
    const alvo = typeof elemento === 'string'
        ? document.getElementById(elemento)
        : elemento

    if (!alvo) {
        console.warn(`criaTooltip: elemento não encontrado`, elemento)
        return null
    }

    const tip = _ui_el('div', {
        display:       'none',
        position:      'fixed',
        background:    '#000000',
        color:         '#ffffff',
        borderRadius:  '4px',
        padding:       '5px 10px',
        fontSize:      '11px',
        fontFamily:    "var(--extensao-rotapje-fonte)",
        whiteSpace:    'pre-wrap',
        maxWidth:      '240px',
        boxShadow:     '0 2px 8px rgba(0,0,0,0.15)',
        zIndex:        '999999999',
        pointerEvents: 'none',
        lineHeight:    '1.4',
    })
    tip.id          = id + '-tip'
    tip.textContent = texto
    document.body.appendChild(tip)

    function onEnter() {
        const rect = alvo.getBoundingClientRect()
        tip.style.display = 'block'

        let left = rect.left + rect.width / 2 - tip.offsetWidth / 2
        let top  = rect.top - tip.offsetHeight - 4

        if (left + tip.offsetWidth > window.innerWidth - 8)
            left = window.innerWidth - tip.offsetWidth - 8
        if (left < 8) left = 8
        if (top < 8)  top  = rect.bottom + 4
        if (top + tip.offsetHeight > window.innerHeight - 8)
            top = window.innerHeight - tip.offsetHeight - 8
        if (top < 8)  top  = 8

        tip.style.left = left + 'px'
        tip.style.top  = top  + 'px'
    }
    function onLeave() { tip.style.display = 'none' }

    alvo.addEventListener('mouseenter', onEnter)
    alvo.addEventListener('mouseleave', onLeave)

    // Limpa o tip se o alvo for removido do DOM
    const observer = new MutationObserver(() => {
        if (!document.body.contains(alvo)) {
            tip.remove()
            observer.disconnect()
        }
    })
    observer.observe(document.body, { childList: true, subtree: true })

    return {
        atualizar: (novoTexto) => { tip.textContent = novoTexto },
        remover:   () => {
            alvo.removeEventListener('mouseenter', onEnter)
            alvo.removeEventListener('mouseleave', onLeave)
            tip.remove()
            observer.disconnect()
        },
    }
}

function criaBotaoFechar({id, ancestral, elementoFechar, esconder = false}){
    let botao = criaBotaoAzul({
        id: id,
        ancestral: ancestral,
        texto: '✕',
        acao: () => {
            fechar(elementoFechar)
            return
        }
    })
    botao.style.padding = '0px 4px'
    botao.style.width = 'fit-content'
    botao.style.height = 'fit-content'
    function fechar(elementoFechar){
        if (esconder){
            let elemento = document.getElementById(elementoFechar)
            if (elemento) elemento.style.display = 'none'
            return
        }
        document.getElementById(elementoFechar)?.remove()
        return
    }
    return botao
}

/**
 * Cria plaquinha colorida com tooltip embutido.
 * (agora delega o tooltip para criaTooltip)
 */
function criaPlaquinhaComTooltip({ id, texto = '', cor = 'azul', tooltip = '', ancestral }) {
    const CORES_PLAQUINHA = {
        azul:    { bg: '#90caf9', borda: '#1e88e5', texto: '#03071e' },
        laranja: { bg: '#e65100', borda: '#ffa726', texto: '#fff3e0' },
        vermelho:{ bg: '#780000', borda: '#c1121f', texto: '#fdf0d5' },
        amarelo: { bg: '#ffd500', borda: '#fdc500', texto: '#03071e' },
        verde:   { bg: '#386641', borda: '#6a994e', texto: '#e8f5e9' },
    }
    const c = CORES_PLAQUINHA[cor] || CORES_PLAQUINHA.azul

    const wrapper = _ui_el('span', {
        position:     'relative',
        display:      'inline-block',
        marginRight:  '4px',
        marginBottom: '4px',
    })
    wrapper.id = id + '-wrapper'

    const plaquinha = _ui_el('span', {
        display:       'inline-block',
        background:    c.bg,
        border:        '1px solid ' + c.borda,
        borderRadius:  '4px',
        padding:       '2px 8px',
        fontSize:      '11px',
        fontWeight:    '700',
        color:         c.texto,
        fontFamily:    "var(--extensao-rotapje-fonte)",
        whiteSpace:    'normal',
        letterSpacing: '0.02em',
        cursor:        'default',
    })
    plaquinha.id          = id
    plaquinha.textContent = texto

    wrapper.appendChild(plaquinha)
    if (ancestral) _ui_inserir(wrapper, ancestral)

    const { atualizar } = criaTooltip({ id, texto: tooltip, elemento: plaquinha })
    wrapper.atualizarTooltip = atualizar

    return wrapper
}

// ── await criaSecaoMostraRecolhe ────────────────────────────────────
//
// Seção expansível com cabeçalho fixo e corpo recolhível.
// A setinha (▲/▼) no canto direito do cabeçalho alterna
// o estado. Começa expandida por padrão.
//
// O roteiro popula idSempreAMostra e idRecolhe com qualquer
// componente de ui.js após a chamada, usando-os como ancestral.
//
// await criaSecaoMostraRecolhe({ id, idSempreAMostra, idRecolhe, ancestral })

async function criaSecaoMostraRecolhe({ id, idSempreAMostra, idRecolhe, ancestral, armazenarExpandido = true }) {
    const wrapper = _ui_el('div', {
        border:       '1px solid ' + UI_CORES.borda,
        borderRadius: '6px',
        // overflow:hidden removido — cortava o conteúdo e impedia o scroll do divFlutuante pai
        marginBottom: '8px',
        background:   UI_CORES.branco,
    })
    wrapper.id = id
    wrapper.classList.add('ui-clip-liberavel')

    const cabecalho = _ui_el('div', {
        display:    'flex',
        alignItems: 'center',
        padding:    '6px 8px 6px 0',
        cursor:     'pointer',
        userSelect: 'none',
        background: UI_CORES.branco,
        transition: 'background 0.15s',
    })
    cabecalho.addEventListener('mouseenter', () => cabecalho.style.background = UI_CORES.fundo)
    cabecalho.addEventListener('mouseleave', () => cabecalho.style.background = UI_CORES.branco)

    const areaFixa = _ui_el('div', { flex: '1' })
    areaFixa.id = idSempreAMostra

    const seta = _ui_el('div', {
        flexShrink:   '0',
        width:        '24px',
        textAlign:    'center',
        fontSize:     '10px',
        color:        UI_CORES.suave,
        fontFamily:   rota_ui_fonte(),
        paddingRight: '4px',
        transition:   'transform 0.2s',
    })
    seta.textContent = '▲'

    cabecalho.appendChild(areaFixa)
    cabecalho.appendChild(seta)

    const corpo = _ui_el('div', {
        borderTop:  '1px solid ' + UI_CORES.borda,
        padding:    '6px 0 4px 0',
        // overflow começa hidden; _aplicar troca para visible quando expandido
        overflow:   'hidden',
        transition: 'max-height 0.25s ease, opacity 0.2s ease',
        maxHeight:  '0',
        opacity:    '0',
    })
    corpo.id = idRecolhe
    corpo.classList.add('ui-clip-liberavel')

    // ── Estado e métodos expostos ─────────────────────────────
    let expandido = true
    if (armazenarExpandido){
        let label = id + 'estado'
        expandido = (await obterArmazenamento([label]))?.[label] ?? false
    }
    wrapper.expandido  = expandido
    wrapper.aoAlternar = null   // roteiro pode atribuir: (expandido) => { ... }

    function _aplicar(expandido) {
        wrapper.expandido = expandido
        let label = id + 'estado'
        armazenar({[label]: expandido})
        if (expandido) {
            // overflow:visible permite que o divFlutuante pai enxergue a altura real e role
            corpo.style.overflow  = 'visible'
            corpo.style.maxHeight = 'none'
            corpo.style.opacity   = '1'
            seta.textContent      = '▲'
        } else {
            corpo.style.overflow  = 'hidden'
            corpo.style.maxHeight = '0'
            corpo.style.opacity   = '0'
            seta.textContent      = '▼'
        }
    }

    wrapper.expandir  = () => _aplicar(true)
    wrapper.recolher  = () => _aplicar(false)

    cabecalho.addEventListener('click', async () => {
        _aplicar(!wrapper.expandido)
        if (typeof wrapper.aoAlternar !== 'function') return
        try {
            await wrapper.aoAlternar(wrapper.expandido)
        } catch (e) {
            console.error('[ui.js] aoAlternar falhou em ' + id, e)
        }
    })
    // ─────────────────────────────────────────────────────────

        wrapper.appendChild(cabecalho)
        wrapper.appendChild(corpo)
        _ui_inserir(wrapper, ancestral)

    _aplicar(expandido)   // sincroniza o visual com o estado guardado
    wrapper.corpo = corpo
    return wrapper
}

function rota_avisoObrigatorio(msg = '', segundos = 60) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div')
    Object.assign(overlay.style, {
      position: 'fixed', inset: '0',
      background: 'rgba(0,0,0,0.45)',
      zIndex: String(ROTA_Z.aviso),
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "var(--extensao-rotapje-fonte)",
    })

    const caixa = document.createElement('div')
    Object.assign(caixa.style, {
      background: '#fff',
      borderLeft: '4px solid #ffa726',
      borderRadius: '8px', padding: '24px 28px',
      maxWidth: '420px', width: '90%',
      boxShadow: '0 4px 24px rgba(0,0,0,0.18)',
      display: 'flex', flexDirection: 'column', gap: '12px',
      cursor: 'pointer',
    })

    const texto = document.createElement('div')
    Object.assign(texto.style, { fontSize: '14px', lineHeight: '1.5', color: '#2c3e50', whiteSpace: 'pre-wrap' })
    texto.textContent = msg

    const rodape = document.createElement('div')
    Object.assign(rodape.style, { fontSize: '12px', color: '#888', display: 'flex', justifyContent: 'space-between' })

    const instrucao = document.createElement('span')
    instrucao.textContent = 'Clique para fechar'

    const timer = document.createElement('span')
    timer.textContent = `Fechando em ${segundos}s`

    rodape.appendChild(instrucao)
    rodape.appendChild(timer)
    caixa.appendChild(texto)
    caixa.appendChild(rodape)
    overlay.appendChild(caixa)
    document.body.appendChild(overlay)

    const fechar = () => {
      clearInterval(intervalo)
      overlay.remove()
      resolve()
    }

    overlay.addEventListener('click', fechar)

    let restam = segundos
    const intervalo = setInterval(() => {
      restam--
      timer.textContent = `Fechando em ${restam}s`
      if (restam <= 0) fechar()
    }, 1000)
  })
}

async function criaVisualizadorDeDocumentos({ancestral, timeline = [], id, termos, abrir}){
    let armazenamento = await obterArmazenamento(id)
    let ordemSalva = armazenamento[id] ?? null
    let maisAntigo = false
    if (!ordemSalva) maisAntigo = ordemSalva?.maisAntigo
    let arrayTermos = [... new Set (termos.split(',').map(d => normalizar(d).trim().toLowerCase()))]
    let termosIds = arrayTermos.map(d => {
        let docs = timeline.filter(c => 
            normalizar(c.titulo).toLowerCase().includes(d) 
            || normalizar(c.tipo).toLowerCase().includes(d) 
            || c?.anexos?.some(a => normalizar(a?.titulo).toLowerCase().includes(d)) 
            || c?.anexos?.some(a => normalizar(a?.tipo).toLowerCase().includes(d))
        )
        let idDocs = docs.flatMap(b => {
            if (normalizar(b.titulo).toLowerCase().includes(d) 
                || normalizar(b.tipo).toLowerCase().includes(d)
            ) return [{id: b.id, idUnicoDocumento: b.idUnicoDocumento, titulo: b.titulo, data: b.data}]
            
            return b.anexos
                .filter(a => normalizar(a?.titulo).toLowerCase().includes(d) || normalizar(a?.tipo).toLowerCase().includes(d))
                .map(a => ({id: a.id, idUnicoDocumento: a.idUnicoDocumento, titulo: a.titulo, data: a.data, idDocumentoPai: a.idDocumentoPai}))
        })
        return {termo:d , documentos: idDocs}
    })
    let contadores = {}
    criaDiv({
        id: id,
        ancestral: ancestral
    })

    // NOVO: verifica se há algum documento em qualquer termo
    let totalDocumentos = termosIds.reduce((soma, t) => soma + t.documentos.length, 0)

    if (!totalDocumentos) {
        criaTexto({
            id: id + '_nenhumDocumentoEncontrado',
            texto: 'Nenhum documento encontrado.',
            ancestral: id
        })
        return
    }

    let idBotaoOrdem = id + '_botaoOrdem'
    let botaoOrdem = criaBotaoLaranja({
        id: idBotaoOrdem,
        texto: maisAntigo ? 'Do mais antigo para o mais novo' : 'Do mais novo para o mais antigo',
        acao: () => inverteOrdem(idBotaoOrdem),
        ancestral: id
    })
    let tabelaTermos = criaTabelaTermos(timeline, id, termosIds)
    function inverteOrdem(id){
        maisAntigo = !maisAntigo
        let botao = document.getElementById(id)
        botao.textContent = maisAntigo ? 'Do mais antigo para o mais novo' : 'Do mais novo para o mais antigo'
    }
    function criaTabelaTermos(timeline, ancestral, termosIds, quantidade = 20){
        let idGrade = id + '_gradeTipos'
        let grade = criaGrade({
            id: id + '_gradeTipos',
            ancestral: id,
        })
        grade.style.gridTemplateColumns = 'repeat(auto-fit, minmax(130px, 1fr))'
        grade.style.padding = '0px 4px 0px 4px'
        for(let termo of termosIds){
            contadores[termo?.termo] = 0
            let texto = termo?.termo.charAt(0).toUpperCase() + termo?.termo.slice(1, )
            let idBotao = id + '_' + termo?.termo.replace(/\s/g,'_')
            let quantidade = termo?.documentos.length
            if (!quantidade) {
                continue
            }
            criaBotaoTermos({
                id: idBotao,
                texto: defineTextoBotaoTermo(termo?.termo, 0, quantidade),
                tooltip: texto,
                ancestral: idGrade,
                acaoPrincipal: () => {
                    let documento = buscaProximoDocumento(termo, idBotao, maisAntigo, quantidade)
                    abrir(documento)
                },
                acaoSecundaria: () => criaTabelaDocumentos(termo?.termo)
            })
        }
    }
    function defineTextoBotaoTermo(texto, posicao, quantidade, comPosicao = true){
        if (comPosicao) return !texto.split(' ')[1] && texto.split(' ')[0].length > 8 ? (texto.charAt(0).toUpperCase() + texto.slice(1, )).split(' ')[0].slice(0, 8) + '... ' + posicao + '/' + quantidade : (texto.charAt(0).toUpperCase() + texto.slice(1, )).split(' ')[0] + ' ' + posicao + '/' + quantidade
        return !texto.split(' ')[1] && texto.split(' ')[0].length > 8 ? (texto.charAt(0).toUpperCase() + texto.slice(1, )).split(' ')[0].slice(0, 8) + '...' : (texto.charAt(0).toUpperCase() + texto.slice(1, )).split(' ')[0]
    }
    function buscaProximoDocumento(termo, idBotao, maisAntigo, quantidade){
        let objeto = (arr, chave) => arr.find(d => chave in d)?.[chave] ?? []
        let soma = maisAntigo ? -1 : 1
        let contador = contadores[termo?.termo]
        let corretor = contador === 0 && soma === -1 ? 0 : 1
        contadores[termo?.termo] = ((contador + soma + quantidade - corretor) % quantidade) + 1
        let botao = document.getElementById(idBotao + '_botaoPrincipal')
        botao.textContent = defineTextoBotaoTermo(termo?.termo, quantidade + 1 - contadores[termo?.termo], quantidade)
        console.log('%c[Rota PJE]%c termo' + JSON.stringify(termo), LOG.aviso, 'color:inherit')
        return termo?.documentos[contadores[termo?.termo] - 1]
    }
    function criaTabelaDocumentos(termo){
        let idTabela = id + '_tabelaDocumentos_' + termo.replace(/\s/g,'_')
        console.log('%c[Rota PJE]%c idTabela: ' + JSON.stringify(idTabela), LOG.info, 'color:inherit')
        let tabela = document.querySelector('[id^="' + id + '_tabelaDocumentos_' + '"]')
        if(tabela) tabela.remove()
        if(tabela && tabela.id.includes(termo.replace(/\s/g,'_'))) return
        let documentosTermos = termosIds.find(d => d.termo === termo)?.documentos ?? []
        let documentos = documentosTermos.map(d => d)
        
        /*
termosIds: [{"termo":"certidao","documentos":[{"id":"b008161","titulo":"Certidão - inexistência de depósitos"}]},{"termo":"manifestacao","documentos":[{"id":"717f22f","titulo":"Manifestação (comprovação dos recolhimentos previdenciários)"},{"id":"b5961a0","titulo":"Manifestação  MARKA"},{"id":"ac8415c","titulo":"Aud Conciliação CEJUSC"},{"id":"8a9f67d","titulo":"Manifestação (cálculos reclamada)"}]},{"termo":"documento diverso","documentos":[{"id":"717f22f","anexos":[{"titulo":"guia","data":"2025-07-07T09:28:52.211898"},{"titulo":"comprovante de pagamento","data":"2025-07-07T09:28:52.213078"}]},{"id":"b5961a0","anexos":[{"titulo":"Informa desistencia no TST","data":"2025-06-23T16:25:47.511422"}]},{"id":"8a9f67d","anexos":[{"titulo":"Luis Haroldo Ferreira - atualização de cálculo","data":"2025-03-28T19:05:18.583445"}]}]},{"termo":"peticao inicial","documentos":[{"id":"3cf565d","titulo":"Petição Inicial"}]},{"termo":"despacho","documentos":[{"id":"8993d43","titulo":"Despacho"},{"id":"ed385b7","titulo":"Despacho"},{"id":"f4322f6","titulo":"Despacho"},{"id":"8e1c338","titulo":"Despacho"},{"id":"c57e157","titulo":"Despacho"},{"id":"f72f487","titulo":"Despacho"}]}]
        */
        console.log('%c[Rota PJE]%c documentos' + JSON.stringify(documentos), LOG.info, 'color:inherit')
        let grade = criaGrade({
            id: idTabela,
            ancestral: id,
        })
        grade.style.gridTemplateColumns = 'repeat(auto-fit, minmax(130px, 1fr))'        
        grade.style.padding = '0px 4px 0px 4px'
        if (!documentos.length){
            criaTexto({
                id: id + '_naoHaDocumentos',
                texto: 'Não há documentos do tipo ' + termo.charAt(0).toUpperCase() + termo.slice(1, ),
                ancestral: idTabela
            })
        }
        for(let doc of documentos){
            let textoBotao = doc?.titulo.length > 20 ? doc?.titulo.slice(0, 20) + '...' : doc?.titulo
            
            let idBotao = id + '_' + (doc?.idUnicoDocumento) + '_botao'
            criaBotaoAzul({
                id: idBotao,
                ancestral: idTabela,
                texto: textoBotao,
                acao: () => abrir(doc)
            })
            criaTooltip({
                id: idBotao + '_tip',
                texto: doc?.titulo + '\n' + defineTextoBotaoTermo(termo, 0, 0, false) + ' - ' + 'Id ' + doc?.idUnicoDocumento + ' - ' + doc?.data.slice(8, 10) + '/' + doc?.data.slice(5, 7) + '/' + doc?.data.slice(0, 4),
                elemento: idBotao
            })
        }
    }
    function criaBotaoTermos({id, texto, ancestral, acaoPrincipal, acaoSecundaria, tooltip}){
        let divId = id
        let div = criaDiv({
            id: divId,
            ancestral: ancestral,
            rowColumn: 'row'
        })
        div.style.gap = '0px'
        div.style.padding = '0px 0px 0px 0px'
        div.style.margin = '0px'
        div.style.background = '#0078aa'
        div.style.border = '1px solid #0078aa'
        div.style.borderRadius = '5%'
        let idBotaoPrincipal = id + '_botaoPrincipal'
        let botaoPrincipal = criaBotaoAzul({
            id: idBotaoPrincipal,
            ancestral: divId,
            texto: texto,
            acao: acaoPrincipal
        })
        botaoPrincipal.style.width = '100%'
        botaoPrincipal.style.margin = '0px'
        botaoPrincipal.style.borderRadius = '0px'
        let tooltipPrincipal = criaTooltip({
            id: id + '_tooltipPrincipal',
            texto: 'Clique para mostrar o próximo documento do tipo ' + tooltip,
            elemento: idBotaoPrincipal
        })
        let idBotaoSecundario = id + '_botaoSecundario'
        let botaoSecundario = criaBotaoAzul({
            id: idBotaoSecundario,
            ancestral: divId,
            texto: '🎛️',
            acao: acaoSecundaria
        })
        botaoSecundario.style.margin = '0px'
        botaoSecundario.style.padding = '0px 4px 0px 4px'
        botaoSecundario.style.width = 'fit-content'
        botaoSecundario.style.borderRadius = '0px'
        let tooltipSecundario = criaTooltip({
            id: id + '_tooltipSecundario',
            texto: 'Clique para detalhar todos os documentos do tipo ' + tooltip,
            elemento: idBotaoSecundario
        })
    }

}

/**
 * criaWidgetDocumentos
 *
 * Monta um widget de botões para navegar documentos de uma timeline.
 *
 * @param {object}   params
 * @param {string}   params.ancestral   - id do elemento pai onde o widget será montado
 * @param {Array}    params.documentos  - array da timeline já resolvida
 * @param {Array}    params.tipos       - array de { chave, label?, opcoes? }
 *                                        se label omitido, usa chave como label
 * @param {string}   params.idPrefixo  - prefixo para compor ids internos
 * @param {Function} params.onAbrir    - callback chamado com (documento) ao clicar
 * @param {boolean}  [params.laranja=false] - true = variantes laranja, false = variantes azul
 * @param {string}   [params.modo='tipo']  - 'tipo' | 'documento' | 'tipoComCheckBox' | 'documentoComCheckBox'
 */
async function criaWidgetDocumentos({ ancestral, documentos, tipos, idPrefixo, onAbrir, laranja = false, modo = 'tipo' }) {

    // --- estado encapsulado ---
    let ordemSalva = await obterArmazenamento('armazenarCriaWidgetDocumentos')
    ordem = ordemSalva?.[idPrefixo] ?? 1
    let contadoresDocumentos = {}

    // normaliza tipos: garante que label sempre existe
    let tiposNormalizados = tipos.map(t => ({
        chave:  t.chave,
        label:  t.label ?? t.chave,
        opcoes: t.opcoes ?? null,
    }))

    // --- factory de botão conforme laranja e modo ---
    function _criaBotao(params) {
        return laranja ? criaBotaoLaranja(params) : criaBotaoAzul(params)
    }

    function _criaBotaoComCheckBox(params) {
        return laranja ? criaBotaoLaranjaComCheckBox(params) : criaBotaoAzulComCheckBox(params)
    }

    // --- botão de ordem (só nos modos por tipo) ---
    function textoOrdem() {
        return ordem === 0 ? 'Ordem: do mais novo para o mais antigo' : 'Ordem: do mais antigo para o mais novo'
    }
    if (modo === 'tipo' || modo === 'tipoComCheckBox') {
        criaBotaoLaranja({
            id:        id(idPrefixo, 'botao_ordem_documentos'),
            texto:     textoOrdem(),
            ancestral: ancestral,
            acao: () => {
                ordem = ordem === 0 ? 1 : 0
                let botao = document.getElementById(id(idPrefixo, 'botao_ordem_documentos'))
                if (botao) botao.textContent = textoOrdem()
                console.log('%c[Rota PJE]%c ordem: ' + JSON.stringify(ordem), LOG.rosa, 'color:inherit')
                armazenar({ armazenarCriaWidgetDocumentos: { [idPrefixo]: ordem } })
            }
        })
    }

    if (!documentos.length) return

    // --- despacha para o modo correto ---
    if (modo === 'tipo')                 _criaTabelaPorTipo(documentos, false)
    else if (modo === 'tipoComCheckBox') _criaTabelaPorTipo(documentos, true)
    else if (modo === 'documento')       _criaTabelaPorDocumento(documentos, false)
    else if (modo === 'documentoComCheckBox') _criaTabelaPorDocumento(documentos, true)

    // -------------------------------------------------------------------------
    // MODO tipo / tipoComCheckBox
    // -------------------------------------------------------------------------

    function _encontrarTipoNaTimeline(tipo, ondeBuscar) {
        const termos = tipo.opcoes ?? [tipo.chave]

        const bate = (titulo, tipoDoc) =>
            termos.some(termo =>
                normalizar(titulo).toLowerCase().includes(termo) ||
                normalizar(tipoDoc).toLowerCase().includes(termo)
            )

        const resultado = []

        for (const documento of ondeBuscar) {
            if (bate(documento?.titulo, documento?.tipo)) {
                resultado.push(documento)
            }
            for (const anexo of documento?.anexos ?? []) {
                if (bate(anexo?.titulo, anexo?.tipo)) {
                    resultado.push(anexo)
                }
            }
        }

        return resultado
    }

    function _criaTabelaPorTipo(docs, comCheckBox) {
        console.log('%c[Rota PJE]%c criaWidgetDocumentos docs: ' + JSON.stringify(docs), LOG.rosa, 'color:inherit')

        let documentosCriar = {}
        let elementos = 0

        for (let c of tiposNormalizados) {
            documentosCriar[c.chave] = _encontrarTipoNaTimeline(c, docs)
            if (documentosCriar[c.chave].length) elementos++
        }

        if (!elementos) return

        let colunas = elementos > 3 ? 3 : elementos
        let idGrade = id(idPrefixo, 'tabela')

        criaGrade({
            id:            idGrade,
            ancestral:     ancestral,
            numeroColunas: colunas
        })

        for (let [tipo, doc] of Object.entries(documentosCriar)) {

            if (!doc.length) continue

            let tipoDef = tiposNormalizados.find(t => t.chave === tipo || (t.opcoes && t.opcoes.includes(tipo)))
            if (!tipoDef) continue

            let chaveContador = id(idPrefixo, tipo)
            contadoresDocumentos[chaveContador] = { atual: 0, total: doc.length, primeiroClique: true }

            let idBotao    = id(idPrefixo, 'botao', tipo)
            let idCheckbox = id(idPrefixo, 'checkbox', tipo)
            let textoBotao = tipoDef.label + ' 0/' + doc.length

            let acaoBotao = async () => {
                let resultado = _avancarContadorDocumento(tipo)
                if (!resultado) return
                let { tipoContador, contador } = resultado
                console.log('%c[Rota PJE]%c onAbrir documento: ' + JSON.stringify(documentosCriar[tipoContador][contador]), LOG.rosa, 'color:inherit')
                await onAbrir(documentosCriar[tipoContador][contador])
            }

            comCheckBox
                ? _criaBotaoComCheckBox({ id: idBotao, idCheckbox, texto: textoBotao, acao: acaoBotao, ancestral: idGrade })
                : _criaBotao({ id: idBotao, texto: textoBotao, acao: acaoBotao, ancestral: idGrade })
        }
    }

    function _avancarContadorDocumento(tipo) {
        let chaveContador = id(idPrefixo, tipo)
        let contador = contadoresDocumentos[chaveContador]
        if (!contador) return null

        if (contador.primeiroClique) {
            contador.atual = ordem === 0 ? 0 : contador.total - 1
            contador.primeiroClique = false
        } else {
            if (ordem === 0) {
                contador.atual = (contador.atual + 1) % contador.total
            } else {
                contador.atual = (contador.atual - 1 + contador.total) % contador.total
            }
        }

        let idBotao = id(idPrefixo, 'botao', tipo)
        let botao = document.getElementById(idBotao)
        if (!botao) return null

        let tipoDef = tiposNormalizados.find(t => t.chave === tipo || (t.opcoes && t.opcoes.includes(tipo)))
        botao.textContent = tipoDef.label + ' ' + (contador.total - contador.atual) + '/' + contador.total

        console.log('%c[Rota PJE]%c _avancarContadorDocumento tipo: ' + JSON.stringify(tipo), LOG.rosa, 'color:inherit')
        console.log('%c[Rota PJE]%c _avancarContadorDocumento atual: ' + JSON.stringify(contador.atual), LOG.rosa, 'color:inherit')

        return { tipoContador: tipo, contador: contador.atual }
    }

    // -------------------------------------------------------------------------
    // MODO documento / documentoComCheckBox
    // -------------------------------------------------------------------------

    function _criaTabelaPorDocumento(docs, comCheckBox) {
        console.log('%c[Rota PJE]%c criaWidgetDocumentos por documento docs: ' + JSON.stringify(docs), LOG.rosa, 'color:inherit')

        let elementos = docs.length
        if (!elementos) return

        let colunas = elementos > 3 ? 3 : elementos
        let idGrade = id(idPrefixo, 'tabela')

        criaGrade({
            id:            idGrade,
            ancestral:     ancestral,
            numeroColunas: colunas
        })

        for (let documento of docs) {
            let docId     = documento.idUnicoDocumento
            let tipoDef   = tiposNormalizados.find(t =>
                t.chave === documento?.tipo ||
                (t.opcoes && t.opcoes.includes(documento?.tipo))
            )
            let labelTipo  = tipoDef?.label ?? documento?.tipo ?? documento?.titulo ?? docId
            let textoBotao = labelTipo + ' - ' + docId

            let idBotao    = id(idPrefixo, 'botao', docId)
            let idCheckbox = id(idPrefixo, 'checkbox', docId)

            let acaoBotao = async () => {
                console.log('%c[Rota PJE]%c onAbrir documento: ' + JSON.stringify(documento), LOG.rosa, 'color:inherit')
                await onAbrir(documento)
            }

            comCheckBox
                ? _criaBotaoComCheckBox({ id: idBotao, idCheckbox, texto: textoBotao, acao: acaoBotao, ancestral: idGrade })
                : _criaBotao({ id: idBotao, texto: textoBotao, acao: acaoBotao, ancestral: idGrade })
        }
    }
}

function formataDiv(div, cor = 'branco', largura = '80%', altura = '80%', position = 'absolute', top = '50%', left = '50%', transform = 'translate(-50%, -50%)') {
    let bgCor = cor.includes('#') ? cor : UI_CORES[cor] || UI_CORES.branco
    Object.assign(div.style,{
        position:       position,
        top:            top,
        left:           left,
        transform:      transform,
        width:          largura,
        height:         altura,
        background:     bgCor,
        border:         '1px solid ' + UI_CORES.azul,
        borderRadius:   '8px',
        boxShadow:      '0 4px 16px rgba(0,0,0,0.15)',
        zIndex:         String(ROTA_Z.flutuante ?? 9000),
        display:        'flex',
        padding:        '4px 4px 4px 4px'
    })
    return div
}

function apresentaResultados({array, nome, ancestral = document.body, embutido = false, aoVoltar = null, baixarResultadoBruto = null}){
    let divId = id(nome)
    let div = criaDiv({
        id: divId,
        ancestral: ancestral
    })
    Object.assign(div.style, {
        background:     UI_CORES.branco,
        border:         '1px solid ' + UI_CORES.azul,
        borderRadius:   '8px',
        boxShadow:      '0 4px 16px rgba(0,0,0,0.15)',
        display:        'flex',
        padding:        '4px 4px 4px 4px',
        ...(embutido ? {
            position:     'relative',
            width:        '98%',
            flex:         '1 1 auto',
            minHeight:    '0',
            marginBottom: '0'
        } : {
            position:   'absolute',
            top:        '50%',
            left:       '50%',
            transform:  'translate(-50%, -50%)',
            width:      '80%',
            height:     '80%',
            zIndex:     String(ROTA_Z.flutuante ?? 9000)
        })
    })
    
    let divTitulo = criaDiv({
        id: id(nome, 'divTitulo'),
        ancestral: divId,
        rowColumn: 'row'
    })
    let titulo = criaTitulo({
        id: id(nome, 'titulo'),
        texto: 'Resultado',
        ancestral: id(nome, 'divTitulo')
    })
    if (!embutido) {
        let botaoFechar = criaBotaoAzul({
            id: id(nome, 'fechar'),
            texto: '✕',
            ancestral: id(nome, 'divTitulo'),
            acao: () => {
                document.getElementById(divId).remove()
                return
            }
        })
        botaoFechar.style.height =          '15px'
        botaoFechar.style.fontSize =        '13px'
        botaoFechar.style.lineHeight =      '1'
        botaoFechar.style.padding =         '2px 5px'
        botaoFechar.style.borderRadius =    '4px'
        botaoFechar.style.position =        'fixed'
        botaoFechar.style.right =           '4px'
    }
    let divLinhas = criaDiv({
        id: id(nome, 'linhas'),
        ancestral: divId
    })
    divLinhas.style.overflowY = 'auto'
    let i = 0
    for (i; i < array.length; i++){
        if (i === 0){
            let primeiraLinha = criaDiv({
            id: id(nome, 'linha' + i),
            ancestral: id(nome, 'linhas'), 
            rowColumn: 'row'
        })
        }
        let linha = criaDiv({
            id: id(nome, 'linha' + (i + 1)),
            ancestral: id(nome, 'linhas'), 
            rowColumn: 'row'
        })
        let objeto = array[i]
        for(let j = 0 ; j < Object.entries(objeto).length; j++){
            
            let largura = Math.floor(100/Object.entries(objeto).length)
            if (i === 0){
                let celula = criaSubTitulo({
                    id: id(nome, 'linhaCabecalho' + i, 'celula' + j),
                    ancestral: id(nome, 'linha' + i),
                    texto: Object.keys(objeto)[j]
                })
                celula.style.width = largura + '%'
                celula.style.whiteSpace = 'pre-wrap'
            }
            
            let celula = criaTexto({
                id: id(nome, 'linha' + i, 'celula' + j),
                ancestral: id(nome, 'linha' + (i + 1)),
                texto: Object.values(objeto)[j]
            })
            
            celula.style.width = largura + '%'
            
        }
    }
    i++
    let linhaFinal = criaDiv({
        id: id(nome, 'linha' + i),
        ancestral: divId, 
        rowColumn: 'row'
    })
    //linhaFinal.style.
    let botoesFinais = [
        {
            id: id(nome, 'copiar'),
            texto: 'Copiar dados tabulados',
            ancestral: id(nome, 'linha' + i),
        },
        {
            id: id(nome, 'baixarTexto'),
            texto: 'Baixar em formato TXT',
            ancestral: id(nome, 'linha' + i),
        },
        {
            id: id(nome, 'baixarJSON'),
            texto: 'Baixar em formato JSON',
            ancestral: id(nome, 'linha' + i),
        },
        {
            id: id(nome, 'baixarResultadoBrutoFuncao'),
            texto: 'Baixar resultado Bruto',
            ancestral: id(nome, 'linha' + i),
        },
    ]
    for (let k = 0; k < botoesFinais.length; k++) {
        let botaoConfig = botoesFinais[k]
        if (!baixarResultadoBruto && botaoConfig.id.includes('baixarResultadoBruto')) continue
        let funcaoBotao = k % 2 === 0 ? criaBotaoAzul : criaBotaoLaranja
        funcaoBotao({
            id: botaoConfig.id,
            texto: botaoConfig.texto,
            ancestral: botaoConfig.ancestral,
            acao: () => extrairResultado(botaoConfig.id)
        })
    }
    if (aoVoltar){
        criaBotaoLaranja({
            id: id(nome, 'voltar'),
            texto: 'Nova análise',
            ancestral: id(nome, 'linha' + i),
            acao: aoVoltar
        })
    }

    // ── Exportação — usam o `array` recebido por apresentaResultados,
    //    não o que já foi renderizado na tela ─────────────────────
    function extrairResultado(tipo){
        let nomeFuncao = tipo.split('_').pop()
        let funcoes = { copiar, baixarJSON, baixarTexto, baixarResultadoBrutoFuncao }
        funcoes[nomeFuncao]?.()

        function copiar(){
            navigator.clipboard.writeText(arrayParaTsv(array))
        }

        function baixarTexto(){
            _baixarArquivo(arrayParaTsv(array), 'resultado.txt', 'text/plain')
        }

        function baixarJSON(){
            _baixarArquivo(JSON.stringify(array, null, 2), 'resultado.json', 'application/json')
        }
        function baixarResultadoBrutoFuncao(){
            _baixarArquivo(JSON.stringify(baixarResultadoBruto, null, 2), 'resultado.json', 'application/json')
        }
    }
}


function criaDivCentralPadrao({id, ancestral = document.body, titulo = '', cor = 'branco', largura = '80%', altura = '80%', position = 'absolute', top = '50%', left = '50%', transform = 'translate(-50%, -50%)'}){
    let div = criaDiv({
        id: id,
        ancestral: ancestral
    })
    formataDiv(div, cor, largura, altura, position, top, left, transform)
    let cabecalho = criaDiv({
        id: id + '_cabecalho',
        ancestral: id,
        rowColumn: 'row-reverse'
    })
    cabecalho.style.marginBottom = '0px'
    criaBotaoFechar({
        id: id + '_fechar',
        ancestral: id + '_cabecalho',
        elementoFechar: id
    })
    let tituloEl = criaTitulo({
        id: id + '_fechar',
        ancestral: id + '_cabecalho',
        texto: titulo
    })
    tituloEl.style.width = '100%'
    let corpo = criaDiv({
        id: id + '_corpo',
        ancestral: id,
    })
    corpo.style.marginBottom = '0px'
    corpo.style.height = '100%'
    let rodape = criaDiv({
        id: id + '_rodape',
        ancestral: id,
    })
    rodape.style.marginBottom = '0px'
    div.corpo = corpo
    div.cabecalho = cabecalho
    div.rodape = rodape
    return div
}