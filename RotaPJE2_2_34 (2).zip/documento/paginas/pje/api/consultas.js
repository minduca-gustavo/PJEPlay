// ============================================================
// api/consultas.js
// Camada de requisição às APIs do PJe usada pelo Rota.
//
// Substitui rota/modulos/navegador.js. O que era genérico saiu
// daqui e vem de modulos/: cookie_obter() no lugar de
// rota_cookie(), criarChaveDeIdempotencia() no lugar de
// rota_idempotencia(), url_parametro_obter() onde a URL é comum,
// extensao_raiz(), armazenar(), relatar().
// ============================================================


/**
 * Token XSRF do PJe, lido dos cookies pelo módulo do SISE.
 */
function rota_token(){
	return cookie_obter('Xsrf-Token') || cookie_obter('XSRF-TOKEN')
}


/**
 * Lê parâmetro tanto da query quanto do hash.
 * url_parametro_obter() (modulos/url.js) só lê da query; o PJe
 * usa hash em várias telas, por isso a variante fica aqui.
 */
function rota_buscarParametros(nome = ''){
	return url_parametro_obter(nome)
		|| new URLSearchParams(location.hash.split('?')[1] ?? '').get(nome)
		|| null
}


function rota_cabecalhos(aceita = 'application/json, text/plain, */*'){
	return {
		'Idempotency-Key':  criarChaveDeIdempotencia(),
		'X-Grau-Instancia': CONFIGURACAO?.pessoa?.instancia || '1',
		'X-XSRF-TOKEN':     rota_token(),
		'Content-Type':     'application/json',
		'Accept':           aceita,
	}
}

// Faz a requisição com o mesmo tratamento de erro, mas devolve a Response crua
async function rota_fetchBruto(url = '', opcoes = {}) {
	try {
		relatar('GET ' + url, '', 'requisicao')
		let r = await fetch(url, {
			method: 'GET', mode: 'cors', credentials: 'include',
			...opcoes
		})
		if (!r.ok) { relatar('HTTP ' + r.status, url, 'erro'); return null }
		return r
	} catch (e) { relatar('fetch erro: ' + e.message, url, 'erro'); return null }
}

// rota_fetch passa a ser só "bruto + json", com o mesmo comportamento de antes
async function rota_fetch(url = '') {
	let r = await rota_fetchBruto(url, { headers: rota_cabecalhos() })
	if (!r) return null
	try {
		let dados = await r.json()
		relatar('Resposta de ' + url, dados, 'resposta')
		return dados
	} catch (e) { relatar('json inválido: ' + e.message, url, 'erro'); return null }
}



async function rota_fetchPost(url = '', body){
	try{
		relatar('POST ' + url, '', 'requisicao')
		let r = await fetch(url, {
			method: 'POST', mode: 'cors', credentials: 'include',
			headers: rota_cabecalhos(),
			body: body
		})
		if(!r.ok){ relatar('HTTP ' + r.status, url, 'erro'); return null }
		let dados = await r.json()
		relatar('Resposta de ' + url, dados, 'resposta')
		return dados
	} catch(e){ relatar('fetch erro: ' + e.message, url, 'erro'); return null }
}


async function post(url, corpo){
	relatar('POST (com corpo) ' + url, corpo, 'requisicao')
	return fetch(url, {
		method: 'POST',
		mode: 'cors',
		credentials: 'include',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json, text/plain, */*',
			'X-XSRF-TOKEN': rota_token(),
		},
		body: JSON.stringify(corpo)
	})
}

async function buscarSegundoGrau(id) {
	const url = location.origin + '/pje-consulta-api/api/processos/' + id
	const tk1g = document.cookie.match(/(?:^|;\s*)access_token_1g=([^;]+)/)?.[1]
	try {
		relatar('GET ' + url, '', 'requisicao')
		let r = await fetch(url, {
			method: 'GET', mode: 'cors', credentials: 'include',
			headers: {
				...rota_cabecalhos(),
				'X-Grau-Instancia': '2',
				...(tk1g && { 'Authorization': 'Bearer ' + tk1g })
			}
		})
		if (!r.ok) { relatar('HTTP ' + r.status, url, 'erro'); return null }
		let dados = await r.json()
		relatar('Resposta de ' + url, dados, 'resposta')
		return Array.isArray(dados) ? (dados[0] || null) : dados
	} catch (e) { relatar('fetch erro: ' + e.message, url, 'erro'); return null }
}

async function buscarSegundoGrauBasicos(numero) {
	const url = location.origin + '/pje-consulta-api/api/processos/dadosbasicos/' + encodeURIComponent(numero)
	try {
		relatar('GET ' + url, '', 'requisicao')
		let r = await fetch(url, {
			method: 'GET', mode: 'cors', credentials: 'include',
			headers: { ...rota_cabecalhos(), 'X-Grau-Instancia': '2' }
		})
		if (!r.ok) { relatar('HTTP ' + r.status, url, 'erro'); return [] }
		console.log('%c[Rota PJE]%c r 119: ' + JSON.stringify(r), LOG.info, 'color:inherit')
		let dados = await r.json()
		console.log('%c[Rota PJE]%c dados 119: ' + JSON.stringify(dados), LOG.info, 'color:inherit')
		relatar('Resposta de ' + url, dados, 'resposta')
		return Array.isArray(dados) ? dados : (dados ? [dados] : [])
	} catch (e) { relatar('fetch erro: ' + e.message, url, 'erro'); return [] }
}

async function rota_download(url = ''){
	try{
		relatar('DOWNLOAD ' + url, '', 'requisicao')
		let r = await fetch(url, {
			method: 'GET', mode: 'cors', credentials: 'include',
			headers: {
				'Idempotency-Key':  criarChaveDeIdempotencia(),
				'X-Grau-Instancia': CONFIGURACAO?.pessoa?.instancia || '1',
				'X-XSRF-TOKEN':     rota_token(),
				'Accept':           '*/*',
			}
		})
		if(!r.ok){ relatar('HTTP ' + r.status, url, 'erro'); return null }
		return await r.blob()
	} catch(e){ relatar('download erro: ' + e.message, url, 'erro'); return null }
}


function rota_blobParaBase64(blob){
    return new Promise((resolve, reject) => {
        let leitor = new FileReader()
        leitor.onload = () => resolve(String(leitor.result).split(',')[1] || '')
        leitor.onerror = () => reject(leitor.error)
        leitor.readAsDataURL(blob)
    })
}