pdfjs.mjs e pdfjs.worker.mjs são distribuições pré-compiladas oficiais
do PDF.js (Mozilla Foundation), não modificadas.

Versão: X.X.X
Fonte: https://mozilla.github.io/pdf.js/
Download: https://github.com/mozilla/pdf.js/releases

Estes arquivos são bibliotecas de terceiros de código aberto (licença Apache 2.0)
e não foram produzidos pelo desenvolvedor desta extensão.