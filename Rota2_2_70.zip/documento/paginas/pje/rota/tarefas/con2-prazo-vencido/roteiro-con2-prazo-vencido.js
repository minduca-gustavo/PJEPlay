// dá problema quando o interceptador dá errado, ou seja, quando não tem gigs concluídos, por exemplo.
// o domicilio eletronico é outra api.
//     ?rotapje_tarefa=_



const dadosCon2PrazoVencido = {
    solucao: null,
    partes: null,
    processo: null,
    gig: null,
    salas: null,
    salaJuizes: null,
    horariosVagosPorSala: null,
    juizSimetriaPeloGig: null,
    peticaoInicialId: null,
    execucaoAtual: null,
    origin: location.origin,
    tarefaMaisRecente: null,
    recursos: null,
    
}
//__________________________________________________
//                      FUNÇÃO INICIAL
//__________________________________________________
async function con2_prazo_vencido_aoAbrirDetalhesDoProcesso(){
    let tarefa = 'con2_prazo_vencido'
    let janela = confereJanela(JANELA.detalhes)
    if (!janela) return
    let armazenamento = await obterArmazenamento(['rotaExecucaoAtual'])
    if (!armazenamento) return
    let execucao = String(armazenamento?.rotaExecucaoAtual || '')
    if (!execucao) return
    let tarefaParam = rota_buscarParametros('rotapje_tarefa')
    if (tarefaParam && !window.name.includes(tarefa)) window.name = window.name + '-' + tarefaParam + '-' + execucao
    if (!window.name.includes('rota') || !window.name.includes(tarefa)) return
    if (execucao !== window.name.split('-').pop()) return
    dadosCon2PrazoVencido.execucaoAtual = execucao
    NAVEGADOR.storage.onChanged.addListener(obedecer)
    await con2_prazo_vencido_janelaDetalhes(execucao)
}

//__________________________________________________
//                      DETALHES DO PROCESSO 
//__________________________________________________

async function con2_prazo_vencido_janelaDetalhes(sessao){
    await aguardarElemento('pje-descricao-processo .mat-tooltip-trigger')
    await suspender (500)
    if (!document.querySelector('.texto-tarefa-processo')){
        await aguardarElemento('#rotapje-irParaAOJDesteProcesso_botao')
        clicar('#rotapje-irParaAOJDesteProcesso_botao')
    }
    await con2_prazo_vencido_enviarParaRoteiroAssistente()
    let executar = await obterArmazenamento(['rota_con2_prazo_vencido_janelaDetalhes'])
    if (executar.rota_con2_prazo_vencido_janelaDetalhes === sessao) return
    await rota_aguardarElemento('.tl-documento')
    let documentos = [...document.getElementsByClassName('tl-documento')]
    let sentenca = documentos.filter(p => p.textContent.includes('Sentença('))
    if (!sentenca.length) return
    console.log('%c[Rota PJE]%c sentenca' + JSON.stringify(sentenca), LOG.rosa, 'color:inherit')
    clicar(sentenca[0])
    sentenca[0].scrollIntoView({ block: 'nearest' })
    await armazenar({rota_con2_prazo_vencido_janelaDetalhes: sessao})
    await removerArmazenamento('rotapje_tarefa')
}

//__________________________________________________
//        OBTER DADOS E ENVIAR PARA ROTEIRO ASSISTENTE
//__________________________________________________

async function con2_prazo_vencido_enviarParaRoteiroAssistente(){
    // OBTENDO SOLUÇÕES
    let idURLMatch = location.href.match(/\/processo\/(\d+)\/detalhe/);
    let idURL = idURLMatch?.[1]; // "2992885"
    let movimentos = await buscarMovimentos(idURL) || null
    let solucaoMovimento = null
    let solucao = []
    let solucoesPossiveis = ['Julgado(s)', 'Extinto', 'Arquivado o processo', 'Não acolhidos']
    if (movimentos) {
        solucaoMovimento = movimentos.filter(m=> solucoesPossiveis.some(d=> m?.titulo.includes(d))) || null
    }
    let dataSolucaoMaisAntiga = new Date()
    console.log('%c[Rota PJE]%c solucaoMovimento: ' + JSON.stringify(solucaoMovimento), LOG.rosa, 'color:inherit')
    for (let mov of solucaoMovimento) {
        let {data} = mov
        dataSolucaoMaisAntiga = new Date(data) < dataSolucaoMaisAntiga ? new Date(data) : dataSolucaoMaisAntiga
        let movimento = ''
        if (mov?.titulo.includes('Julgado(s) ')){
            movimento = (mov?.titulo.split('Julgado(s) ')[1])
                .replace("o(s) pedido(s) (", "- ")
                .replaceAll(')', '')
                .replaceAll('(', '')
                .replaceAll('/', '')
                .replaceAll(/\d*/g, '')
                .replace(/\s+/g, ' ')
                .trim().toUpperCase()
        } else {
            movimento = mov?.titulo
        }
        solucao.push({movimento, data: new Date(data).toLocaleDateString()})
    }
    console.log('%c[Rota PJE]%c solucao: ' + JSON.stringify(solucao), LOG.rosa, 'color:inherit')
    
    console.log('%c[Rota PJE]%c movimentos: ' + JSON.stringify(movimentos), LOG.rosa, 'color:inherit')
    let [timeline, processo, recursos] = await Promise.all([
        interceptador_aguardar('timeline').then(() => interceptador_lerTimeline() || []),
        interceptador_aguardar('processo').then(() => interceptador_lerProcesso() || {}),
        interceptador_aguardar('recursos').then(() => interceptador_lerRecursos() || {}),
    ])
    let idBusca = processo.id || idURL
    if (!idBusca) return
    let partes = await buscarProcesso(idBusca, '/partes?retornaEndereco=true') || []
    let buscaExpedientes = await buscarProcesso(idBusca, '/expedientes?pagina=1&tamanhoPagina=1000&instancia=1') || {}
    let expedientes = buscaExpedientes?.resultado.filter(d => new Date(d.fimDoPrazoLegal) > dataSolucaoMaisAntiga)
    movimentos = movimentos?.filter(d => new Date(d.data) > dataSolucaoMaisAntiga)
    console.log('%c[Rota PJE]%c dataSolucaoMaisAntiga' + JSON.stringify(dataSolucaoMaisAntiga), LOG.aviso, 'color:inherit')
    console.log('%c[Rota PJE]%c expedientes' + JSON.stringify(expedientes), LOG.aviso, 'color:inherit', expedientes)
    
    dadosCon2PrazoVencido.solucao       = solucao
    dadosCon2PrazoVencido.movimentos    = movimentos
    dadosCon2PrazoVencido.timeline      = timeline
    dadosCon2PrazoVencido.partes        = partes
    dadosCon2PrazoVencido.processo      = processo
    dadosCon2PrazoVencido.recursos      = recursos
    dadosCon2PrazoVencido.expedientes   = expedientes
    
    await armazenar({ rota_dadosCon2PrazoVencido: dadosCon2PrazoVencido })
    await armazenar({ rota_dadosCon2PrazoVencidoNumero: processo.numero })
    await armazenar({ rota_dadosProntos: true })
}

//__________________________________________________
//                      ABRIR DOCUMENTOS
//__________________________________________________

async function con2_prazo_vencido_abrirDocumentos(documento) {
    let confereExecucao = await execucaoAtualConferencia()
    if (!confereExecucao) return
    // Tenta pelo idUnicoDocumento (documento raiz)
    let botao = selecionar('[id="anexo_' + documento.id + '"]')
    console.log('%c[Rota PJE]%c botao 125: ' + JSON.stringify(botao.textContent), LOG.rosa, 'color:inherit')
    if (!botao) {
        // Tenta pelo id simples (anexo com pai já expandido)
        botao = selecionar('[id="abrirdoc_' + documento.idUnicoDocumento + '"]')
        console.log('%c[Rota PJE]%c botao.textContent 126: ' + JSON.stringify(botao.textContent), LOG.rosa, 'color:inherit')
    }

    if (!botao) {
        // Pai não expandido — abre o pai primeiro
        let pai = selecionar('#doc_' + documento.idDocumentoPai)
        console.log('%c[Rota PJE]%c pai.textContent 125: ' + JSON.stringify(pai.textContent), LOG.rosa, 'color:inherit')
        if (!pai) {
            rota_avisoObrigatorio('Documento não encontrado.', 5)
            console.log('%c[Rota PJE]%c 138: ' + JSON.stringify(138), LOG.rosa, 'color:inherit')
            return
        }
        let botaoPai = selecionar('.botao-anexos', pai)
        console.log('%c[Rota PJE]%c botaoPai.textContent 125: ' + JSON.stringify(botaoPai.textContent), LOG.rosa, 'color:inherit')
        if (!botaoPai) {
            rota_avisoObrigatorio('Documento não encontrado.', 5)
            console.log('%c[Rota PJE]%c 139: ' + JSON.stringify(139), LOG.rosa, 'color:inherit')
            return
        }
        clicar(botaoPai)
        await rota_aguardarElemento('[id$="' + documento.id + '"]')
        botao = selecionar('[id$="' + documento.id + '"]')
    }
    console.log('%c[Rota PJE]%c botao.textContent 125: ' + JSON.stringify(botao.textContent), LOG.rosa, 'color:inherit')
    clicar(botao)
    rota_avisoTemporario(JSON.stringify(documento.idUnicoDocumento), '', 4000)
}

//__________________________________________________
//                      RETIFICAR
//__________________________________________________

// RETIFICAR PASSO 1 - recebe os dados e abre a tela de retificação

async function con2_prazo_vencido_retificarAutuacao(tipo) {
    let envio = tipo.tipo
    await armazenar({
        'rotapje_con2_prazo_vencido_retificar': dadosCon2PrazoVencido.execucaoAtual,
        'rotapje_con2_prazo_vencido_retificar_tipo': envio,
    })
    let parametros = '?rotapje_con2_prazo_vencido_retificar=' + dadosCon2PrazoVencido.execucaoAtual + 
                    '&rotapje_con2_prazo_vencido_retificar_tipo=' + envio
    let nomeJanela = 'rotapje_con2_prazo_vencido_retificar_' + dadosCon2PrazoVencido.execucaoAtual
    let id = dadosCon2PrazoVencido?.processo?.id
    let url = location.origin + '/pjekz/processo/' + id + '/retificar' + parametros
    await abrirUrl(url, 'esquerdaAssistida', nomeJanela)
    //await alert(tipo + ' em desenvolvimento. ' + id)
}

// RETIFICAR PASSO 2 - verifica se a janela aberta é a da extensão

async function con2_prazo_vencido_aoAbrirRetificar(){
    let janela = confereJanela(JANELA.retificar)
    if (!janela) return
    let parametros = await rota_buscarParametros('rotapje_con2_prazo_vencido_retificar')
    if (!parametros) return
    let armazenamento = await obterArmazenamento('rotapje_con2_prazo_vencido_retificar')
    if (!armazenamento) return
    let execucao = armazenamento?.rotapje_con2_prazo_vencido_retificar
    let nomeJanela = window.name
    if (!nomeJanela.includes('rotapje_con2_prazo_vencido_retificar')) return
    if(execucao !== parametros || execucao !== nomeJanela.split('_').pop()) return
    registrarListenerFechar(execucao)
    await con2_prazo_vencido_acoesRetificar()
}

// RETIFICAR PASSO 3 - executa as ações

async function con2_prazo_vencido_acoesRetificar(){
    let tipos = await obterArmazenamento(['rotapje_con2_prazo_vencido_retificar_tipo']) || await rota_buscarParametros('rotapje_con2_prazo_vencido_retificar_tipo')
    if (!tipos) return
    let tipo = tipos?.rotapje_con2_prazo_vencido_retificar_tipo ?? tipos
    let i = 0
    let elemento = null
    while (!elemento) {
        i++
        if (i > 10) break
        let elementos = [...await sel('retificacaoAutuacaoPrimeirosBotoes', '', true)]
        elemento = elementos.find(e => e.textContent.includes(tipo))
        if (!elemento) await suspender(1000)
    }
    if (!elemento) return
    clicar(elemento)
}

// _________________________________________________
//                   PROCESSAR RECURSO
// _________________________________________________

// PROCESSAR PASSO 1 - recebe os dados e abre a tela de tarefa

async function con2_prazo_vencido_processarRecursos(recursos) {
    let confereExecucao = await execucaoAtualConferencia()
    if (!confereExecucao) return
    if (!confereSetor('CON2', 'Vara do trabalho')) {
        rota_avisoObrigatorio('Esta funcionalidade deve ser executada em processos que estão na CON2, ou na Vara.', 5)
        return
    }
    let idURL = location.href.match(/processo\/(\d+)\/detalhe/)
    let id = idURL[1]
    /*
    [{"marcado":false,"idUnicoDocumento":"4caf1df","idSignatario":239515},
    {"marcado":false,"idUnicoDocumento":"cf1e595","idSignatario":33408}]
    */
    let recorrentes = []
    for (let recurso of recursos){
        let {marcado, idUnicoDocumento, idSignatario} = recurso
        let url = location.origin + '/pje-comum-api/api/processos/id/' + id + '/partes/representadas?idRepresentante=' + idSignatario
        let recorrente = await rota_fetch(url) || []
        recorrentes.push({...recurso, recorrente})
    }
    let chave = idg('con2', 'prazoVencido', 'processar')
    await armazenar({[chave]: {recorrentes, confereExecucao}})
    let urlInicio = await definirURLDaTarefa(id) || ''
    if (!urlInicio) {
        rota_avisoObrigatorio('Ocorreu um erro. Atualize a página e tente novamente.', 5)
        return
    }
    let url = urlInicio + '?' + chave + '=' + confereExecucao
    let nomeJanela = chave + '_' + confereExecucao
    await abrirUrl(url, 'esquerdaAssistida', nomeJanela)
}

// DESPACHAR PASSO 2 - verifica se a janela aberta é a da extensão
async function con2_prazo_vencido_aoAbrirDespachar(){
    let janela = confereJanela(JANELA.processoTarefa)
    if (!janela) return
    let chave = idg('con2', 'prazoVencido', 'processar')
    let armazenamento = await obterArmazenamento(chave)
    if (!armazenamento) return
    let dados = armazenamento[chave] || null
    if (!dados) return
    let execucao = String(dados?.confereExecucao || '')
    let nomeJanela = window.name
    if (!nomeJanela.includes(execucao)) return
    if(execucao !== nomeJanela.split('_').pop()) return
    registrarListenerFechar(execucao)
    await con2_prazo_vencido_acoesDespachar(dados?.recorrentes)
}

// DESPACHAR PASSO 3 - executa as ações

async function con2_prazo_vencido_acoesDespachar(recursos){
    let movimentos = []
    let recorrente = []
    let preparo = ''
    let recursosProcessar = recursos.filter(d => d?.marcado && !d?.naoProcessar)
    let tipos = [
        {
            label: 'recurso ordinario (69)',
            nome: 'Recurso Ordinário'
        },
        {
            label: 'recurso adesivo (63)',
            nome: 'Recurso Adesivo'
        },
    ]
    console.log('%c[Rota PJE]%c recursosProcessar: ', LOG.info, 'color:inherit', recursosProcessar)
    for (let recurso of recursosProcessar){
        let tipo = tipos.find(d => d.nome == recurso.tipo)?.label
        recorrente.push('id ' + recurso.idUnicoDocumento + ',  por ' + recurso.recorrente[0]?.nome + ', ' + recurso.participacaoProcesso?.split(',')[0].trim().toLowerCase())
        movimentos.push({checkbox: {incluir: 'recebido', naoIncluir: 'nao'}, opcoes: [{nomeDoCampo: 'nome do recurso', selecionar: tipo}, {nomeDoCampo: 'nome da parte', selecionar: recurso.recorrente[0]?.nome}]})
    }
    if (recursosProcessar.some(d => d.preparo == 'recolhidas')){
        preparo = 'Regular a representação, recolhidas as custas e efetivado o depósito recursal.'
    } else if (recursosProcessar.some(d => d.preparo == 'dispensadas') && !recursosProcessar.some(d => d.preparo == 'recolhidas')){
        preparo = 'Regular a representação, custas e depósito recursal dispensados.'
    } else {
        preparo = 'Regular a representação.'
    }
    let textoProcessar = `<p>Pressupostos extrínsecos:</p>
<p>O(s) recurso(s) interposto(s), ` + recorrente.join(', ') + `, é(são) tempestivo(s).</p>
<p>` + preparo + `</p>
<p>Pressupostos intrínsecos:</p>
<p>Todas as matérias debatidas preenchem o requisito de admissibilidade.</p>
<p>Apresente(m) o(s) recorrido(s) contrarrazões no prazo legal e, após, remetam-se os autos ao segundo grau.</p>
<p>Intimem-se ainda os patronos das partes para que efetuem, se for o caso, seu cadastramento junto ao sistema PJe na 2ª instância.</p>
`
    let recursosDenegar = recursos.filter(d => !d?.marcado && !d?.naoProcessar)
    let recorrenteDenegar = []
    let motivo = []
    for (let recurso of recursosDenegar){
        let tipo = tipos.find(d => d.nome == recurso.tipo)?.label
        if (recurso.intempestivo){
            motivo.push('intempestivo')
        }
        if (recurso.custasAusentes){
            motivo.push('ausente o pagamento das custas')
        }
        if (recurso.depositoAusente){
            motivo.push('ausente a comprovação do depósito recursal/seguro fiança')
        }
        if (recurso.alcada){
            motivo.push('de alçada exclusiva de Vara do Trabalho, nos termos dos §§ 3º e 4º do art. 2º da Lei 5.584/1970')
        }
        recorrenteDenegar.push('id ' + recurso.idUnicoDocumento + ',  interposto por ' + recurso.recorrente[0]?.nome + ', pois ' + motivo.join(','))
        movimentos.push({checkbox: {incluir: 'nao recebido'}, opcoes: [{nomeDoCampo: 'nome do recurso', selecionar: tipo}, {nomeDoCampo: 'nome da parte', selecionar: recurso.recorrente[0]?.nome}]})
    }
    let textoDenegar = `<p>Denego seguimento ao(s) recurso(s) ordinário(s) ` + recorrenteDenegar.join(', ') + `.</p>`
    let texto = (recursos.some(d => d?.marcado) ? textoProcessar : '') + '\n' + (recursos.some(d => !d?.marcado && !d?.naoProcessar) ? textoDenegar : '')

    
    await movimentar('Admissibilidade de Recursos', {
        'Elaborar decisão':{texto, movimentos, descricao: 'Decisão - Admissibilidade de Recursos', prazo: 8}
    })
    
    return
    


}
// _________________________________________________
//                   DEVOLVER PARA A VARA DE ORIGEM
// _________________________________________________

// PROCESSAR PASSO 1 - recebe os dados e abre a tela de tarefa

async function con2_prazo_vencido_devolverRemeter(parametro) {
    let confereExecucao = await execucaoAtualConferencia()
    if (!confereExecucao) return
    if (parametro == 'devolver' && confereSetor('Vara do ')) {
        rota_avisoObrigatorio('Este processo já está na Vara.', 5)
        return
    }
    if (parametro == 'devolver' && !confereSetor('CON2')) {
        rota_avisoObrigatorio('Esta funcionalidade deve ser executada em processos que estão na CON2.', 5)
        return
    }
    let idURL = location.href.match(/processo\/(\d+)\/detalhe/)
    let id = idURL[1]
    let chave = idg('con2', 'prazoVencido', 'devolverRemeter')
    await armazenar({[chave]: {confereExecucao, parametro}})
    let urlInicio = await definirURLDaTarefa(id) || ''
    if (!urlInicio) {
        rota_avisoObrigatorio('Ocorreu um erro. Atualize a página e tente novamente.', 5)
        return
    }
    let url = urlInicio + '?' + chave + '=' + confereExecucao
    let nomeJanela = chave + '_' + confereExecucao
    await abrirUrl(url, 'esquerdaAssistida', nomeJanela)
}

// DESPACHAR PASSO 2 - verifica se a janela aberta é a da extensão
async function con2_prazo_vencido_aoAbrirDevolver(){
    let janela = confereJanela(JANELA.processoTarefa)
    console.log('%c[Rota PJE]%c janela 371' + JSON.stringify(janela), LOG.aviso, 'color:inherit')
    if (!janela) return
    let chave = idg('con2', 'prazoVencido', 'devolverRemeter')
    let armazenamento = await obterArmazenamento(chave)
    console.log('%c[Rota PJE]%c armazenamento 371' + JSON.stringify(armazenamento), LOG.aviso, 'color:inherit')
    if (!armazenamento) return
    let dados = armazenamento[chave] || null
    console.log('%c[Rota PJE]%c dados 371' + JSON.stringify(dados), LOG.aviso, 'color:inherit')
    if (!dados) return
    let execucao = String(dados?.confereExecucao || '')
    console.log('%c[Rota PJE]%c execucao 371' + JSON.stringify(execucao), LOG.aviso, 'color:inherit')
    let nomeJanela = window.name
    if (!nomeJanela.includes(execucao)) return
    registrarListenerFechar(execucao)
    await con2_prazo_vencido_acoesDevolver(dados?.parametro)
}

// DESPACHAR PASSO 3 - executa as ações

async function con2_prazo_vencido_acoesDevolver(parametro){
    console.log('%c[Rota PJE]%c acoes Devolver 371' + JSON.stringify(371), LOG.aviso, 'color:inherit')
    if (parametro == 'devolver'){
        await movimentar('Devolver processo para vara de origem')
    }
    return
}

//__________________________________________________
//                      COLOCAR GIG DE ACOMPANHAMENTO
//__________________________________________________

async function con2_prazo_vencido_colocarGigDeAcompanhamento() {
    let confereExecucao = await execucaoAtualConferencia()
    if (!confereExecucao) return
    let id = await obterArmazenamento('rota_dadosCon2PrazoVencido').then(dados => dados?.rota_dadosCon2PrazoVencido?.processo?.id || '')
    let audienciaMarcadaHorario = await buscarAudienciasMarcadas(id).then(dados=> dados?.dataInicio || '')
    let audienciaMarcadaNumero = audienciaMarcadaHorario ? new Date(audienciaMarcadaHorario).getTime() : NaN
    let hoje = new Date().getTime()
    let trintaDiasAntes = audienciaMarcadaNumero - 30 * 24 * 60 * 60 * 1000
    let dataGig
    if (hoje < trintaDiasAntes) {
        dataGig = new Date(trintaDiasAntes).toLocaleDateString('pt-BR')
    } else if (audienciaMarcadaNumero - hoje < 10 * 24 * 60 * 60 * 1000) {
        dataGig = new Date(audienciaMarcadaNumero).toLocaleDateString('pt-BR')
    } else {
        dataGig = new Date(hoje + 10 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')
    }
    let usuarioObter = await obterArmazenamento('rotapje_usuario')
    let usuario = usuarioObter?.rotapje_usuario.nome || ''
    let mostrarOuEsconder = await aguardarElementoNovo('detalhesDoProcessoMostrarOuEsconderGigs')
    if (mostrarOuEsconder.ariaLabel == 'Mostrar o GIGS') clicar(mostrarOuEsconder)
    await aguardarElementoNovo('detalhesDoProcessoBotaoNovaAtividadeGigs')
    await inserirGigsNaTelaDeDetalhesDoProcesso('Audiência', dataGig, '', usuario.trim().toUpperCase(), 'Acompanhamento - Triagem Inicial', 'sim')
    //rota_avisoTemporario(JSON.stringify(dataGig), tipo = 'info', ms = 2000)
}



//__________________________________________________
//                      ENCAMINHAR PARA AGUARDANDO AUDIÊNCIA
//__________________________________________________

// ENCAMINHAR PARA AGUARDANDO AUDIÊNCIA PASSO 1 - recebe os dados e abre a tela de tarefa

async function con2_prazo_vencido_aguardandoAudiencia(tipo) {
    let confereExecucao = await execucaoAtualConferencia()
    if (!confereExecucao) return
    let id =            dadosCon2PrazoVencido?.processo?.id
    let tarefa =        await buscarTarefaMaisRecente(id)
    let idTarefa =      tarefa[0]?.idTarefa || ''
    let recurso =       tarefa[0]?.nomeRecurso || ''
    let parametros =    '?rotapje_con2_prazo_vencido_aguardandoAudiencia=' + dadosCon2PrazoVencido.execucaoAtual
    let nomeJanela =    'rotapje_con2_prazo_vencido_aguardandoAudiencia_' + dadosCon2PrazoVencido.execucaoAtual
    await armazenar({'rotapje_con2_prazo_vencido_aguardandoAudiencia': dadosCon2PrazoVencido.execucaoAtual})
    if (!recurso || !idTarefa){
        await rota_avisoObrigatorio('Ocorreu um erro. Tente novamente.', 30)
        return
    }
    let page =          dadosCon2PrazoVencido?.recursos?.find(r => r?.nome === recurso)
    if (!page?.caminhoRecurso){
        await rota_avisoObrigatorio('Ocorreu um erro. Tente novamente.', 30)
        return
    }
    let url =           location.origin + '/pjekz/processo/' + id + '/tarefa/' + idTarefa + page?.caminhoRecurso.split('{idTarefa}')[1] + parametros
    let setorProcesso = await aguardarElementoNovo('detalhesDoProcessoOJDoProcesso')
    if (!setorProcesso.textContent.includes('CON1')) {
        await rota_avisoObrigatorio('Esta funcionalidade deve ser executada em processos que estão na CON1.', 30)
        return
    }
    await abrirUrl(url, 'esquerdaAssistida', nomeJanela)
    
}



// ENCAMINHAR PARA AGUARDANDO AUDIÊNCIA PASSO 2 - verifica se a janela aberta é a da extensão
async function con2_prazo_vencido_aoAbrirAguardandoAudiencia(){
    let janela = confereJanela(JANELA.processoTarefa)
    if (!janela) return
    let armazenamento = await obterArmazenamento('rotapje_con2_prazo_vencido_aguardandoAudiencia')
    let execucao = String(armazenamento?.rotapje_con2_prazo_vencido_aguardandoAudiencia || '')
    if (!armazenamento) return
    let nomeJanela = window.name
    if (!nomeJanela.includes('rotapje_con2_prazo_vencido_aguardandoAudiencia')) return
    if(execucao !== nomeJanela.split('_').pop()) return
    registrarListenerFechar(execucao)
    await con2_prazo_vencido_acoesEncaminharAguardandoAudiencia()
}

// ENCAMINHAR PARA AGUARDANDO AUDIÊNCIA PASSO 3 - executa as ações

async function con2_prazo_vencido_acoesEncaminharAguardandoAudiencia(){
    await movimentar('Aguardando audiência')
    await suspender(2000)
    await armazenar({ rota_acoes_conjuntas_con2_prazo_vencido_pronta: 'con2_prazo_vencido_certidao' })
    window.close()
    return
    
}



//__________________________________________________
//                      AÇÕES CONJUNTAS
//__________________________________________________

async function con2_prazo_vencido_acoesConjuntas(p){
    let i = 0
    for (let c of p?.comandos){
        await armazenar({ rota_acoes_conjuntas_con2_prazo_vencido_em_andamento: c })
        const concluiu = await Promise.race([
            new Promise(resolver => {
                NAVEGADOR.storage.onChanged.addListener(function ouvir(mudancas) {
                    if (mudancas['rota_acoes_conjuntas_con2_prazo_vencido_pronta']?.newValue === c) {
                        NAVEGADOR.storage.onChanged.removeListener(ouvir)
                        resolver(true)
                    }
                })
                comandar([c], [p?.parametros[i]])
            }),
            new Promise(resolver => setTimeout(() => resolver(false), 10 * 60 * 1000)) // 10 minutos
        ])
        if (!concluiu) {
            rota_avisoTemporario('A ação expirou. Prossiga manualmente.', 'erro', 10000)
            await removerArmazenamento('rota_acoes_conjuntas_con2_prazo_vencido_em_andamento')
            return
        }
        i++
    }
    await removerArmazenamento('rota_acoes_conjuntas_con2_prazo_vencido_em_andamento')
    return
}

//let emAndamento = await obterArmazenamento(['rota_acoes_conjuntas_con2_prazo_vencido_em_andamento'])
//let chamadaPorAcaoConjunta = emAndamento?.rota_acoes_conjuntas_con2_prazo_vencido_em_andamento === 'con2_prazo_vencido_despachar'
//
//if (chamadaPorAcaoConjunta) {
//    criaBotaoAzul({
//        texto: 'Próximo',
//        acao: () => armazenar({ rota_acoes_conjuntas_con2_prazo_vencido_pronta: 'con2_prazo_vencido_despachar' })
//    })
//}

//__________________________________________________
//                      COMANDAR
//__________________________________________________


Object.assign(rota_acoes, {
    'con2_prazo_vencido_abrir_documentos':  async (p) => await con2_prazo_vencido_abrirDocumentos(p),
    'con2_prazo_vencido_retificar':         async (p) => await con2_prazo_vencido_retificarAutuacao(p),
    'con2_prazo_vencido_processar_recursos':async (p) => await con2_prazo_vencido_processarRecursos(p),
    'con2_prazo_vencido_devolverRemeter':   async (p) => await con2_prazo_vencido_devolverRemeter(p),
})


async function verificarOQueChegou(p) {
    rota_avisoTemporario(JSON.stringify(p), tipo = 'info', ms = 2000)
}

//__________________________________________________
//                      BUSCAR JUIZ NO MODELO - POSSÍVEL FUNÇÃO GLOBAL 
//__________________________________________________


