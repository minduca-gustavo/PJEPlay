let SELETORES_SIGEO = {
    barraDeBusca: '#div_pesquisa',
    botaoOk: '#formAJIntranet\\:botaoPesquisarPorPalavraChave',
    celulaDoProcessoNaTabela: '#formAJIntranet\\:numeroPPJ',
}

async function sigeoAjJtAoIniciar() {
    let janela = location.href
    console.log('%c[Rota PJE]%c 3: ' + location.href, LOG.teste, 'color:inherit')
    if (!janela.includes('sigeo.jt.jus.br/aj/nomeacao') && !janela.includes('sigeo.jt.jus.br/aj/pagamento')) return
    await rota_aguardarElemento(SELETORES_SIGEO.barraDeBusca)
    sigeoAjJtInserirElementos()
}

async function sigeoAjJtInserirElementos() {
    let retira = await selecionar('#rotapje-sigeo-filtra-vt-final')
    if (retira) retira.remove()
    console.log('%c[Rota PJE]%c 15:', LOG.teste, 'color:inherit')
    let botaoOk = await selecionar(SELETORES_SIGEO.botaoOk)
    
    
    let div = criaDiv({ 
        id: 'rotapje-sigeo-filtra-vt-final', 
        ancestral: SELETORES_SIGEO.barraDeBusca,
        rowColumn: 'row'
    })
    div.style.display = 'inline-flex'  // inline pra não quebrar linha com o botaoOk
    div.style.alignItems = 'center'    // alinha verticalmente
    div.style.gap = '4px'              // espaço entre input e botão
    div.style.marginTop = '3px'              // espaço entre input e botão
    
    let input = criaInput({ 
        id: 'rotapje-sigeo-filtra-vt-final-input-vara', 
        ancestral: 'rotapje-sigeo-filtra-vt-final',
        placeholder: 'Digite o código da Vara. Ex.: 0091, 0049',
    })
    input.container.style.flexDirection = 'row'
    
    
    let inputEl = document.querySelector('#rotapje-sigeo-filtra-vt-final-input-vara')
    inputEl.style.padding = '0px 4px'
    inputEl.style.fontSize = '10px'
    inputEl.style.marginLeft = '6px'
    inputEl.style.borderRadius = '0px'
    inputEl.style.marginTop = '3px'
    inputEl.addEventListener('keydown', e => {
        if (e.key === 'Enter') botaoFiltroEl.click()
    })
    inputEl.value = ''
    
    let botaoFiltro = criaBotaoAzul({ 
        id: 'rotapje-sigeo-filtra-vt-final-botao-filtro', 
        ancestral: 'rotapje-sigeo-filtra-vt-final',
        texto: 'Filtrar por Vara',
        acao: () => sigeo_filtra_vt_finalfiltrarPorVara(inputEl.value)
    })
    let botaoFiltroEl = document.querySelector('#rotapje-sigeo-filtra-vt-final-botao-filtro')
    botaoFiltroEl.style.display = 'inline-flex'
    botaoFiltroEl.style.width = '300px'
    botaoFiltroEl.style.height = 'fit-content'
    botaoFiltroEl.style.padding = '0px 0px'
    botaoFiltroEl.style.fontSize = '12px'
    botaoFiltroEl.style.borderRadius = '2px'
    botaoFiltroEl.style.marginLeft = '6px'
    botaoFiltroEl.style.textAlign = 'center'
    botaoFiltroEl.style.justifyContent = 'center'
    botaoFiltroEl.style.marginTop = '3px'  
    botaoFiltroEl.type = 'button'
    
    let varaSalva = await obterArmazenamento('rotapje_sigeo_filtra_vt_finalVaraSalva')
    console.log('%c[Rota PJE]%c varaSalva: ' + JSON.stringify(varaSalva), LOG.rosa, 'color:inherit')
    if (varaSalva?.rotapje_sigeo_filtra_vt_finalVaraSalva) {
        inputEl.value = varaSalva.rotapje_sigeo_filtra_vt_finalVaraSalva
    }
        
    

    inputEl.insertAdjacentElement('afterend', botaoFiltro)




}

async function sigeo_filtra_vt_finalfiltrarPorVara(vara) {
    await armazenar({rotapje_sigeo_filtra_vt_finalVaraSalva: vara})
    document.querySelectorAll('tr').forEach(el => el.style.display = '')
    if (!vara){
        return
    }
    let linhas = [...document.querySelectorAll('tr')]
    let linhasExcluir = linhas.filter(l => [...l.querySelectorAll('td')].some(td => td.textContent.length && td.textContent.match(/\d{20}/) && td.textContent.trim().slice(-4) != vara))
    linhasExcluir.forEach(el => el.closest('tr').style.display = 'none')
}
