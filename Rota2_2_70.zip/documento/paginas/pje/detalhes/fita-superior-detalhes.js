// ____________________________________
//        PRELIMINAR - CRIA A FITA
// ____________________________________

async function criaFitaSuperior() {
    let retira = await selecionar('#rotapje_fita_superior')
    if (retira) retira.remove()
    let barra = await aguardarElementoNovo('detalhesDoProcessoBarraSuperior')
    let corToolbar = barra
        ? getComputedStyle(barra).backgroundColor
        : '#1565C0'
    let div = criaDiv({
        id: 'rotapje_fita_superior',
        ancestral: 'ffff'
    })
    
    formataFitaSuperior(div, corToolbar)

    // Insere a div no DOM antes de criar os botões,
    // pois criaBotaoAzul busca o ancestral pelo id
    insereFitaSuperior(barra, div)
    if (confereJanela(JANELA.pericias)){
        await peritosPreferidos('rotapje_fita_superior')
        return
    }
    if (confereJanela(JANELA.minutar, JANELA.tarefaAssinar)){
        await despachosPreferidos('rotapje_fita_superior')
        console.log('%c[Rota PJE]%c 2: ' + JSON.stringify(2), LOG.info, 'color:inherit')
        liquidAICriaBotoes()
        return
    }
    if (confereJanela(JANELA.conclusao, JANELA.encaminharPostoAvancado, JANELA.analise)){
        return
    }
    if(confereJanela(JANELA.gigsRelatorios, JANELA.painelGlobal, JANELA.escaninho)){
        acertaChipTelaGig('rotapje_fita_superior')
        return
    }
    
    await busca_filaCriaBotao()
    await busca_pautaEletronicaCriaBotao()
    await abre_tarefa_rotaCriaBotao()
    await irParaAOJDesteProcessoCriaBotao()
    await abrirTarefaChipEmCima('rotapje_fita_superior')
    
    await tramitaIAResumoRapido()
    //await fitaDocumento()
    
}

function acertaChipTelaGig(ancestral){
    let janela = confereJanela(JANELA.gigsRelatorios, JANELA.painelGlobal, JANELA.escaninho)
    if (!janela) return
    let botao = criaBotaoAzul({
        id: idg('acertaChipTelaGig'),
        texto: 'Ajustar filtros',
        ancestral,
        acao: () => {
            if (!document.querySelector('.mat-chip-list-wrapper')) return
            let w = [...document.querySelector('.mat-chip-list-wrapper').children].map(d=>d.style.flexWrap = 'wrap')
        }
    })
    criaTooltip({
        id: idg('acertaChipTelaGig', 'tooltip'),
        texto: 'Ajustar filtros para evitar a rolagem da tela para os lados.',
        elemento: idg('acertaChipTelaGig')
    })
    estiloBotaoFitaSuperior(botao)
}

function formataFitaSuperior(elemento, cor){
    elemento.style.backgroundColor = cor ?? '#ffffff'
    elemento.style.gap = '1px'
    elemento.style.padding = '0px'
    elemento.style.marginBottom = '0px'
    elemento.style.minHeight = '14px'   // antes era height fixo
    elemento.style.height = 'auto'      // cresce conforme as linhas
    elemento.style.zIndex = '1'
    elemento.style.display = 'flex'
    elemento.style.flexDirection = 'row'
    elemento.style.flexWrap = 'wrap'    // quebra de linha
    elemento.style.alignItems = 'center'
    elemento.style.alignContent = 'flex-start'
    elemento.style.boxSizing = 'border-box'
    elemento.style.width = '0px'
    elemento.style.minWidth = '100%'
}

async function abrirTarefaChipEmCima(ancestral){
    let janela = confereJanela(JANELA.detalhes)
    if (!janela) return
    let botao = criaBotaoAzul({
        id: idg('abrirTarefaChipEmCima'),
        texto: 'Abrir Tarefa',
        ancestral,
        acao: () => {
            let botao = document.querySelector('.descricao-tarefa button')?.click()
        }
    })
    estiloBotaoFitaSuperior(botao)
}

async function confereCriaFitaSuperior(){
    console.log('%c[Rota PJE]%c confere: ' + JSON.stringify(43), LOG.rosa, 'color:inherit')
    let janela = confereJanela(
        JANELA.analise,
        JANELA.detalhes,
        JANELA.pericias,
        JANELA.minutar,
        JANELA.tarefaAssinar,
        JANELA.conclusao,
        JANELA.encaminharPostoAvancado,
        JANELA.gigsRelatorios,
        JANELA.painelGlobal,
        JANELA.escaninho,
    )
    console.log('%c[Rota PJE]%c fita superior janela: ' + JSON.stringify(janela), LOG.aviso, 'color:inherit')
    if (!janela) return
    await criaFitaSuperior()
}

function insereFitaSuperior(elemento, inserir){
    elemento
        ? elemento.parentElement.insertBefore(inserir, elemento)
        : document.body.prepend(inserir)
}

// ___________________________________________________
// [1] BUSCA POSIÇÃO FILA
// ___________________________________________________

async function busca_filaCriaBotao(){
    let botao = await criaBotaoAzul({
        id: 'rotapje-busca-posicao-fila-botao-busca',
        ancestral: 'rotapje_fita_superior',
        acao: () => busca_posicao_filaConsultar(),
        texto: 'Busca posição do processo na fila.'
    })
    estiloBotaoFitaSuperior(botao)
}

function buscaPosicaoFilaPainelGlobal(){
    let janela = confereJanela(JANELA.painelGlobalTarefas)
    if (!janela) return
    busca_FilaPainelGlobal()
}

async function busca_FilaPainelGlobal(){
    let parametros = await rota_buscarParametros('rotapje_busca_posicao_fila')
    if (!parametros) return
    let processo = await rota_buscarParametros('rotapje_busca_posicao_fila_numero')
    let armazenamento = await obterArmazenamento('rotapje_busca_posicao_fila')
    if (!armazenamento) return
    await removerArmazenamento('rotapje_busca_posicao_fila')
    await busca_posicao_filaAguardaCarregamentoDoBodyComProcesso()
    let contAtual = await interceptador_lerProcessosPainel()
    let conteudoAtual = contAtual.resultado
    let botoes = [...document.querySelectorAll(seletorPorVersao('painelGlogalBotoesDeOrdenar'))]
    let desde = botoes.find(el => el.textContent.includes('Desde'))
    let prioridade = await sel('painelGlobalBotaoFiltroDePrioridades')
    let desconsiderar = await sel('painelGlobalBotaoDesconsiderarFiltrosSelecionados')
    let dataPrioridade = ''
    let dataDesconsiderar = ''
    let cliques = [desde, prioridade]
    for(let clique of cliques){
        let elDesde = [...document.querySelectorAll('.th-container-class')].find(d=> d.textContent.includes('Desde'))
        if (elDesde.querySelector('[aria-label*=ascendente]') && clique == desde){
            dataDesconsiderar = new Date(datas[0].dataEntradaTarefa).toLocaleDateString('pt-BR')
            continue
        }
        clicar(clique)
        let datas = await busca_posicao_filaMudancaDaMetaTag(conteudoAtual)
        conteudoAtual = datas
        if(clique == prioridade) {
            dataPrioridade = new Date(datas[0].dataEntradaTarefa).toLocaleDateString('pt-BR')
        }
        if(clique == desde) {
            dataDesconsiderar = new Date(datas[0].dataEntradaTarefa).toLocaleDateString('pt-BR')
        }
    }
    busca_posicao_filaAguardaCarregamentoDoBodyComProcesso(conteudoAtual)
    relatar(dataPrioridade + ' - ' + dataDesconsiderar, '', 'teste')
    await aguardarElementoNovo('painelGlobalTabelaDeProcessos')
    let aviso = criaDiv({id: 'rotapje-busca-posicao-fila-div', ancestral: '#ffff'})
    aviso.style.width = '300px'
    aviso.style.position = 'fixed'
    aviso.style.top = '50%'
    aviso.style.left = '50%'
    aviso.style.transform = 'translate(-50%, -50%)'
    aviso.style.zIndex = '9999999'
    let botao = criaBotaoAzul({
        id: 'rotapje-busca-posicao-fila-botao',
        ancestral: 'rotapje-busca-posicao-fila-div',
        texto: 'O processo ' + processo + ' entrou na tarefa em ' + decodeURI(parametros) + '. O processo prioritário mais antigo entrou na tarefa em ' + dataPrioridade + '. O processo mais antigo, desconsiderando os prioritários, entrou na tarefa em ' + dataDesconsiderar + '. Clique para fechar.',
        acao: () => aviso.remove()
    })
    botao.style.zIndex = '9999999'
    document.body.appendChild(aviso)
}

async function busca_posicao_filaMudancaDaMetaTag(conteudo) {
    console.log('%c[Rota PJE]%c conteudo: ', LOG.info, 'color:inherit', conteudo)
    let jsonInicial = JSON.stringify(conteudo)
    let conteudoAtual
    for(let i = 0; i < 100; i++){
        let contAtual = await interceptador_lerProcessosPainel()
        conteudoAtual = contAtual.resultado
        if (!conteudoAtual) { await suspender(300); continue }
        if (JSON.stringify(conteudoAtual) !== jsonInicial) break
        await suspender(300)
    }
    return conteudoAtual
}

async function busca_posicao_filaAguardaCarregamentoDoBodyComProcesso(conteudoAtual){
    let match
    let contAtual
    let conteudo
    let ROTA_REGEX_CNJ = /\d{7}[-.]\d{2}[-.]\d{4}[-.]\d[-.]\d{2}[-.]\d{4}/
    if(!conteudoAtual){
        await aguardarElementoNovo('painelGlobalTabelaDeProcessos')
        for(let i = 0; i < 100; i++){
            contAtual = await sel('painelGlobalTabelaDeProcessos')
            conteudo = contAtual.innerText
            match = conteudo.match(ROTA_REGEX_CNJ) || conteudo.match('Não há processos neste tema.')
            if (match) return
            await suspender(300)
        }
        if (!ROTA_REGEX_CNJ.test(conteudo)) return null
    }else{
        conteudo = conteudoAtual
    }
    for(let i = 0; i < 100; i++){
        let contMudou = await sel('painelGlobalTabelaDeProcessos')
        let conteudoMudou = contMudou.innerText
        if (conteudo !== conteudoMudou && ROTA_REGEX_CNJ.test(conteudoMudou)) return
        await suspender(300)
    }
    return null
}

async function busca_posicao_filaConsultar() {
    const rodape = await selecionar('#rotapje-busca-posicao-fila-rodape')
    const id = location.href.match(/\/pjekz\/processo\/(\d+)\/detalhe/)?.[1]
    const processo = ((await sel('detalhesDoProcessoNumeroProcessoComTipo'))?.textContent.split(' ')[2])
      ?? (await interceptador_lerProcesso()?.numero ?? await rota_fetch(`${location.origin}/pje-comum-api/api/processos/id/${id}`))?.numero
    if(!processo){
        rodape.textContent = 'Processo não encontrado. Atualize a página e tente novamente.'
        return
    }
    let idTarefa = await rota_fetch(location.origin + '/pje-comum-api/api/agrupamentotarefas/processos?numero=' + processo)
    let tarefas = await rota_fetch(location.origin + '/pje-comum-api/api/tarefas/historico/' + id)
    let dataEntradaTarefa = new Date(tarefas[tarefas.length - 2]?.inicio).toLocaleDateString('pt-BR')
    rodape.textContent = 'O processo entrou na tarefa em ' + dataEntradaTarefa + '.'
    await armazenar({rotapje_busca_posicao_fila: dataEntradaTarefa})
    let url = location.origin + '/pjekz/painel/global/' + idTarefa[0].idAgrupamentoProcesso + '/lista-processos?rotapje_busca_posicao_fila=' + encodeURI(dataEntradaTarefa) + '&rotapje_busca_posicao_fila_numero='+ processo
    window.open(url)
}

function busca_posicao_filaNavegar(url) {
    location.href = url
}



// ___________________________________________________
// [2] ABRE PAUTA ELETRÔNICA
// ___________________________________________________

async function busca_pautaEletronicaCriaBotao() {
    let botao = await criaBotaoLaranja({
        id: idg('buscaPautaEletronica', 'botao'),
        ancestral: 'rotapje_fita_superior',
        acao: () => busca_pautaEletronica(),
        texto: 'Pauta Eletrônica'
    })
    criaTooltip({
        id: idg('buscaPautaEletronica', 'botao', 'tooltip'),
        texto: 'Abre a pauta eletrônica na sala correspondente, SE houver audiência marcada',
        elemento: botao
    })
    estiloBotaoFitaSuperior(botao)
}

async function busca_pautaEletronica() {
    let idURLMatch = location.href.match(/pjekz\/processo\/(\d+)\/detalhe/)
    let idURL = idURLMatch?.[1]
    let audienciasMarcadas = interceptador_lerAudiencias() || await buscarAudienciasMarcadas(idURL) || []
    if (!audienciasMarcadas.length) {
        fitaSuperiorErro('Não há audiências marcadas')
        return
    }
    let sala = audienciasMarcadas[0]?.salaFisica?.nome
    let oj = interceptador_lerProcesso() || await buscarProcesso(id) || {}
    if (!oj?.orgaoJulgador?.descricao) {
        fitaSuperiorErro('Ocorreu um erro. Atualize a página e tente novamente')
        return
    }
    let url = 'https://pauta.trt15.jus.br/pautaeletronica/pautaAudiencia.xhtml'
    let tarefa = idg('buscaPautaEletronica')
    let execucao = Date.now()
    let nomeJanela = tarefa + '_' + execucao
    await armazenar ({[tarefa]: {execucao: execucao, oj: oj?.orgaoJulgador?.descricao, sala: sala}})
    window.open(url, nomeJanela)
}

async function pautaEletronicaAbriu() {
    let janela = confereJanela(JANELA.pautaEletronica)
    if (!janela) return
    let tarefa = idg('buscaPautaEletronica')
    let janelaNome = window.name
    if (!janelaNome.includes(tarefa)) return
    let armazenamento = await obterArmazenamento(tarefa)
    let dado = armazenamento[tarefa]
    if (!janelaNome.includes(dado?.execucao)) return
    let jurisdicao = 'select[id="main:jurisdicao"]'
    await rotinaCliques(jurisdicao, dado?.oj)
    let local = 'select[id="main:local"]'
    await aguardarMudar(local)
    await rotinaCliques(local, dado?.oj)
    let sala = 'select[id="main:sala"]'
    await aguardarMudar(sala)
    await rotinaCliques(sala, dado?.sala)
    await suspender (1000)
    window.name = ''
    await removerArmazenamento(tarefa)
    document.querySelector('a[id="main:btnPautaDia"]').click()
    return

    async function aguardarMudar(local) {
        let i = 0
        while(!confereElemento(local)){
            await suspender(1000)
            i++
            if (i === 10) {
                fitaSuperiorErro('Ocorreu um erro. Proceda manualmente.')
                return
            }
        }
        return
        function confereElemento(seletor){
            let elemento = document.querySelector(seletor)
            let opcoes = [...elemento.querySelectorAll('option')]
            return opcoes.length > 1 ? true : false
        }
    }
    
    async function rotinaCliques(elemento, opcao){
        await aguardarElemento(elemento)
        await suspender(1000)
        let menu = document.querySelector(elemento)
        let opcoes = [...menu.querySelectorAll('option')]
        let opcaoEncontrada = opcoes.find(d => d.textContent == opcao || opcao.includes(d.textContent))
        menu.value = opcaoEncontrada?.value
        menu.dispatchEvent(new Event('change', { bubbles: true }))
    }
}



function fitaSuperiorErro(texto){
    if (typeof texto !== 'string') return
    rota_avisoObrigatorio(texto, 5)
    return
}

// ___________________________________________________
// [3] ABRE TAREFA DO ROTA EM JANELAS
// ___________________________________________________

async function abre_tarefa_rotaCriaBotao() {
    let nomeTarefaAtiva = await abre_tarefa_rotaNomeTarefaAtiva()
    let botaoTarefa = await criaBotaoAzul({
        id: 'rotapje-abre-tarefa-rota-botao',
        ancestral: 'rotapje_fita_superior',
        acao: () => abre_tarefa_rotaAbrirEmModoJanelas(),
        texto: 'tarefa: ' + nomeTarefaAtiva
    })
    estiloBotaoFitaSuperior(botaoTarefa)
}

async function abre_tarefa_rotaNomeTarefaAtiva(){
    let cfg = await obterArmazenamento('tarefaAtiva')
    return _ass_nomeTarefa(cfg?.tarefaAtiva) || cfg?.tarefaAtiva || '—'
}

async function abre_tarefa_rotaAbrirEmModoJanelas(){
    const id = location.href.match(/\/pjekz\/processo\/(\d+)\/detalhe/)?.[1]
    const processo = ((await sel('detalhesDoProcessoNumeroProcessoComTipo'))?.textContent.split(' ')[2])
        ?? (await interceptador_lerProcesso()?.numero ?? await rota_fetch(`${location.origin}/pje-comum-api/api/processos/id/${id}`))?.numero
    if(!id || !processo){
        rota_avisoTemporario('Processo não encontrado. Atualize a página e tente novamente.', 'erro', 4000)
        return
    }
    rota_avisoTemporario('▶ Abrindo no modo janelas…', 'info', 3000)
    rota_iniciarFluxo({ fila: [{ numProc: processo, id, dadosLinha: [], params: [] }] })
}


// ___________________________________________________
// [4] IR PARA A OJ DESTE PROCESSO
// ___________________________________________________

async function irParaAOJDesteProcessoCriaBotao() {
    let id = 'rotapje-irParaAOJDesteProcesso' 
    let botaoTarefa = await criaBotaoLaranja({
        id: id + '_botao',
        ancestral: 'rotapje_fita_superior',
        acao: () => irParaAOJDesteProcesso(),
        texto: 'Ir para a OJ deste processo'
    })
    criaTooltip({
        id: id + '_tooltip',
        texto: 'Ir para a OJ atual deste processo',
        elemento: botaoTarefa
    })
    estiloBotaoFitaSuperior(botaoTarefa)
}

async function irParaAOJDesteProcesso() {
    let id = location.href.match(/\/pjekz\/processo\/(\d+)\/detalhe/)?.[1]
    let dados = await buscarProcesso(id)
    let oj = dados?.orgaoJulgador?.id || null
    if(!oj) {
        rota_avisoTemporario('Ocorreu um erro.', 'erro', 4000)
        return
    }
    //if(document.querySelector('pje-cabecalho-processo').textContent.includes(dados?.orgaoJulgador?.descricao)) {
    //    rota_avisoTemporario('Você já está na OJ deste processo.', 'info', 4000)
    //    return
    //}
    let perfis = await rota_fetch(location.origin + '/pje-seguranca/api/token/perfis')
    //console.log('%c[Rota PJE]%c perfis' + JSON.stringify(perfis), LOG.info, 'color:inherit')
    //return
    let perfil = perfis.find(el => el.idOrgaoJulgador === oj)
    if (!perfil) {
        rota_avisoTemporario('Ocorreu um erro.', 'erro', 4000)
        return
    }
    await fetch(location.origin + '/pje-seguranca/api/token/perfis/trocar', {
        method: 'POST',
        mode: 'cors',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            'X-XSRF-TOKEN': cookie_obter('Xsrf-Token') || cookie_obter('XSRF-TOKEN'),
        },
        body: JSON.stringify({ id_perfil: perfil.idPerfil })
    })
    window.location.reload()
}

// ___________________________________________________
// [5] TRAMITA IA RESUMO RÁPIDO
// ___________________________________________________

async function tramitaIAResumoRapido() {
    let idBotao = idg('tramitaIAResumoRapido', 'botao')
    let botao = await criaBotaoLaranja({
        id: idBotao,
        ancestral: 'rotapje_fita_superior',
        acao: () => tramitaIAResumoRapidoBusca(idBotao),
        texto: 'Tramita IA - Resumo rápido'
    })
    criaTooltip({
        id: idg('tramitaIAResumoRapido', 'botao', 'tooltip'),
        texto: 'Apresenta um resumo rápido da tramitação do processo. Disponível apenas na CON1, por enquanto.',
        elemento: botao
    })
    estiloBotaoFitaSuperior(botao)
}

async function tramitaIAResumoRapidoBusca(idBotao, novaChamada = false) {
    document.getElementById(idBotao).disabled = true
    let ojs = [
        {
            oj: 'CON1',
            funcao: 'tramitaIAResumoRapidoCON1',
        },
        {
            oj: 'LIQ1',
            funcao: 'tramitaIAResumoRapidoLIQ1',
        }
    ]
    let mapaFuncoes = {
        tramitaIAResumoRapidoCON1,
        tramitaIAResumoRapidoLIQ1
    }
    let funcao = null
    for(let oj of ojs){
        let ojAtual = document.querySelector('section.oj-cargo').textContent
        if(ojAtual.includes(oj?.oj)){
            funcao = oj?.funcao || null
        }
    }
    if (!funcao) {
        fitaSuperiorErro('Ainda não configurado para esta OJ.')
        document.getElementById(idBotao).disabled = false
        return
    }
    let resumo = await montarResumo('carregando')
    if (resumo) {
        document.getElementById(idBotao).disabled = false
        return
    }
    let resposta = await mapaFuncoes[funcao]()
    console.log('%c[Rota PJE]%c resumos: ' + JSON.stringify(resposta), LOG.teste, 'color:inherit')
    await montarResumo(resposta)
    document.getElementById(idBotao).disabled = false
    return

    
    async function montarResumo(dados){
        let idDiv = idg('tramitaIA', 'resumos')
        if(!novaChamada){
            if (document.getElementById(idDiv)){
                if (document.getElementById(idDiv).style.display == 'none'){
                    document.getElementById(idDiv).style.display = 'flex'
                    return true
                } else {
                    document.getElementById(idDiv)?.remove()
                }
            }
        } else {
            document.getElementById(idDiv)?.remove()
        }
        let div = criaDiv({
            id: idDiv,
            ancestral: document.body
        })
        formataDiv(div, 'branco', '70%', '70%', 'fixed')
        let cabecalho = criaDiv({
            id: idDiv + '_cabecalho',
            ancestral: idDiv,
            rowColumn: 'row-reverse'
        })
        criaBotaoFechar({
            id: idDiv + '_fechar',
            ancestral: idDiv + '_cabecalho',
            elementoFechar: idDiv,
            esconder: true
        })
        let titulo = criaTitulo({
            id: idDiv + '_cabecalho_titulo',
            texto: 'Tramita IA',
            ancestral: idDiv + '_cabecalho',
        })
        titulo.style.width = '100%'
        let idCarregando = idDiv + '_carregando'
        if (dados === 'carregando'){
            let subtitulo = criaSubTitulo({
                id: idCarregando + '_texto',
                texto: 'Aguarde. Fazendo a consulta ao Chat-JT',
                ancestral: idDiv
            })
            subtitulo.style.fontSize = '20px'
            return null
        } else {
            document.getElementById(idCarregando)?.remove()
        }
        let idFundo = idDiv + '_fundo'
        let divFundo = criaDiv({
            id: idFundo,
            ancestral: idDiv,
            rowColumn: 'row'
        })
        divFundo.style.height = '95%'
        let idRolante = idDiv + '_rolante'
        let divRolante = criaDiv({
            id: idRolante,
            ancestral: idFundo,
        })
        divRolante.style.overflowY = 'auto'
        divRolante.style.width = '95%'
        divRolante.style.height = '95%'
        divRolante.style.left = '5px'
        let idDireita = idDiv + '_direita'
        let divDireita = criaDiv({
            id: idDireita,
            ancestral: idFundo
        })
        divDireita.style.width = '170px'
        divDireita.style.overflowY = 'auto'
        let rodape = criaDiv({
            id: idDiv + '_rodape',
            ancestral: idDiv
        })
                
        let i = 0
        let novaBusca = false
        for(let dado of dados){
            if (i == 0){
                criaTexto({
                    id: idDireita + '_instrucao',
                    texto: 'Clique nos botões para rolar para o tema correspondente. Utilize os checkbox para habilitar/desabilitar as consultas ao CHAT-JT.',
                    ancestral: idDireita
                })
            }
            let {resposta, titulo, id} = dado
            console.log('%c[Rota PJE]%c id' + JSON.stringify(id), LOG.aviso, 'color:inherit')
            let idDivResposta = idDiv + '_div_' + (id ? id : i)
            let idTitulo = idDiv + '_titulo_' + (id ? id : i)
            criaDiv({
                id: idTitulo + '_div',
                ancestral: idRolante,
                rowColumn: 'row'
            })
            let subtitulo = criaSubTitulo({
                id: idTitulo,
                texto: titulo,
                ancestral: idTitulo + '_div',
            })
            subtitulo.style.fontSize = '20px'
            criaBotaoAzul({
                id: idTitulo + '_copiar',
                ancestral: idTitulo + '_div',
                texto: 'Copiar 📋',
                acao: async () => {
                    navigator.clipboard.writeText(resposta)
                    document.getElementById(idTitulo + '_copiar').textContent = 'Copiado ☑️'
                    await suspender(2000)
                    document.getElementById(idTitulo + '_copiar').textContent = 'Copiar 📋'
                }
            })
            criaTexto({
                id: idDiv + '_resumo_' + (id ? id : i),
                ancestral: idRolante,
                texto: resposta
            })
            criaDiv({
                id: idDivResposta,
                ancestral: idDireita,
                rowColumn: 'row'
            })
            if (id){
                let armazenamento = await obterArmazenamento(id)
                let check = await criaCheckBox({
                    id,
                    ancestral: idDivResposta,
                    salvar: true
                })
                if (armazenamento?.[id]) clicar(id)
                check.addEventListener('click', () => criaBotaoNovaBusca())
            }
            let botaoResumo = criaBotaoAzul({
                id: idDiv + '_botao_' + (id ? id : i),
                texto: titulo, 
                ancestral: idDivResposta,
                acao: () => {
                    document.getElementById(idTitulo)?.scrollIntoView({block: 'start'})
                }
            })
            botaoResumo.style.width = '100%'
            i++
        }
        
        function criaBotaoNovaBusca(){
            if (!novaBusca){
                let botaoNovaConsulta = criaBotaoLaranja({
                    id: idDiv + '_botaoNovaConsulta',
                    texto: 'Nova consulta',
                    ancestral: idDireita,
                    acao: () => tramitaIAResumoRapidoBusca(idBotao, true)
                })
            }
            novaBusca = true
        }
        return null
    }
}



async function estiloBotaoFitaSuperior(botao){
    botao.style.width = 'fit-content'
    let armazenamento = await obterArmazenamento('melhorLeitura_ativo')
    let melhorLeitura = armazenamento?.melhorLeitura_ativo
    //console.log('%c[Rota PJE]%c melhorLeitura' + JSON.stringify(melhorLeitura), LOG.aviso, 'color:inherit')
    if (!melhorLeitura){
        botao.style.fontSize = '9px'
        botao.style.height     = '14px'
        botao.style.lineHeight = '14px'
        botao.style.padding    = '0 8px'
        botao.style.zIndex = '1'
        return
    }
    botao.style.padding = '0 4px'
    botao.style.fontSize = '20px'
    botao.style.fontSize = '20px'
    botao.style.background = '#000000'
    _ui_hoverBotao(botao, '#000000', '#333333')
    return

}

async function peritosPreferidos(ancestral) {
    let idBotaoConfigura = idg('fita_superior', 'peritosPreferidos')
    document.getElementById(idBotaoConfigura)?.remove()
    let botaoConfigura = criaBotaoAzul({
        id: idBotaoConfigura,
        texto: 'Cadastrar peritos mais usados',
        ancestral,
        acao: () => cadastrarPeritosPreferidos()
    })
    let tooltip = criaTooltip({
        id: idBotaoConfigura + '_tooltip',
        texto: 'Cria botões com os peritos mais usados, para escolher/nomear com um clique.',
        elemento: idBotaoConfigura
    })
    estiloBotaoFitaSuperior(botaoConfigura)
    let peritos = await obterArmazenamento(idBotaoConfigura) || {}
    if (peritos[idBotaoConfigura] && peritos[idBotaoConfigura].length) {
        let peritosArmazenados = peritos[idBotaoConfigura]
        let i = 0
        for (let perito of peritosArmazenados){
            let funcoes = [
                'criaBotaoLaranja',
                'criaBotaoAzul'
            ]
            let mFuncoes = {
                criaBotaoAzul,
                criaBotaoLaranja
            }
            console.log('%c[Rota PJE]%c mFuncoes[funcoes[i % 2]]' + JSON.stringify(mFuncoes[funcoes[(i % 2)]]), LOG.info, 'color:inherit')
            let funcao = funcoes[i % 2]
            let botao = mFuncoes[funcao]({
                id: idBotaoConfigura + '_botaoPerito_' + i,
                ancestral: 'rotapje_fita_superior',
                texto: perito?.perito.split(' ')[0] + ' ' + perito?.perito.split(' ').pop(),
                acao: () => nomearPerito(perito)
            })
            criaTooltip({
                id: idBotaoConfigura + '_botaoPerito_tooltip_' + i,
                texto: 'Intimar perito ' + perito?.perito + ' - ' + perito?.especialidade + '.',
                elemento: idBotaoConfigura + '_botaoPerito_' + i
            })
            estiloBotaoFitaSuperior(botao)
            i++
        }
    }
    
    async function cadastrarPeritosPreferidos(){
        let peritos = await obterArmazenamento(idBotaoConfigura) || {}
        let divId = idg('peritosPreferidos', 'cadastro')
        let div = criaDiv({
            id: divId,
            ancestral: document.body
        })
        formataDiv(div, 'branco', '50%', '50%')
        let divCabecalho = criaDiv({
            id: divId + '_cabecalho',
            ancestral: divId,
            rowColumn: 'row-reverse'
        })
        divCabecalho.style.marginBottom = '0px'
        criaBotaoFechar({
            id: divId + '_botaoFechar',
            ancestral: divId + '_cabecalho',
            elementoFechar: divId,
        })
        let titulo = criaTitulo({
            id: divId + '_titulo',
            ancestral: divId + '_cabecalho',
            texto: 'Cadastre seus peritos mais usados'
        })
        titulo.style.width = '100%'
        let textArea = criaInputAnotacao({
            id: divId + '_input',
            textoEmCima: 'Cadastre seus peritos mais usados, com respectivas especialidades, e data em dias ou data certa(opcionais), um por linha, separando a especialidade e data (se houver) por vírgula ou tabulação.',
            ancestral: divId
        })
        textArea.style.width = 'auto'
        textArea.style.height = '80%'
        textArea.textarea.style.height = '100%'
        textArea.textarea.placeholder = 'Ex:\nFULANO DE TAL, economista, 30\nCiclano de tal, ADMINISTRADOR, 28/02/2027\nbeltrano de tal\tcontador (separado por TAB - colado de uma planilha)'
        if (peritos[idBotaoConfigura] && peritos[idBotaoConfigura].length){
            let texto = peritos[idBotaoConfigura].map(d => {
                let {perito, especialidade, dataOuDias} = d
                return [perito, especialidade, dataOuDias].join(', ')
            }).join('\n')
            textArea.textarea.value = texto
        }
        let divRodape = criaDiv({
            id: divId + '_rodape',
            ancestral: divId,
            rowColumn: 'row-reverse'
        })
        divRodape.style.marginBottom = '0px'
        criaBotaoAzul({
            id: divId + '_botaoSalvar',
            texto: 'Salvar alterações',
            ancestral: divId + '_rodape',
            acao: () => salvarAlteracoes(divId + '_input')
        })

    }
    async function nomearPerito({perito = '', especialidade = '', dataOuDias = 0}){
        if (!perito){
            rota_avisoObrigatorio('Não foi informado o nome do perito. Verifique se foi salvo corretamente.', 5)
            return
        }
        if (!especialidade){
            rota_avisoObrigatorio('Não foi informada a especialidade do perito. Verifique se foi salvo corretamente.', 5)
            return
        }
        await aguardarElemento('button[mattooltip^="Incluir per"]')
        await suspender()
        let botaoIncluir = document.querySelector('button[mattooltip^="Incluir per"]')
        clicar(botaoIncluir)
        await aguardarElemento('.input-profissao input')
        await suspender()
        let inputProfissao = document.querySelector('.input-profissao input')
        clicar(inputProfissao)
        await aguardarElemento('mat-option')
        await suspender()
        let opcoesEspecialidades = [...document.querySelectorAll('mat-option')]
        let opcaoEspecialidade = opcoesEspecialidades.find(d => normalizar(d?.textContent).includes(normalizar(especialidade)))
        if(!opcaoEspecialidade){
            rota_avisoObrigatorio('Não foi encontrada a especialidade ' + especialidade + '.', 5)
            return
        }
        clicar(opcaoEspecialidade)
        await aguardarElemento('pje-seletor-perito .fa-check')
        await suspender()
        let inputPerito = document.querySelector('pje-seletor-perito input')
        clicar(inputPerito)
        await aguardarElemento('mat-option')
        await suspender()
        let opcoesPeritos = [...document.querySelectorAll('mat-option')]
        let opcaoPerito = opcoesPeritos.find(d => normalizar(d?.textContent).includes(normalizar(perito)))
        if(!opcaoPerito){
            rota_avisoObrigatorio('Não foi encontrado o perito ' + perito + '. Verifique a especialidade', 5)
            return
        }
        clicar(opcaoPerito)
        if (dataOuDias){
            await suspender()
            let inputData = document.querySelector('input[data-mat-calendar]')
            if (dataOuDias.match(/\d{2}\/\d{2}\/\d{4}/)){
                preencher(inputData, dataOuDias)
            } else if (typeof Number(dataOuDias) == 'number'){
                let idURLMatch = location.href.match(/processo\/(\d+)\/pericias/)
                let idURL = idURLMatch?.[1]
                let processo = interceptador_lerProcesso() || await buscarProcesso(idURL) || {}
                if (!processo?.orgaoJulgador) return
                let data = await rota_fetch(location.origin + '/pje-gigs-api/api/atividade/retorna-prazo/' + dataOuDias + '?idOj=' + processo?.orgaoJulgador?.id + '&dataInicio=' + new Date().toISOString().slice(0, 10))
                let dataPreencher = new Date(data?.DATA).toLocaleDateString()
                console.log('%c[Rota PJE]%c data' + JSON.stringify(data), LOG.rosa, 'color:inherit')
                preencher(inputData, dataPreencher)
            } else {
                rota_avisoObrigatorio('O formato de data deve ser DD/MM/AAAA ou então número de dias.')
                return
            }
        }
        //alert (JSON.stringify(dadosPerito))
    }
    async function salvarAlteracoes(elemento){
        let peritos = await obterArmazenamento(idBotaoConfigura) || {}
        let peritosCadastrados = peritos[idBotaoConfigura] || []
        let peritosNovos = tratarDados(document.getElementById(elemento).value)
        await armazenar({[idBotaoConfigura]: peritosNovos?.peritos})
        if(peritosNovos?.erros?.length){
            rota_avisoObrigatorio(
                `Os seguintes peritos não foram cadastrados, pois foi encontrado erro na formatação (vírgula ausente, mais vírgulas do que o necessário, etc.):\n` +
                peritosNovos?.erros.join('\n'), 8
            )
        } else {
            rota_avisoObrigatorio('Cadastro efetuado com sucesso', 8)
        }
        criaFitaSuperior()
        return
    }
    function tratarDados(texto){
        let linhas = texto.split(/\r?\n/)
        let peritos = []
        let erros = []
        for (let linha of linhas){
            let dados = linha.split(',')
            
            console.log('%c[Rota PJE]%c dados' + JSON.stringify(dados.length), LOG.aviso, 'color:inherit')
            if (dados.length != 2 && dados.length != 3){
                if (linha.match(/[A-Za-zÀ-ÿ\s]+/)?.[0]) erros.push(linha)
                continue
            }
            peritos.push({
                perito: dados[0].trim().match(/[A-Za-zÀ-ÿ\s]+/)?.[0] || '', 
                especialidade: dados[1].trim().match(/[A-Za-zÀ-ÿ\s]+/)?.[0] || '',
                dataOuDias: dados?.[2] ? dados?.[2].trim() : null
            })
        }
        return {peritos, erros}
    }
}


async function fitaDocumento() {
    let retira = await selecionar('#rotapje_fita_documentos')
    if (retira) retira.remove()
    let barra = await aguardarElemento('#documento')
    let documento = document.querySelector('#documento').children[0]
    let corToolbar = barra
        ? getComputedStyle(barra).backgroundColor
        : '#fafafa'
    let div = criaDiv({
        id: 'rotapje_fita_documentos',
        ancestral: document.body
    })
    formataFitaSuperior(div, corToolbar)
    insereFitaSuperior(documento, div)
    await buscaPeritoNoDocumento('rotapje_fita_documentos')
}

async function buscaPeritoNoDocumento(ancestral) {
    let idBusca = idg('buscaPeritoNoDocumento')
    let botao = await criaBotaoAzul({
        id: idBusca,
        ancestral: ancestral,
        acao: () => buscaPeritoNoDocumentoEIntima(),
        texto: 'Busca perito e designa perícia'
    })
    criaTooltip({
        id: idBusca + '_tooltip',
        texto: 'Busca perito no documento usando IA e designa a perícia. A resposta do ChatJT pode ser demorada.',
        elemento: idBusca
    })
    estiloBotaoFitaSuperior(botao)
}