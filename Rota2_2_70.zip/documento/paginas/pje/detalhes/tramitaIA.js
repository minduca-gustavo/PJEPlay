async function tramitaIAResumoRapidoCON1() {
    let idURLMatch = location.href.match(/pjekz\/processo\/(\d+)\/detalhe/)
    let idURL = idURLMatch?.[1]
    // DOCUMENTOS COMUNS
    let timeline = interceptador_lerTimeline() || await buscarDocumentos(idURL) || []
    let timelineLimpa = timeline.map(d => {
        return({id: d?.id, idUnicoDocumento: d?.idUnicoDocumento, titulo: d?.titulo, tipo: d?.tipo, data: d?.data, participacaoProcesso: d?.participacaoProcesso})
    })
    let dataMaior = null
    let atas = timelineLimpa.filter(d=> normalizar(d?.titulo).includes('ata da audiencia')) || []
    let teorAtas = []
    for (let ata of atas){
        let teor = await rota_extrairTeorDocumento(idURL, ata?.id) || ''
        teorAtas.push({id: ata?.id, informacoes: ata, teor})
        dataMaior = dataMaior > new Date(ata?.data) ? dataMaior : ata?.data
    }
    let despachos = timelineLimpa.filter(d=> ['despacho', 'decisao', 'sentenca'].some(c => normalizar(d?.titulo).includes(c))) || []
    let teorDespachos = []
    for (let despacho of despachos){
        let teor = await rota_extrairTeorDocumento(idURL, despacho?.id) || ''
        teorDespachos.push({id: despacho?.id, informacoes: despacho, teor})
        dataMaior = dataMaior > new Date(despacho?.data) ? dataMaior : despacho?.data
    }
    let peticaoInicial = null
    let documentosPartes = timelineLimpa.filter(d=>{
        let partes = ['perito', 'autor', 'reu'].some(c=> normalizar(d?.participacaoProcesso).includes(c) && d?.participacaoProcesso)
        let data = new Date(d?.data) > dataMaior
        if(partes && data) return d
    }) || []
    let teorDocumentosPartes = []
    for (let documento of documentosPartes){
        let teor = await rota_extrairTeorDocumento(idURL, documento?.id) || ''
        peticaoInicial = normalizar(documento?.titulo).includes('peticao inicial') ? {informacoes: documento, teor} : ''
        teorDocumentosPartes.push({id: documento?.id, informacoes: documento, teor})
    }
    // PRIMEIRO ASSISTENTE
    let armazenamento = await obterArmazenamento(idg('resumoGeralCON1'))
    let primeiraRespostaTF = armazenamento[idg('resumoGeralCON1')] || false
    let primeiroAssistenteEnvio = {timelineLimpa, teorDespachos, teorDocumentosPartes, teorAtas}
    let primeiroAssistente = '6ac138f2bb98490b4befd0e7'
    let primeiraResposta = primeiraRespostaTF ? (await rota_IAConsulta(primeiroAssistente, JSON.stringify(primeiroAssistenteEnvio)) || 'Ocorreu um erro') : 'Não solicitado (o checkbox não está clicado ao lado, efetue nova consulta).'
    // DOCUMENTOS SEGUNDO ASSISTENTE
    let processo = document.querySelector('pje-descricao-processo')?.textContent.match(_ROTA_CNJ_PADRAO) || ''
    if (!processo){
        processo = interceptador_lerProcesso() || await buscarProcesso(idURL) || {}
    }
    let numeroProcesso = (typeof processo === 'string') ? processo : processo?.numero
    let gigs = interceptador_lerGigs() || await buscarGigs(numeroProcesso) || []
    let audienciaMarcada = document.querySelector('.campo-informacao-icone')?.textContent || ' '
    gigs = gigs.map(d => ({prazo: d?.dataPrazo, observacao: d?.observacao, tipoAtividade: d?.tipoAtividade?.descricao, statusAtividade: d?.statusAtividade}))
    let tarefa = interceptador_lerTarefaMaisRecente() || await buscarTarefaMaisRecente(idURL) || null
    let chips = interceptador_ler('chips') || await buscarChips(idURL) || []
    chips = chips.map(d=> ({nome: d?.etiquetaInstancia?.etiqueta?.nome, data: d?.etiquetaInstancia?.etiqueta?.dataInclusao}))
    armazenamento = await obterArmazenamento(idg('gestaoCON1'))
    let segundaRespostaTF = armazenamento[idg('gestaoCON1')] || false
    let segundoAssistenteEnvio = {primeiraResposta, timelineLimpa, teorDespachos, teorAtas, chips, gigs, audienciaMarcada, tarefa}
    let segundoAssistente = '6ac7e7eb2d5c9cd657dd24f1'
    let segundaResposta = segundaRespostaTF ? (await rota_IAConsulta(segundoAssistente, JSON.stringify(segundoAssistenteEnvio)) || 'Ocorreu um erro') : 'Não solicitado (o checkbox não está clicado ao lado, efetue nova consulta).'
    //_baixarArquivo(JSON.stringify(segundoAssistenteEnvio, null, 2), 'resumoRapidoCON1.json', 'application/json')
    return [
        {titulo: 'Resumo Geral CON1', resposta: primeiraResposta, id: idg('resumoGeralCON1')}, 
        {titulo: 'Gestão', resposta: segundaResposta, id: idg('gestaoCON1')},
    ]
    
}

async function tramitaIAResumoRapidoLIQ1() {
    let idURLMatch = location.href.match(/pjekz\/processo\/(\d+)\/detalhe/)
    let idURL = idURLMatch?.[1]
    // DOCUMENTOS COMUNS
    
    let timeline = interceptador_lerTimeline() || await buscarDocumentos(idURL) || []
    let timelineLimpa = timeline.map(d => {
        return({id: d?.id, idUnicoDocumento: d?.idUnicoDocumento, titulo: d?.titulo, tipo: d?.tipo, data: d?.data, participacaoProcesso: d?.participacaoProcesso, nomeResponsavel: d?.nomeResponsavel})
    })
    let dataMaior = null
    let numeroProcesso = document.querySelector('pje-descricao-processo [role="button"]')?.textContent || ''
    let despachos = timelineLimpa.filter(d=> ['despacho', 'decisao', 'sentenca'].some(c => normalizar(d?.titulo).includes(c)) && (d?.nomeSignatario)) || []
    let teorDespachos = []
    for (let despacho of despachos){
        let teor = await rota_extrairTeorDocumento(idURL, despacho?.id) || ''
        teorDespachos.push({id: despacho?.id, informacoes: despacho, teor})
        dataMaior = dataMaior > new Date(despacho?.data) ? dataMaior : despacho?.data
    }
    // ASSISTENTE
    let armazenamento = await obterArmazenamento(idg('resumoGeralLIQ1'))
    let resumoGeralLIQ1TF = armazenamento[idg('resumoGeralLIQ1')] || false
    armazenamento = await obterArmazenamento(idg('obrigacoesDeFazerLIQ1'))
    let obrigacoesDeFazerLIQ1TF = armazenamento[idg('obrigacoesDeFazerLIQ1')] || false
    armazenamento = await obterArmazenamento(idg('informacoesProcessuaisLIQ1'))
    let informacoesProcessuaisLIQ1TF = armazenamento[idg('informacoesProcessuaisLIQ1')] || false
    let assistenteEnvio = {timelineLimpa, teorDespachos, numeroProcesso}
    let assistente_resumoGeralLIQ1 = '6ae39ae8bac219ab06a6932d'
    let assistente_obrigacoesDeFazerLIQ1 = '6aecc761296544c71127842a'
    let [resumoGeralLIQ1, obrigacoesDeFazerLIQ1, informacoesProcessuaisLIQ1] = await Promise.all([
    resumoGeralLIQ1TF ? (rota_IAConsulta(assistente_resumoGeralLIQ1, JSON.stringify(assistenteEnvio)).then(r => r || 'Ocorreu um erro')) : 'Não solicitado (o checkbox não está clicado ao lado, efetue nova consulta).',
    obrigacoesDeFazerLIQ1TF ? (rota_IAConsulta(assistente_obrigacoesDeFazerLIQ1, JSON.stringify(assistenteEnvio), [], ).then(r => r || 'Ocorreu um erro')) : 'Não solicitado (o checkbox não está clicado ao lado, efetue nova consulta).',
    informacoesProcessuaisLIQ1TF ? (rota_IAConsulta('',`Utilize o buscador processual para buscar as seguintes informações no processo:
(i) o número do PIS do reclamante;
(ii) o número da CTPS do reclamante;
(iii) se a CTPS é física ou digital
(iv) por DEPÓSITO RECURSAL ou DEPÓSITO JUDICIAL vinculados à reclamada, indicando o id do documento (idUnicoDocumento), se possível.
INSTRUÇÕES IMPORTANTES:
1) Responda apenas utilzando texto, sem marcas de estilo.
2) Ao referir-se a documentos, indique o id (idUnicoDocumento), normalmente encontrado na assinatura: "Documento assinado eletronicamente por XXXXXX, em DD/MM/AAAA, às HH:MM:SS - ID AQUI"
Número do processo: ` + numeroProcesso).then(r => r || 'Ocorreu um erro')) : 'Não solicitado (o checkbox não está clicado ao lado, efetue nova consulta).'
])
    return [
        {titulo: 'Resumo Geral LIQ1', resposta: resumoGeralLIQ1, id: idg('resumoGeralLIQ1')}, 
        {titulo: 'Obrigações de fazer LIQ1', resposta: obrigacoesDeFazerLIQ1, id: idg('obrigacoesDeFazerLIQ1')}, 
        {titulo: 'Informações processuais', resposta: informacoesProcessuaisLIQ1, id: idg('informacoesProcessuaisLIQ1')}, 
    ]
    
}