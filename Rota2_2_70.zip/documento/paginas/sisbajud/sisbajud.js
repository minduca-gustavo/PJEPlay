async function sisbajudInicia(){
    //return
    let janela = confereJanela(JANELA.sisbajudCadastrarMinuta, JANELA.sisbajudOrdemJudicial)
    if (!janela) return
    if (confereJanela(JANELA.sisbajudOrdemJudicial)){
        botaoCertificar()
        return
    }
    await aguardarElemento('.uikit-actions button')
    await suspender(500)
    let botaoProtocolar = [...document.querySelectorAll('.uikit-actions button')].find(d => normalizar(d.textContent).includes('protocolar')) || null
    if (!botaoProtocolar) return
    let idBotao = idg('sisbajud', 'protolocar_e_inserirGigs')
    document.getElementById(idBotao)?.remove()
    let botao = criaBotaoLaranja({
        id: idBotao,
        ancestral: '.uikit-actions',
        texto: 'Protocolar e inserir CHIP/GIG',
        acao: () => abrirUrlSisbajud('criaGIGeCHIP')
    })
    botao.style.display = 'inline-block'

    async function abrirUrlSisbajud(parametro){
        let armazenamento = await obterArmazenamento('rotapje_ultimaOrigem')
        let ultimaOrigem = armazenamento?.rotapje_ultimaOrigem || 'https://pje.trt15.jus.br'
        if (parametro == 'criaGIGeCHIP'){
            aguardarElemento('.uikit-actions button[title="Protocolar Minuta"]')
            await suspender(300)
            clicar('.uikit-actions button[title="Protocolar Minuta"]')
        }
        let numero = [...document.querySelectorAll('.mat-card-content [class^=col-md]')].find(d => normalizar(d.textContent).includes('numero do processo'))?.querySelector('span')?.textContent.trim() || ''
        if (!numero){
            rota_avisoObrigatorio('Ocorreu um erro. Atualize a página e tente novamente.', 5)
            return
        }
        let url = ultimaOrigem + '/pje-consulta-api/api/processos/dadosbasicos/' + numero
        let dadosBasicos = await NAVEGADOR.runtime.sendMessage({
			requisicao: url,
			configuracao: {
				method: 'GET',
				credentials: 'include',
				headers: { 'Content-Type': 'application/json', 'Accept': '*/*' },
				
			}
		})
        
        if (!dadosBasicos.sucesso){
            rota_avisoObrigatorio('Ocorreu um erro. Atualize a página e tente novamente.', 5)
            return
        }
        let {dados} = dadosBasicos
        if (!dados[0]?.id){
            rota_avisoObrigatorio('Ocorreu um erro. Atualize a página e tente novamente.', 5)
            return
        }
        let execucao = Date.now()
        await armazenar({rotapje_sisbajudExecucao: execucao})
        let detalhe = {
            criaGIGeCHIP: 'detalhe',
            sisbajudCertificar: 'documento/anexar'
        }
        let urlAbrir = ultimaOrigem + '/pjekz/processo/' + dados[0]?.id + '/' + detalhe[parametro] +'?rotapje_sisbajud=' + parametro + '&rotapje_sisbajudExecucao=' + execucao
        abrirURL({url: urlAbrir})
        
    }

    async function botaoCertificar(){
        //return
        await aguardarElemento('.uikit-actions button')
        await suspender(500)
        let idBotao = idg('sisbajud', 'certificar')
        document.getElementById(idBotao)?.remove()
        
        
        let botao = criaBotaoLaranja({
            id: idBotao,
            ancestral: '.uikit-actions',
            texto: 'Certificar',
            acao: async () => {
                await armazenaTextoCertidao()
                abrirUrlSisbajud('sisbajudCertificar')
            }
        })
        botao.style.display = 'inline-block'

        async function armazenaTextoCertidao(){
            let textoProtocolo = [...document.querySelectorAll('div .row [class*="label"]')].map(d => '<p>' + d?.textContent.trim() + '</p>').join('')
            let tReus = [...document.querySelectorAll('sisbajud-table-reus tr')]
            for (let tr of tReus){
                //let texto = ''
                if(tr.classList.contains('element-row')){
                    let tds = [...tr.querySelectorAll('td')].filter(d=> d?.textContent && d?.textContent.trim() !== 'Sim' && d?.textContent.trim() !== 'Não')
                        for(let td of tds){
                        if (td.querySelector('span')){
                            let texto = td.querySelector('span')?.textContent + ' - ' + td.querySelector('a')?.textContent
                            textoProtocolo += '<p>' + texto + '</p>'
                        } else {
                            textoProtocolo += '<p>' + td.textContent.trim() + '</p>'
                        }
                    }
                }
                if(tr.classList.contains('detail-row')){
                    let mat = [...tr.querySelectorAll('mat-list-item')].filter(d=> d?.textContent).map(d => '<p>' + d?.textContent.trim() + '</p>').join('')
                    textoProtocolo += '<p>' + mat + '</p>'
                }
            }
            let chave = idg('sisbajudCertificar')
            armazenar({[chave]: textoProtocolo})
        }
    }
    //let botoes = elemento.querySelectorAll('button')
}

async function sisbajudJanelaPJEAbriu(){
    let janela = confereJanela(JANELA.detalhes, JANELA.certificar)
    if (!janela) return
    let parametros = new URLSearchParams(document.location.search);
    let sisbajud = parametros.get('rotapje_sisbajud')?.trim()
    if(!sisbajud) return
    let execucao = parametros.get('rotapje_sisbajudExecucao')
    let armazenamento = await obterArmazenamento('rotapje_sisbajudExecucao') || {}
    let execucaoArmazenada = armazenamento?.rotapje_sisbajudExecucao
    if (execucao != execucaoArmazenada) return
    mFuncoes = {
        criaGIGeCHIP,
        sisbajudCertificar
    }
    mFuncoes[sisbajud]()
    return

    async function sisbajudCertificar() {
        let chave = idg('sisbajudCertificar')
        let armazenamento = await obterArmazenamento(chave)
        if (!armazenamento?.[chave]) {
            rota_avisoObrigatorio('Ocorreu um erro. Prossiga manualmente.', 5)
            return
        }
        await aguardarElemento('.area-conteudo [contenteditable]')
        await suspender(500)
        inserirTextoNoEditor('.area-conteudo [contenteditable]', armazenamento?.[chave])
        await aguardarElemento('pje-anexar-tipo-documento input[data-placeholder="Tipo de Documento"]')
        console.log('%c[Rota PJE]%c 141 passou tipo: ' + JSON.stringify(141), LOG.info, 'color:inherit')
        await suspender (500)
        await preencherCampoComEscolhaDeOpcao('pje-anexar-tipo-documento input[data-placeholder="Tipo de Documento"]', 'Sisbajud (bloqueio)')
        console.log('%c[Rota PJE]%c 144 passou descrição: ' + JSON.stringify(144), LOG.info, 'color:inherit')
        await aguardarElemento('input[data-placeholder=Descrição]')
        await suspender (500)
        await preencher('input[data-placeholder=Descrição]', 'Sisbajud (bloqueio) - minuta')
        await removerArmazenamento([chave])
        removerArmazenamento('rotapje_sisbajudExecucao')
        return
    }

    async function criaGIGeCHIP(){
        await aguardarElemento('pje-historico button.botao-esconder-gigs')
        if (!document.querySelector('.conteudo-historico #gigs')) clicar('pje-historico button.botao-esconder-gigs')
        let usuarioArmazenado = await obterArmazenamento('rotapje_usuario') || {}
        let responsavel = usuarioArmazenado?.rotapje_usuario?.nome || null
        let salvar = responsavel ? true : false
        let fechar = responsavel ? true : false
        let gig = await inserirGigsNaTelaDeDetalhesDoProcesso({tipoAtividade: 'SISBAJUD - aguardar resposta', dias: 5, responsavel, salvar, observacao: 'Resposta SISBAJUD'})
        await aguardarElemento('simple-snack-bar')
        let sucesso = document.querySelector('simple-snack-bar')
        await aguardarElemento('pje-lista-etiquetas button[mattooltip="Incluir Chip Amarelo"]')
        await suspender(500)
        if([...document.querySelectorAll('mat-chip-list mat-chip')].find(c => normalizar(c?.textContent).includes('sisbajud')) && sucesso && gig && fechar){
            await removerArmazenamento('rotapje_sisbajudExecucao')
            //alert ('fechar')
            window.close()
        }
        clicar('pje-lista-etiquetas button[mattooltip="Incluir Chip Amarelo"]')
        await aguardarElemento('pje-inclui-etiquetas-dialogo li')
        await suspender(500)
        let sucessoChip = false
        let opcao = [...document.querySelectorAll('pje-inclui-etiquetas-dialogo li')].find(c => normalizar(c.textContent).includes('sisbajud')) || null
        let opcaoClique = opcao?.querySelector('input') || null
        if (opcao && opcaoClique) {
            clicar(opcaoClique)
            await aguardarElemento('.container-botoes button')
            let textoChip = opcao?.textContent.trim()
            let salvarChip = [...document.querySelectorAll('.container-botoes button')].find(b => normalizar(b.textContent).includes('salvar')) || null
            if (salvarChip) clicar(salvarChip)
            await aguardarElemento('mat-chip-list mat-chip[aria-label*=' + textoChip + ']')
            sucessoChip = true
        }
        //while(sucesso.isConnected){
        //    await suspender(1000)
        //}
        if (gig && fechar && sucesso?.textContent.includes('salva com sucesso') && sucessoChip){
            await removerArmazenamento('rotapje_sisbajudExecucao')
            window.close()
        }
    }
}

/*


https://pje.trt15.jus.br/pjekz/processo/id/detalhe
0000098-73.2014.5.15.0091 - {
    "sucesso": true,
    "dados": [
        {
            "id": 2449534,
            "numeroIdentificacaoJustica": 515,
            "numero": "0000098-73.2014.5.15.0091",
            "classe": "ATOrd",
            "codigoOrgaoJulgador": "091 ",
            "segredoJustica": false,
            "juizoDigital": false
        }
    ]
}
*/