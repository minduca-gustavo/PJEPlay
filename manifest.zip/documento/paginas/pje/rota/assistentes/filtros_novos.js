// ── TDs excluídos da busca de número de processo ────────────────
const ROTA_FILTROS_NOVOS_TDS_EXCLUIDOS = [
    // 'seletor-css-do-td-que-nao-deve-ser-usado',
]

// ── Contador (Etapa / Filtrando) ──────────────────────────────
//
// Chamar a cada volta de um for loop que faz requisição ao servidor.
// ancestral  → id do container onde o botão Filtrar foi criado
//              (aparece logo abaixo dele).
// etapa      → string "atual/total" (ex: '2/3'). Passe 0 (padrão) para
//              omitir a linha "Etapa" — funções com um único for loop
//              não devem mostrá-la.
// filtrando  → string "atual/total" (ex: '15/251') com o índice da
//              chamada dentro do loop atual. Se vier uma string SEM
//              "/" (ex: 'Nenhum processo encontrado.'), é tratada como
//              mensagem final — substitui o texto inteiro, sem os
//              prefixos "Etapa"/"Filtrando". É assim que o retorno
//              negativo da função de filtro chega até aqui (ver
//              criaFiltro).
function atualizar_contador(ancestral, etapa = 0, filtrando = 1) {
    let idContador = ancestral + '_contador'
    let ehMensagem = typeof filtrando === 'string' && !filtrando.includes('/')
    let texto
    if (ehMensagem) {
        texto = filtrando
    } else {
        let linhas = []
        if (etapa) linhas.push('Etapa ' + etapa)
        linhas.push('Filtrando ' + filtrando)
        texto = linhas.join(' — ')
    }

    let el = document.querySelector('#' + idContador)
    if (el) {
        el.innerText = texto
    } else {
        criaTexto({ id: idContador, texto: texto, ancestral: ancestral })
    }
}

async function filtrosNovos(ancestral) {
    document.querySelectorAll('#' + idg('filtros')).forEach(el => el.remove())
    let janela = confereJanela(
        JANELA.meuPainel,
        JANELA.painelGlobal,
        JANELA.painelGlobalTarefas,
        JANELA.painelGlobalTodos,
        JANELA.escaninho,
        JANELA.pautaAudiencias,
        JANELA.atasAudiencias,
        JANELA.gigsRelatorios,
    )
    if (!janela) {
        console.log('%c[Rota PJE]%c filtrosNovos4: ' + JSON.stringify(4), LOG.rosa, 'color:inherit')
        return
    }
    console.log('%c[Rota PJE]%c filtrosNovos4' + JSON.stringify('true'), LOG.rosa, 'color:inherit')
    criaWidgetfiltrosNovos(ancestral)
}

async function criaWidgetfiltrosNovos(ancestral) {
    let div = 'filtros'
    let divFiltros = criaDiv({
        id: idg(div),
        ancestral: ancestral
    })

    const USUARIOS_PERMITIDOS = [
        'gustavo',
        'heber',
        'ronaldo',
        'matheus',
        'guilherme'
        // acrescente aqui
    ]

    let autenticado = false
    let usuarioAtivo = null

    for (let usuario of USUARIOS_PERMITIDOS) {
        let chave = 'rota_filtroAutenticacao_' + usuario
        let armazenado = await obterArmazenamento([chave])
        let dados = armazenado?.[chave]
        if (dados?.tf && dados?.horario && (Date.now() - dados.horario) < 12 * 60 * 60 * 1000) {
            autenticado = true
            usuarioAtivo = usuario
            break
        }
    }

    if (!autenticado) {
        await obterAutenticacao(idg(div))
    } else {
        await apresentaFiltros(idg(div))
    }
    return

    // ── Autenticação ─────────────────────────────────────────────
    async function obterAutenticacao(ancestral) {
        let secao = 'senha'
        let divAutenticaNome = idg(div, secao, 'autentica')
        let divAutentica = criaDiv({
            id: divAutenticaNome,
            ancestral: ancestral
        })
        let idInputUsuario = idg(div, secao, 'input') + '_usuario'
        let idInputSenha   = idg(div, secao, 'input')

        let inputUsuario = criaInput({
            id: idInputUsuario,
            textoEmCima: 'Usuário',
            ancestral: divAutenticaNome
        })
        inputUsuario.container.style.width = '95%'
        inputUsuario.container.style.margin = '4px'
        inputUsuario.autocomplete = 'username'

        let inputSenha = criaInput({
            id: idInputSenha,
            textoEmCima: 'Senha',
            ancestral: divAutenticaNome
        })
        inputSenha.container.style.width = '95%'
        inputSenha.container.style.margin = '4px'
        inputSenha.type = 'password'
        inputSenha.autocomplete = 'new-password'

        inputUsuario.addEventListener('blur', () => {
            let usuario = inputUsuario.value.trim().toLowerCase()
            if (!usuario) return
            if (!USUARIOS_PERMITIDOS.includes(usuario)) {
                inputSenha.type = ''
                inputSenha.autocomplete = 'off'
                inputSenha.value = 'Usuário não possui permissão'
                inputSenha.disabled = true
                botao.disabled = true
            } else {
                if (inputSenha.value === 'Usuário não possui permissão') {
                    inputSenha.type = 'password'
                    inputSenha.autocomplete = 'new-password'
                    inputSenha.value = ''
                }
                inputSenha.disabled = false
                botao.disabled = false
            }
        })

        let botao = criaBotaoAzul({
            id: idg(div, secao, 'botao'),
            texto: 'Autenticar',
            acao: () => confereSenha(idInputUsuario, idInputSenha, divAutentica),
            ancestral: divAutenticaNome
        })

        async function confereSenha(idInputUsuario, idInputSenha, divRemover) {
            let usuario = document.querySelector('#' + idInputUsuario).value.trim().toLowerCase()
            let senha   = document.querySelector('#' + idInputSenha).value

            if (!USUARIOS_PERMITIDOS.includes(usuario)) return

            let chave = 'rota_filtroAutenticacao_' + usuario
            let armazenado = await obterArmazenamento([chave])
            let hashSalvo  = armazenado?.[chave]?.hash
            let hashDigitado = await _hashSenha(senha)

            if (!hashSalvo) {
                await armazenar({ [chave]: { hash: hashDigitado, tf: true, horario: Date.now() } })
                divRemover.remove()
                await apresentaFiltros(ancestral)
            } else if (hashDigitado === hashSalvo) {
                await armazenar({ [chave]: { hash: hashSalvo, tf: true, horario: Date.now() } })
                divRemover.remove()
                await apresentaFiltros(ancestral)
            } else {
                inputSenha.value = ''
                inputSenha.placeholder = 'Senha incorreta'
                setTimeout(() => inputSenha.placeholder = 'Senha', 3000)
            }
        }

        async function _hashSenha(texto) {
            let buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto))
            return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('')
        }
    }

    // ── Filtros ──────────────────────────────────────────────────
    async function apresentaFiltros(ancestral) {
        let secao = 'filtros'

        let botoes = [

            // ── 1. Lista processos por CNPJ/CPF (Id) ─────────
            {
                id: idg(secao, 'botao', 'gig_desIniLiq1'),
                texto: 'Busca os Gigs Despacho Inicial e Registrar trânsito',
                inputs: [
                    {
                        id: idg(secao, 'input', 'gig_desIniLiq1'),
                        textoEmCima: 'Ids',
                        placeholder: '1234567\n2456789',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsInput = valores[0]?.split(/\r?\n/)
                    let d = []
                    if (!idsInput.length) return 'Ids não informados.'
                    for (let idx = 0; idx < idsInput.length; idx++) {
                        atualizar_contador(ancestral, 0, (idx + 1) + '/' + idsInput.length)
                        let soNumeros = /\d+/.test(idsInput[idx])
                        if (!soNumeros){
                            d.push({
                                'Id':                       idsInput[idx],
                                'Gig Despacho Inicial':     'Id incorreto',
                                'Gig Registrar Trânsito?':  'Id incorreto',
                                
                            })
                            continue
                        }
                        
                        let gigs = await buscarGigsPorId(idsInput[idx]) || []
                        let gigDespachoInicial = gigs.some(g => normalizar(g?.tipoAtividade?.descricaoConsulta).includes('despacho inicial'))
                        let gigRegistrarTransito = gigs.some(g => normalizar(g?.tipoAtividade?.descricaoConsulta).includes('registrar transito'))
                        
                        d.push({
                            'Id':                       idsInput[idx],
                            'Gig Despacho Inicial':     gigDespachoInicial ? 'SIM' : 'NÃO',
                            'Gig Registrar Trânsito?':  gigRegistrarTransito ? 'SIM' : 'NÃO'
                        })
                        
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'peritoNoPolo'),
                texto: 'Diz se tem perito no polo - por ID.',
                inputs: [
                    {
                        id: idg(secao, 'input', 'peritoNoPolo'),
                        textoEmCima: 'Digite/cole os ids, um por linha',
                        placeholder: '1234567\n2345681\n',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsInput = valores[0]?.split(/\r?\n/)
                    if (!idsInput.length) return 'Ids não informados.'

                    let d = []
                    for (let idx = 0; idx < idsInput.length; idx++) {
                        atualizar_contador(ancestral, 0, (idx + 1) + '/' + idsInput.length)
                        let soNumeros = /\d+/.test(idsInput[idx])
                        if (!soNumeros){
                            d.push({
                                'Id':                   idsInput[idx],
                                'Tem perito':           'Id incorreto',
                                })
                            continue
                        }
                        let partes = await buscarProcesso(idsInput[idx], '/partes') || {}
                        let perito = partes?.TERCEIROS?.some(p => normalizar(p?.tipo).includes('perito')) || null
                        d.push({
                            'Id':           idsInput[idx],
                            'Tem perito':   perito ? 'SIM' : 'NÃO'
                        })
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'cnpjcpf_id'),
                texto: 'Lista processos por CNPJ/CPF - com indicação de apenas órgão público,  — por ID',
                inputs: [
                    {
                        id: idg(secao, 'input', 'cnpjcpf_id'),
                        textoEmCima: 'Nome da tarefa',
                        placeholder: 'Ex: Concluso para sentença',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsInput = valores[0]?.split(/\r?\n/)
                    if (!idsInput.length) return 'Ids não informados.'

                    let d = []
                    for (let idx = 0; idx < idsInput.length; idx++) {
                        atualizar_contador(ancestral, 0, (idx + 1) + '/' + idsInput.length)
                        let soNumeros = /\d+/.test(idsInput[idx])
                        if (!soNumeros){
                            d.push({
                                'Id':                   idsInput[idx],
                                'Documento':            'Id incorreto',
                                'Reclamada':            'Id incorreto',
                                'Reclamante':           'Id incorreto',
                                'Outras Reclamadas':    'Id incorreto',
                                'Apenas órgão público': 'Id incorreto',
                                'Todas têm advogado?':  'Id incorreto',
                                'Alguma tem advogado?': 'Id incorreto'
                            })
                            continue
                        }
                        let partes = await buscarProcesso(idsInput[idx], '/partes') || {}
                        console.log('%c[Rota PJE]%c partes: ' + JSON.stringify(partes), LOG.info, 'color:inherit', partes)
                        let autor = partes?.ATIVO[0]?.nome
                        let orgaoPublico = partes?.PASSIVO.filter(d=> d?.tipoPessoa == 'O').length == partes?.PASSIVO.length ? 'Sim' : 'Não'
                        let todasAdv = !partes?.PASSIVO.some(d => !d?.representantes && !d?.procuradoria)
                        let algumaTemAdv = partes?.PASSIVO.some(d => d?.representantes || d?.procuradoria)
                        for (let j of partes?.PASSIVO || []) {
                            let maisReclamadas = partes?.PASSIVO.length === 1 ? 'Não' : 'Sim'
                            d.push({
                                'Id':                   idsInput[idx],
                                'Documento':            j?.documento || '',
                                'Reclamada':            j?.nome,
                                'Reclamante':           autor,
                                'Outras Reclamadas':    maisReclamadas,
                                'Apenas órgão público': orgaoPublico,
                                'Todas têm advogado?':  todasAdv ? 'SIM' : 'NÃO',
                                'Alguma tem advogado?': algumaTemAdv ? 'SIM' : 'NÃO'
                            })
                        }
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'cnpjcpf_tarefa'),
                texto: 'Lista processos por CNPJ/CPF - com indicação de apenas órgão público — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'cnpjcpf_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa',
                        placeholder: 'Ex: Concluso para sentença',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeTarefa = valores[0]?.trim()
                    if (!nomeTarefa) return 'Informe o nome da tarefa.'

                    // Etapa 1/2 — coleta dos processos da tarefa
                    let tarefa = await resolverTarefa(nomeTarefa)
                    if (!tarefa) return 'Tarefa não encontrada.'
                    let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1)
                    let ids = r.ids, t = r.t
                    atualizar_contador(ancestral, '1/2', '1/' + r.paginas)
                    for (let pagina = 2; pagina <= r.paginas; pagina++) {
                        atualizar_contador(ancestral, '1/2', pagina + '/' + r.paginas)
                        let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina)
                        ids.push(...rp.ids); t.push(...rp.t)
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'

                    // Etapa 2/2 — partes de cada processo
                    let d = []
                    for (let idx = 0; idx < ids.length; idx++) {
                        atualizar_contador(ancestral, '2/2', (idx + 1) + '/' + ids.length)
                        let r2 = await buscarProcesso(ids[idx], '/partes')
                        let numero = t[idx]?.numero || ''
                        let autor  = t[idx]?.autor  || ''
                        let orgaoPublico = r2?.PASSIVO.filter(d=> d?.tipoPessoa == 'O').length == r2?.PASSIVO.length ? 'Sim' : 'Não'
                        for (let j of r2?.PASSIVO || []) {
                            let maisReclamadas = r2?.PASSIVO.length === 1 ? 'Não' : 'Sim'
                            d.push({
                                'Documento':            j?.documento || '',
                                'Processo':             numero,
                                'Reclamada':            j?.nome,
                                'Reclamante':           autor,
                                'Outras Reclamadas':    maisReclamadas,
                                'Apenas órgão público': orgaoPublico

                            })
                        }
                    }
                    return d
                }
            },

            // ── 2. Lista processos Tema 1389 (Tarefa) ─────────────
            {
                id: idg(secao, 'botao', 'tema1389_tarefa'),
                texto: 'Lista processos Tema 1389 — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'tema1389_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa',
                        placeholder: 'Ex: Concluso para sentença',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeTarefa = valores[0]?.trim()
                    if (!nomeTarefa) return 'Informe o nome da tarefa.'

                    // Etapa 1/2 — coleta dos processos da tarefa
                    let tarefa = await resolverTarefa(nomeTarefa)
                    if (!tarefa) return 'Tarefa não encontrada.'
                    let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1)
                    let ids = r.ids, t = r.t
                    atualizar_contador(ancestral, '1/2', '1/' + r.paginas)
                    for (let pagina = 2; pagina <= r.paginas; pagina++) {
                        atualizar_contador(ancestral, '1/2', pagina + '/' + r.paginas)
                        let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina)
                        ids.push(...rp.ids); t.push(...rp.t)
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'

                    // Etapa 2/2 — sobrestamento/gigs de cada processo
                    let d = []
                    for (let idx = 0; idx < ids.length; idx++) {
                        atualizar_contador(ancestral, '2/2', (idx + 1) + '/' + ids.length)
                        let sobrestamentos = await rota_fetch(location.origin + '/pje-comum-api/api/processos/id/' + ids[idx] + '/sobrestamentos') || []
                        let sobrestamento = sobrestamentos.find(s => !s.dataRevogacao)
                        let textoSobrestamento = sobrestamento?.textoFinalExternoSobrestamento || ''
                        let numero   = t[idx]?.numero  || ''
                        let autor    = t[idx]?.autor   || ''
                        let reu      = t[idx]?.reu     || ''
                        let autuacao = (new Date(t[idx]?.autuadoEm).toLocaleDateString('pt-BR')) || ''
                        let gigs = []
                        if (new Date(t[idx]?.autuadoEm) >= new Date('2025-10-20') &&
                            (textoSobrestamento?.includes('1389') || textoSobrestamento?.includes('1.389'))) {
                            gigs = await buscarGigs(numero)
                        }
                        let gig = gigs.find(gig => /GAB.*JU.*/i.test(gig?.tipoAtividade?.descricao || '')) ?? {}
                        let gigNormalizado = normalizar(gig?.tipoAtividade?.descricao)
                        let juizSimetria = gigNormalizado.split(/ju[ií]za?/i, 2)[1]?.trim().toUpperCase() || ''
                        d.push({
                            id:            ids[idx] || '',
                            processo:      numero   || '',
                            autor:         autor    || '',
                            reu:           reu      || '',
                            sobrestamento: textoSobrestamento || '',
                            autuacao:      autuacao || '',
                            juiz_simetria: juizSimetria || '',
                        })
                    }
                    return d
                }
            },

            // ── 3a. Lista número/partes/autuação/tarefa — por Tarefa ─
            {
                id: idg(secao, 'botao', 'listagem_tarefa'),
                texto: 'Lista número, partes, autuação, tarefa — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'listagem_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa (ou TODAS)',
                        placeholder: 'TODAS',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let valorTarefa = valores[0]?.trim() || 'TODAS'
                    let idsx = [], tx = []
                    let tarefas = await rota_fetch(location.origin + '/pje-comum-api/api/tarefas/ativas?presenteEmProcesso=true')
                    if (valorTarefa !== 'TODAS') {
                        tarefas = [tarefas.find(t => t.nome.toLowerCase() === valorTarefa.toLowerCase())]
                    }
                    // Único estágio de rede: para cada tarefa (etapa), percorre
                    // suas páginas (filtrando). Só se aplica quando "TODAS".
                    for (let it = 0; it < tarefas.length; it++) {
                        let tarefaNome = tarefas[it]?.nome
                        if (!tarefaNome?.toLowerCase().includes('arquiv' || 'cartas devolvidas')) {
                            let etapaTexto = tarefas.length > 1 ? (it + 1) + '/' + tarefas.length : 0
                            let tarefa = await resolverTarefa(tarefaNome)
                            if (!tarefa) continue
                            let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1)
                            atualizar_contador(ancestral, etapaTexto, '1/' + r.paginas)
                            idsx.push(...r.ids); tx.push(...r.t)
                            for (let pagina = 2; pagina <= r.paginas; pagina++) {
                                atualizar_contador(ancestral, etapaTexto, pagina + '/' + r.paginas)
                                let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina)
                                idsx.push(...rp.ids); tx.push(...rp.t)
                            }
                        }
                    }
                    if (!idsx.length) return 'Nenhum processo encontrado.'
                    let d = []
                    for (let i = 0; i < idsx.length; i++) {
                        d.push({
                            Id:         idsx[i] || '',
                            Processo:   tx[i]?.numero || '',
                            Tipo:       tx[i]?.descricaoClasseJudicial || '',
                            Reclamada:  tx[i]?.reu   || '',
                            Reclamante: tx[i]?.autor || '',
                            Autuado_em: (new Date(tx[i]?.autuadoEm).toLocaleDateString('pt-BR')) || '',
                        })
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'recebimento_execucao'),
                texto: 'Lista processos na tarefa Recebimento em fase de execução, separando entre OJs',
                inputs: [
                    //{
                    //    id: idg(secao, 'input', 'listagem_tarefa_nome'),
                    //    textoEmCima: 'ESTE INPUT ESTÁ INATIVO NESTE FILTRO',
                    //    placeholder: 'INATIVO',
                    //    tipoInput: 'criaInput',
                    //}
                ],
                funcao: async (valores, ancestral) => {
                    let valorTarefa = valores[0]?.trim() || 'TODAS'
                    let idsx = [], tx = []
                    let tarefas = await rota_fetch(location.origin + '/pje-comum-api/api/tarefas/ativas?presenteEmProcesso=true') || []
                    if (!tarefas.length) return 'Ocorreu um erro. Atualize a página e tente novamente.'
                    let tarefa = tarefas.find(d => d.nome == 'Recebimento de instância superior') || {}
                    if (!tarefa?.nome) return 'Ocorreu um erro. Atualize a página e tente novamente.'
                    let r = await buscarProcessosPorTarefa(tarefa?.nome, '&faseProcessual=EXECUCAO')
                    idsx.push(...r.ids); tx.push(...r.t)
                    if (!idsx.length) return 'Nenhum processo encontrado.'
                    let d = []
                    for (let i = 0; i < idsx.length; i++) {
                        let publicos = [
                            'municipio',
                            'empresa brasileira de correios',
                            'estado de sao paulo',
                            'recuperacao',
                            'falid'
                        ]
                        if (publicos.some(d => normalizar(tx[i]?.reu).includes(d) && !normalizar(tx[i]?.reu).includes('e outros'))){
                            defineOJ('EXE4')
                            continue
                        }
                        let url = location.origin + '/pje-comum-api/api/processos/id/' + idsx[i] +'/partes'
                        let dados = await rota_fetch(url) || {}
                        if (!dados?.PASSIVO) continue
                        if (!dados?.PASSIVO?.some(d=> d?.tipoPessoa == 'F' || d?.tipoPessoa == 'J')){
                            defineOJ('EXE4')
                            continue
                        }
                        let timeline = await buscarDocumentos(idsx[i]) || []
                        if (!timeline.length) continue
                        let acordao = timeline?.find(d=> d.tipo == 'Acórdão' && d.titulo == 'Acórdão') || {}
                        console.log('%c[Rota PJE]%c acordao: ' + JSON.stringify(acordao), LOG.info, 'color:inherit')
                        if (!acordao?.id) continue
                        let teor = await extrairHtml(idsx[i], acordao?.id) || ''
                        if (!teor) continue
                        if (normalizar(teor).includes('prescricao intercorrente')){
                            defineOJ('EXE2')
                            continue
                        }
                        defineOJ('EXE1')
                        function defineOJ(OJ){
                            d.push({
                                Id:         idsx[i] || '',
                                Processo:   tx[i]?.numero || '',
                                Tipo:       tx[i]?.descricaoClasseJudicial || '',
                                Fase:       tx[i]?.labelFaseProcessual || '',
                                Reclamada:  tx[i]?.reu   || '',
                                Reclamante: tx[i]?.autor || '',
                                Autuado_em: (new Date(tx[i]?.autuadoEm).toLocaleDateString('pt-BR')) || '',
                                OJ:         OJ
                            })
                        }
                        
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'pesquisa_timeline_id'),
                texto: 'Faz busca de termos na timeline e devolve processos que contiverem os termos - por ID.',
                inputs: [
                    {
                        id: idg(secao, 'input', 'pesquisa_timeline_id', 'tarefa'),
                        textoEmCima: 'Digite/cole os ids, um por linha.',
                        placeholder: '1234567\n9876543',
                        tipoInput: 'criaInputAnotacao',
                    },
                    {
                        id: idg(secao, 'input', 'pesquisa_timeline_id', 'movimentoOuDocumento'),
                        textoEmCima: 'Digite Movimentos, Documentos, Documentos e Anexos, ou Ambos',
                        placeholder: 'Ex: movimentos, AMBOS, Documentos, documentos e anexos',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'pesquisa_timeline_id', 'termosTimeline'),
                        textoEmCima: 'Digite os termos a buscar, separados por vírgula',
                        placeholder: 'Ex: Acordo, SENTENÇA, Ata da audiencia',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let valorIds = valores[0]?.split(/\r?\n/)
                    if (!valorIds.length) return 'Não foram encontrados ids. Verifique.'
                    let movimentoOuDocumento = normalizar(valores[1])?.trim().replace(/\s/g, '') || 'ambos'
                    console.log('%c[Rota PJE]%c valores[1]' + JSON.stringify(valores[1]), LOG.erro, 'color:inherit')
                    let termosTimeline = valores[2]?.split(',').map(d=> normalizar(d)?.trim())
                    let funcoes = {
                        ambos: 'buscarDocumentosEMovimentos',
                        documentos: 'buscarDocumentos',
                        movimentos: 'buscarMovimentos',
                        documentoseanexos: 'buscarDocumentos',
                    }
                    let mapaFuncoes = {
                        buscarDocumentosEMovimentos,
                        buscarDocumentos,
                        buscarMovimentos
                    }
                    let funcao = funcoes[movimentoOuDocumento] || null
                    if(!funcao) return 'Digite ambos, movimentos ou documentos'
                    let idsx = valorIds
                    let d = []
                    for (let i = 0; i < idsx.length; i++) {
                        atualizar_contador(ancestral, '2/2', (i + 1) + '/' + idsx.length)
                        let timeline = await mapaFuncoes[funcao](idsx[i]) || []
                        if (!timeline.length) continue
                        let encontrados = []
                        for (let valor of termosTimeline){
                            for (let documento of timeline){
                                if (normalizar(documento?.tipo).includes(valor) || normalizar(documento?.titulo).includes(valor)) encontrados.push(valor)
                                if (movimentoOuDocumento == 'documentoseanexos') {
                                    if (documento?.anexos) {
                                        if (documento?.anexos.some(d => normalizar(d?.tipo).includes(valor) || normalizar(d?.titulo).includes(valor))) encontrados.push(valor)
                                    }
                                }
                            }
                        }
                        if (encontrados.length) encontrado(encontrados.join(', '))
                        function encontrado(valor){
                            d.push({
                                Id:         idsx[i] || '',
                                encontrado: valor
                            })
                        }
                        
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'pesquisa_timeline'),
                texto: 'Faz busca de termos na timeline e devolve processos que contiverem os termos',
                inputs: [
                    {
                        id: idg(secao, 'input', 'pesquisa_timeline', 'tarefa'),
                        textoEmCima: 'Digite a tarefa',
                        placeholder: 'Ex: Prazos vencidos',
                        tipoInput: 'criaInputAnotacao',
                    },
                    {
                        id: idg(secao, 'input', 'pesquisa_timeline', 'movimentoOuDocumento'),
                        textoEmCima: 'Digite Movimento, Documento, ou Ambos',
                        placeholder: 'Ex: movimento, AMBOS, Documento',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'pesquisa_timeline', 'termosTimeline'),
                        textoEmCima: 'Digite os termos a buscar, separados por vírgula',
                        placeholder: 'Ex: Acordo, SENTENÇA, Ata da audiencia',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let valorTarefa = valores[0]?.trim()
                    console.log('%c[Rota PJE]%c valorTarefa: ' + JSON.stringify(valorTarefa), LOG.teste, 'color:inherit')
                    let movimentoOuDocumento = normalizar(valores[1])?.trim() || 'ambos'
                    console.log('%c[Rota PJE]%c movimentoOuDocumento: ' + JSON.stringify(movimentoOuDocumento), LOG.info, 'color:inherit')
                    let termosTimeline = valores[2]?.split(',').map(d=> normalizar(d)?.trim())
                    console.log('%c[Rota PJE]%c termosTimeline: ' + JSON.stringify(termosTimeline), LOG.aviso, 'color:inherit')
                    if (!valorTarefa) return 'Digite uma tarefa.'
                    let funcoes = {
                        ambos: 'buscarDocumentosEMovimentos',
                        documentos: 'buscarDocumentos',
                        movimentos: 'buscarMovimentos'
                    }
                    let mapaFuncoes = {
                        buscarDocumentosEMovimentos,
                        buscarDocumentos,
                        buscarMovimentos
                    }
                    console.log('%c[Rota PJE]%c funcoes[]: ' + JSON.stringify(funcoes[movimentoOuDocumento]), LOG.teste, 'color:inherit')
                    let funcao = funcoes[movimentoOuDocumento] || null
                    if(!funcao) return 'Digite ambos, movimentos ou documentos'
                    console.log('%c[Rota PJE]%c funcao: ' + JSON.stringify(typeof funcao), LOG.teste, 'color:inherit')
                    let idsx = [], tx = []
                    let tarefas = await rota_fetch(location.origin + '/pje-comum-api/api/tarefas/ativas?presenteEmProcesso=true') || []
                    let tarefa = tarefas.find(d => d.nome == valorTarefa) || {}
                    if (!tarefa?.nome) return 'Tarefa não encontrada.'
                    atualizar_contador(ancestral, '1/2', '...')
                    let r = await buscarProcessosPorTarefa(tarefa?.nome)
                    atualizar_contador(ancestral, '2/2', '...')
                    idsx.push(...r.ids); tx.push(...r.t)
                    if (!idsx.length) return 'Nenhum processo encontrado.'
                    let d = []
                    for (let i = 0; i < idsx.length; i++) {
                        atualizar_contador(ancestral, '2/2', (i + 1) + '/' + idsx.length)
                        let timeline = await mapaFuncoes[funcao](idsx[i]) || []
                        if (!timeline.length) continue
                        let encontrados = []
                        for (let valor of termosTimeline){
                            if (timeline.some(d => normalizar(d?.tipo).includes(valor) || normalizar(d?.titulo).includes(valor))) encontrados.push(valor)
                        }
                        if (encontrados.length) encontrado(encontrados.join(', '))
                        function encontrado(valor){
                            d.push({
                                Id:         idsx[i] || '',
                                Processo:   tx[i]?.numero || '',
                                Tipo:       tx[i]?.descricaoClasseJudicial || '',
                                Fase:       tx[i]?.labelFaseProcessual || '',
                                Reclamada:  tx[i]?.reu   || '',
                                Reclamante: tx[i]?.autor || '',
                                Autuado_em: (new Date(tx[i]?.autuadoEm).toLocaleDateString('pt-BR')) || '',
                                encontrado: valor
                            })
                        }
                        
                    }
                    return d
                }
            },
            {
                id: idg(secao, 'botao', 'sentenca_acordao'),
                texto: 'Busca textos das Sentenças e Acórdãos',
                inputs: [
                    {
                        id: idg(secao, 'input', 'sentenca_acordao'),
                        textoEmCima: 'Nome da tarefa (ou TODAS - MUITO DEMORADO)',
                        placeholder: 'TODAS',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'sentenca_acordao_quantidade'),
                        textoEmCima: 'Quantos processos devem ser buscados',
                        placeholder: 'Máximo: 50',
                        tipoInput: 'criaInput',
                    },
                ],
                funcao: async (valores, ancestral) => {
                    let valorTarefa = valores[0]?.trim() || 'TODAS'
                    let maximo = Number(valores[1]?.trim()) || 50
                    if (!maximo || maximo > 50) maximo = 50
                    if (typeof maximo !== 'number') {
                        return 'O valor informado para a quantidade de processos deve ser um número.'
                    }
                    let idsx = [], tx = []
                    let tarefas = await rota_fetch(location.origin + '/pje-comum-api/api/tarefas/ativas?presenteEmProcesso=true')
                    if (valorTarefa !== 'TODAS') {
                        tarefas = [tarefas.find(t => t.nome.toLowerCase() === valorTarefa.toLowerCase())]
                    }
                    // Único estágio de rede: para cada tarefa (etapa), percorre
                    // suas páginas (filtrando). Só se aplica quando "TODAS".
                    for (let it = 0; it < tarefas.length; it++) {
                        let tarefaNome = tarefas[it]?.nome
                        if (!tarefaNome?.toLowerCase().includes('arquiv' || 'cartas devolvidas')) {
                            let etapaTexto = tarefas.length > 1 ? (it + 1) + '/' + (tarefas.length + 1) : 0
                            let tarefa = await resolverTarefa(tarefaNome)
                            if (!tarefa) continue
                            let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1, '&faseProcessual=CONHECIMENTO')
                            atualizar_contador(ancestral, etapaTexto, '1/' + r.paginas)
                            idsx.push(...r.ids); tx.push(...r.t)
                            if (idsx.length >= maximo) break
                            for (let pagina = 2; pagina <= r.paginas; pagina++) {
                                atualizar_contador(ancestral, etapaTexto, pagina + '/' + r.paginas)
                                let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina, '&faseProcessual=CONHECIMENTO')
                                idsx.push(...rp.ids); tx.push(...rp.t)
                                if (idsx.length >= maximo) break
                            }
                        }
                    }
                    if (!idsx.length) return 'Nenhum processo encontrado.'
                    let d = []
                    for (let i = 0; i < maximo; i++) {
                        atualizar_contador(ancestral, (tarefas.length + 1) + '/' + (tarefas.length + 1), (i + 1) + '/' + maximo)
                        let id = idsx[i] || null
                        console.log('%c[Rota PJE]%c tx[i]' + JSON.stringify(tx[i]), LOG.info, 'color:inherit')
                        let numero = tx[i]?.numero || null
                        if (!id) continue
                        if (!numero) continue
                        let idsDocs = []
                        let timeline   = await buscarDocumentos(id) || []
                        let idSegundo = await buscarSegundoGrauBasicos(numero) || []
                        let dadosSegundo = []
                        if (idSegundo.length != 0){
                            dadosSegundo = await buscarSegundoGrau(idSegundo[0]?.id) || []
                            console.log('%c[Rota PJE]%c dadosSegundo 573: ' + JSON.stringify(dadosSegundo), LOG.info, 'color:inherit', dadosSegundo)
                        }
                        let timelineSegundo = dadosSegundo?.itensProcesso || []
                        let tituloRegex = /^TST\s*-\s*(Acórdão|Decisão)\b/i
                        let sentencas  = timeline
                            .filter(d => ['Sentença', 'Acórdão'].includes(d?.tipo) || tituloRegex.test(d?.titulo || ''))
                            .map(d => ({id: d?.id, data: d?.data, tipo: d?.tipo, instancia: d?.instancia})) || []
                        idsDocs.push(...sentencas)
                        let documentosInternosTexto = await Promise.all
                            (idsDocs.map(async (d) => {
                                let teor = await extrairHtml(id, d?.id) || null
                                let parser = new DOMParser();
                                let teorHtml = teor ? parser.parseFromString(teor, 'text/html') : null
                                let divs = teorHtml ? [...teorHtml.querySelectorAll('div.corpo')] : []
                                // Se não encontrou nenhuma div.corpo, tenta div.body
                                if (teorHtml && divs.length === 0) {
                                    divs = [...teorHtml.querySelectorAll('.conteudo_editor')]
                                }

                                let teorCorpo = divs
                                    .map(div => div.innerText.replace(/\n\s*\n/g, '\n').trim())
                                    .filter(texto => texto.length > 0)
                                    .join('\n\n')
                                if (!teor){
                                    let teorPDF = await rota_extrairTeorDocumento(id, d?.id) || null
                                    teorPDF = normalizarTeor(teorPDF)
                                    if (teorPDF) teorCorpo = teorPDF
                                }
                                return {idDocumento: d?.id, teor: teorCorpo, dataDocumento: d?.data, tipo: d?.tipo, instancia: d?.instancia}
                            })
                        )
                        let url = 'https://ia.jt.jus.br/chat/'

                        window.open(url, idg('filtros_novos', 'sentencas_e_acordaos_') + Date.now())
                        //let idAssistente = '6aac80f81501b0e00725a8df'
                        //let {idIA, aut} = await rota_fetch_IACriaConversa(idAssistente)
                        //let resultado = await rota_fetch_IAEnviaRequisicao(parametro, idIA, aut)
                        d.push({
                            id:         idsx[i] || '',
                            numero:     tx[i].numero || '',
                            sentencasEAcordaos: documentosInternosTexto,
                        })
                    }
                    _baixarArquivo(JSON.stringify(d, null, 2), 'sentencasEAcordaos.json', 'application/json')
                    //_baixarArquivo(JSON.stringify(d, null, 2), 'sentencasEAcordaos.txt', 'text/plain')
                    return 'O arquivo foi baixado.'
                }
            },

            // ── 3b. Lista número/partes/autuação/tarefa — por Lista ──
            {
                id: idg(secao, 'botao', 'listagem_lista'),
                texto: 'Lista número, partes, autuação, tarefa — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'listagem_lista_nums'),
                        textoEmCima: 'Números CNJ (um por linha)',
                        placeholder: '0000000-00.0000.0.00.0000',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let numerosRaw = valores[0] || ''
                    let numeros = numerosRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!numeros.length) return 'Nenhum número informado.'
                    let processos = []
                    for (let i = 0; i < numeros.length; i++) {
                        atualizar_contador(ancestral, 0, (i + 1) + '/' + numeros.length)
                        let idProcesso = await buscarIdPeloNumeroCNJ(numeros[i])
                        if (idProcesso) processos.push(idProcesso)
                    }
                    if (!processos.length) return 'Nenhum processo encontrado.'
                    let d = []
                    for (let i = 0; i < processos.length; i++) {
                        let {id, numero, descricaoClasseJudicial, autor, reu, nomeTarefa, autuadoEm} = processos[i]
                        d.push({
                            Id:         id || '',
                            Processo:   numero || '',
                            Tipo:       descricaoClasseJudicial || '',
                            Reclamada:  reu   || '',
                            Reclamante: autor || '',
                            Tarefa: nomeTarefa || '',
                            Autuado_em: (new Date(autuadoEm).toLocaleDateString('pt-BR')) || '',
                        })
                    }
                    return d
                }
            },

            // ── 4a. PJC único + Sentenças — por Tarefa ────────────
            {
                id: idg(secao, 'botao', 'termos', 'sentencasEAcordaos', 'id'),
                texto: 'Busca termos nas sentenças e acórdãos - por ID',
                inputs: [
                    {
                        id: idg(secao, 'input', 'ids', 'sentencasEAcordaos'),
                        textoEmCima: 'Digite os Ids',
                        placeholder: '1234567\n2456789',
                        tipoInput: 'criaInputAnotacao',
                    },
                    {
                        id: idg(secao, 'input', 'termos', 'sentencasEAcordaos'),
                        textoEmCima: 'Digite os termos que devem constar da sentença/acórdão, separados por vírgula.',
                        placeholder: 'Ex.: horas extras, ferias vencidas.',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsInput = valores[0]?.split(/\r?\n/)
                    let d = []
                    if (!idsInput.length) return 'Ids não informados.'
                    let termos = valores[1]?.split(',').map(d => normalizar(d).trim()) || []
                    if (!termos.length) return 'Não foram encontrados termos. Verifique.'
                    let i = 0
                    for (let id of idsInput){
                        let termosEncontrados = []
                        atualizar_contador(ancestral, 0, (i++) + '/' + idsInput.length)
                        let soNumeros = /\d+/.test(id)
                        if (!soNumeros) continue
                        let timeline = await buscarDocumentos(id) || []
                        let sentencasEAcordaos = timeline.filter(d=> ['sentenca', 'acordao', 'decisao'].some(c => normalizar(d?.titulo).includes(c) || normalizar(d?.tipo).includes(c)))
                        for (let documento of sentencasEAcordaos){
                            let texto = await rota_extrairTeorDocumento(id, documento?.id)
                            for (let termo of termos){
                                let encontrado = buscaEmTextoMalFormatado(texto, normalizar(termo).trim(), 10, 10)
                                if (!!encontrado){
                                    termosEncontrados.push(encontrado?.trechos)
                                }
                            }
                        }
                        d.push({id: id, encontrados: termosEncontrados.length ? 'SIM' : 'NÃO' ,'Termos Encontrados': termosEncontrados.join(', ')})
                    }
                    return d

                }
            },
            {
                id: idg(secao, 'botao', 'pjc_tarefa'),
                texto: 'PJC único + Sentenças — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'pjc_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa (ou TODAS)',
                        placeholder: 'TODAS',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'pjc_termo_nome'),
                        textoEmCima: 'Digite o termo que deve constar da sentença/acórdão.',
                        placeholder: 'Ex.: horas extras, ferias vencidas.',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let valorTarefa = valores[0]?.trim() || 'TODAS'
                    let termoEspecifico = valores[1]?.trim() || ''
                    let idsx = [], tx = []
                    let tarefas = await rota_fetch(location.origin + '/pje-comum-api/api/tarefas/ativas?presenteEmProcesso=true')
                    if (valorTarefa !== 'TODAS') {
                        tarefas = [tarefas.find(t => t.nome.toLowerCase() === valorTarefa.toLowerCase())]
                    }
                    // Etapa 1/2 — coleta dos processos (uma ou mais tarefas)
                    for (let tarefaAtiva of tarefas) {
                        if (!tarefaAtiva?.nome?.toLowerCase().includes('arquiv' || 'cartas devolvidas')) {
                            let tarefa = await resolverTarefa(tarefaAtiva.nome)
                            if (!tarefa) continue
                            let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1)
                            atualizar_contador(ancestral, '1/2', '1/' + r.paginas)
                            idsx.push(...r.ids); tx.push(...r.t)
                            for (let pagina = 2; pagina <= r.paginas; pagina++) {
                                atualizar_contador(ancestral, '1/2', pagina + '/' + r.paginas)
                                let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina)
                                idsx.push(...rp.ids); tx.push(...rp.t)
                            }
                        }
                    }
                    if (!idsx.length) return 'Nenhum processo encontrado.'
                    return await _executaPjcSentencas(idsx, tx, ancestral, '2/2', termoEspecifico)
                }
            },

            // ── 4b. PJC único + Sentenças — por Lista ─────────────
            {
                id: idg(secao, 'botao', 'pjc_lista'),
                texto: 'PJC único + Sentenças — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'pjc_lista_nums'),
                        textoEmCima: 'Números CNJ (um por linha)',
                        placeholder: '0000000-00.0000.0.00.0000',
                        tipoInput: 'criaInputAnotacao',
                    },
                    {
                        id: idg(secao, 'input', 'pjc_termo_nome'),
                        textoEmCima: 'Digite o termo que deve constar da sentença/acórdão.',
                        placeholder: 'Ex.: horas extras, ferias vencidas.',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let numerosRaw = valores[0] || ''
                    let termoEspecifico = valores[1]?.trim() || ''
                    let numeros = numerosRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!numeros.length) return 'Nenhum número informado.'
                    let idsx = [], tx = []
                    for (let i = 0; i < numeros.length; i++) {
                        atualizar_contador(ancestral, '1/2', (i + 1) + '/' + numeros.length)
                        let idProcesso = await buscarIdPeloNumeroCNJ(numeros[i])
                        if (idProcesso) { idsx.push(idProcesso); tx.push({ numero: numeros[i] }) }
                    }
                    if (!idsx.length) return 'Nenhum processo encontrado.'
                    return await _executaPjcSentencas(idsx, tx, ancestral, '2/2', termoEspecifico)
                }
            },

            // ── 5. Lista informações por GIG (Tarefa) ─────────────
            {
                id: idg(secao, 'botao', 'gig_tarefa'),
                texto: 'Lista informações dos processos pelo GIG — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'gig_tarefa_nome'),
                        textoEmCima: 'Nome do GIG',
                        placeholder: 'Ex: GAB JUÍZA FULANA',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeGig = valores[0]?.trim()
                    if (!nomeGig) return 'Informe o nome do GIG.'
                    let gigs = await resolverGigs(nomeGig)
                    if (!gigs.length) return 'Nenhum processo encontrado.'
                    let ids = [], t = []
                    for (let ig = 0; ig < gigs.length; ig++) {
                        let etapaTexto = gigs.length > 1 ? (ig + 1) + '/' + gigs.length : 0
                        let r = await buscarProcessosPorGigPagina(gigs[ig].id, 1)
                        atualizar_contador(ancestral, etapaTexto, '1/' + r.paginas)
                        ids.push(...r.ids); t.push(...r.t)
                        for (let pagina = 2; pagina <= r.paginas; pagina++) {
                            atualizar_contador(ancestral, etapaTexto, pagina + '/' + r.paginas)
                            let rp = await buscarProcessosPorGigPagina(gigs[ig].id, pagina)
                            ids.push(...rp.ids); t.push(...rp.t)
                        }
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    let d = []
                    for (let i = 0; i < ids.length; i++) {
                        d.push({
                            Id:         t[i]?.processo?.id          || '',
                            Processo:   t[i]?.processo?.numero      || '',
                            Reclamada:  t[i]?.processo?.nomeParteRe || '',
                            Reclamante: t[i]?.processo?.nomeParteAutora || '',
                            Tarefa:     t[i]?.processo?.nomeTarefa  || '',
                        })
                    }
                    return d
                }
            },

            // ── 6. Simetria sem GIG Gabinete — por Tarefa ─────────
            {
                id: idg(secao, 'botao', 'simetria_tarefa'),
                texto: 'Simetria sem GIG Gabinete — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'simetria_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa',
                        placeholder: 'Ex: Concluso para sentença',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeTarefa = valores[0]?.trim()
                    if (!nomeTarefa) return 'Informe o nome da tarefa.'

                    // Etapa 1/2 — coleta dos processos da tarefa
                    let tarefa = await resolverTarefa(nomeTarefa)
                    if (!tarefa) return 'Tarefa não encontrada.'
                    let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1, '&idEtiqueta=316')
                    let ids = r.ids, t = r.t
                    atualizar_contador(ancestral, '1/2', '1/' + r.paginas)
                    for (let pagina = 2; pagina <= r.paginas; pagina++) {
                        atualizar_contador(ancestral, '1/2', pagina + '/' + r.paginas)
                        let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina, '&idEtiqueta=316')
                        ids.push(...rp.ids); t.push(...rp.t)
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    return await _executaSimetriaSemGig(ids, t, ancestral, '2/2')
                }
            },

            // ── 6b. Simetria sem GIG Gabinete — por Lista ─────────
            {
                id: idg(secao, 'botao', 'simetria_lista'),
                texto: 'Simetria sem GIG Gabinete — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'simetria_lista_nums'),
                        textoEmCima: 'Números CNJ (um por linha)',
                        placeholder: '0000000-00.0000.0.00.0000',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let numerosRaw = valores[0] || ''
                    let numeros = numerosRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!numeros.length) return 'Nenhum número informado.'
                    let ids = [], t = []
                    for (let i = 0; i < numeros.length; i++) {
                        atualizar_contador(ancestral, '1/2', (i + 1) + '/' + numeros.length)
                        let idProcesso = await buscarIdPeloNumeroCNJ(numeros[i])
                        if (idProcesso) { ids.push(idProcesso); t.push({ numero: numeros[i] }) }
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    return await _executaSimetriaSemGig(ids, t, ancestral, '2/2')
                }
            },

            // ── 7a. Processos sem .pjc na tarefa — por Tarefa ─────
            {
                id: idg(secao, 'botao', 'sempjc_tarefa'),
                texto: 'Processos sem .pjc na tarefa — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'sempjc_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa',
                        placeholder: 'Ex: Concluso para sentença',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeTarefa = valores[0]?.trim()
                    if (!nomeTarefa) return 'Informe o nome da tarefa.'

                    // Etapa 1/2 — coleta dos processos da tarefa
                    let tarefa = await resolverTarefa(nomeTarefa)
                    if (!tarefa) return 'Tarefa não encontrada.'
                    let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1)
                    let ids = r.ids, t = r.t
                    atualizar_contador(ancestral, '1/2', '1/' + r.paginas)
                    for (let pagina = 2; pagina <= r.paginas; pagina++) {
                        atualizar_contador(ancestral, '1/2', pagina + '/' + r.paginas)
                        let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina)
                        ids.push(...rp.ids); t.push(...rp.t)
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    return await _executaSemPjc(ids, t, ancestral, '2/2')
                }
            },

            // ── 7b. Processos sem .pjc na tarefa — por Lista ──────
            {
                id: idg(secao, 'botao', 'sempjc_lista'),
                texto: 'Processos sem .pjc na tarefa — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'sempjc_lista_nums'),
                        textoEmCima: 'Números CNJ (um por linha)',
                        placeholder: '0000000-00.0000.0.00.0000',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let numerosRaw = valores[0] || ''
                    let numeros = numerosRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!numeros.length) return 'Nenhum número informado.'
                    let ids = [], t = []
                    for (let i = 0; i < numeros.length; i++) {
                        atualizar_contador(ancestral, '1/2', (i + 1) + '/' + numeros.length)
                        let idProcesso = await buscarIdPeloNumeroCNJ(numeros[i])
                        if (idProcesso) { ids.push(idProcesso); t.push({ numero: numeros[i] }) }
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    return await _executaSemPjc(ids, t, ancestral, '2/2')
                }
            },

            // ── 8. Recebimento do TRT — por Tarefa ────────────────
            {
                id: idg(secao, 'botao', 'recebimento_tarefa'),
                texto: 'Recebimento do TRT (Acordo / Improcedência) — por Tarefa',
                inputs: [
                    {
                        id: idg(secao, 'input', 'recebimento_tarefa_nome'),
                        textoEmCima: 'Nome da tarefa',
                        placeholder: 'Ex: Concluso para sentença',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeTarefa = valores[0]?.trim()
                    if (!nomeTarefa) return 'Informe o nome da tarefa.'

                    // Etapa 1/2 — coleta dos processos da tarefa
                    let tarefa = await resolverTarefa(nomeTarefa)
                    if (!tarefa) return 'Tarefa não encontrada.'
                    let r = await buscarProcessosPorTarefaPagina(tarefa.id, 1)
                    let ids = r.ids, t = r.t
                    atualizar_contador(ancestral, '1/2', '1/' + r.paginas)
                    for (let pagina = 2; pagina <= r.paginas; pagina++) {
                        atualizar_contador(ancestral, '1/2', pagina + '/' + r.paginas)
                        let rp = await buscarProcessosPorTarefaPagina(tarefa.id, pagina)
                        ids.push(...rp.ids); t.push(...rp.t)
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    return await _executaRecebimentoTRT(ids, t, ancestral, '2/2')
                }
            },

            // ── 8b. Recebimento do TRT — por Lista ────────────────
            {
                id: idg(secao, 'botao', 'recebimento_lista'),
                texto: 'Recebimento do TRT (Acordo / Improcedência) — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'recebimento_lista_nums'),
                        textoEmCima: 'Números CNJ (um por linha)',
                        placeholder: '0000000-00.0000.0.00.0000',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let numerosRaw = valores[0] || ''
                    let numeros = numerosRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!numeros.length) return 'Nenhum número informado.'
                    let ids = [], t = []
                    for (let i = 0; i < numeros.length; i++) {
                        atualizar_contador(ancestral, '1/2', (i + 1) + '/' + numeros.length)
                        let idProcesso = await buscarIdPeloNumeroCNJ(numeros[i])
                        if (idProcesso) { ids.push(idProcesso); t.push({ numero: numeros[i] }) }
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    return await _executaRecebimentoTRT(ids, t, ancestral, '2/2')
                }
            },

            // ── 9. Audiências até data — por Sala ─────────────────
            {
                id: idg(secao, 'botao', 'analisa_triagem'),
                texto: 'Analisa a triagem.',
                inputs: [
                    {
                        id: idg(secao, 'input', 'audiencias_sala_juiz'),
                        textoEmCima: 'Nome da sala na OJ.',
                        placeholder: 'Ex: FULANO DE TAL',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'audiencias_tipo'),
                        textoEmCima: 'Tipos de audiência a buscar, separados por vírgula. Deixe em branco para todas.',
                        placeholder: 'Ex: "inicial, una", "una", "rito sumarissimo, instrucao"',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'audiencias_maximo'),
                        textoEmCima: 'Quantos processos devem ser buscados',
                        placeholder: 'Máximo: 50. Caso não seja informado, será 50.',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let nomeSala        = valores[0]?.trim() || ''
                    let tipoAudiencia   = valores[1]?.trim() || ''
                    let maximo          = Number(valores[2]?.trim()) || ''
                    if (!nomeSala) {
                        return 'Informe o nome da sala.'
                    }
                    if (!maximo || maximo > 50) maximo = 50
                    if (typeof maximo !== 'number') {
                        return 'O valor informado para a quantidade de processos deve ser um número.'
                    }
                    let sala = await resolverSala(nomeSala)
                    if (!sala) return 'Sala não encontrada.'
                    let i = 0
                    let resultadoAudiencia = []
                    atualizar_contador(ancestral, '1 / 2', 0 + '/' + maximo)
                    for (let j = 0; j < 1000; j++){
                        if (i >= maximo) break
                        let data = acertaData()
                        let dados = await buscarProcessosNaSalaPorData(sala.id, data)
                        console.log('%c[Rota PJE]%c dados: ' + JSON.stringify(dados), LOG.teste, 'color:inherit', dados)
                        if (!dados?.t) continue
                        for (let audiencia of dados?.t){
                            console.log('%c[Rota PJE]%c audiencia: ' + JSON.stringify(audiencia), LOG.teste, 'color:inherit')
                            if(
                                tipoAudiencia.split(',').map(d => normalizar(d).toLowerCase().trim()).some(d=> (normalizar(audiencia?.tipo?.descricao.toLowerCase())).includes(d))
                                && audiencia.idProcesso
                            ){
                                i++
                                atualizar_contador(ancestral, '1 / X', i + '/' + maximo)
                                let processo = audiencia?.processo
                                console.log('%c[Rota PJE]%c processo 739: ' + JSON.stringify(processo), LOG.aviso, 'color:inherit')
                                let partes   = processo?.parteProcessual?.map(d=>{
                                    let nome = d?.nome.slice(0, 10)
                                    console.log('%c[Rota PJE]%c nome 742: ' + JSON.stringify(nome), LOG.aviso, 'color:inherit')
                                    let tipoPessoa = d?.pessoa?.tipoPessoa?.descricao
                                    console.log('%c[Rota PJE]%c tipoPessoa 742: ' + JSON.stringify(tipoPessoa), LOG.aviso, 'color:inherit')
                                    return {nome: nome, tipoPessoa: tipoPessoa}
                                })
                                let atividade = processo?.processoJT?.atividade?.nome
                                resultadoAudiencia.push({
                                    idProcesso:             audiencia?.idProcesso,
                                    nrProcesso:             audiencia?.nrProcesso,
                                    tipo:                   audiencia?.tipo?.descricao,
                                    virtual:                audiencia?.isVirtual,
                                    horario:                audiencia?.pautaAudienciaHorario?.horaInicial,
                                    classe:                 processo?.classeJudicial?.descricao,
                                    autuadoEm:              processo?.autuadoEm.slice(0, 10),
                                    apreciadoTutelaLiminar: processo?.apreciadoTutelaLiminar,
                                    apreciadoTutelaLiminar: processo?.apreciadoTutelaLiminar,
                                    partes:                 partes,
                                    atividade:              atividade
                                })
                                if (i >= maximo) break
                            }
                        }
                        function acertaData(){
                            let data = new Date()
                            data.setDate(data.getDate() + j)
                            let dado = data.toISOString().slice(0, 10)
                            return dado
                        }
                    }
                    console.log('%c[Rota PJE]%c resultadoAudiencia: ' + JSON.stringify(resultadoAudiencia), LOG.rosa, 'color:inherit')
                    if (!resultadoAudiencia.length) return 'Não foram encontradas audiências para o tipo informado.'
                    let resultadoProcesso = []
                    let k = 0
                    for (let dado of resultadoAudiencia){
                        atualizar_contador(ancestral, '2 / 2', k++ + '/' + resultadoAudiencia.length)
                    
                        let id = dado?.idProcesso
                        let timeline = await buscarDocumentos(id) || []
                        let timelineImportante = timeline
                            .filter(d => d?.tipo === 'Petição Inicial' || d?.usuarioInterno === true)
                            .map(d => {
                                let tipo = d?.tipo || '';
                                
                                if (d?.tipo === 'Petição Inicial') {
                                    return {
                                        id: d?.id || '',
                                        tipo,
                                        titulo: d?.titulo || '',
                                        anexos: d?.anexos ? d?.anexos.map(c => ({
                                            id: c?.id || '',
                                            tipo: c?.tipo || '',
                                            titulo: c?.titulo || ''
                                        })) : []
                                    };
                                }
                                
                                return { tipo };
                            });
                        let peticaoInicial = timeline.filter(d => d?.tipo === 'Petição Inicial')
                        let teorPeticaoInicial = peticaoInicial.length ? await rota_extrairTeorDocumento(id, peticaoInicial[0]?.id) : ''
                        teorPeticaoInicial = normalizarTeor(teorPeticaoInicial)
                        let peticao = {idDocumento: peticaoInicial[0]?.id || '', teor: teorPeticaoInicial}
                        let certidaoSimetria = timeline.findLast(d => d?.titulo.includes('Simetria'))
                        let tiposBusca = ['Certidão', 'Intimação', 'Despacho'];
                        let documentosInternos = timeline
                            .toReversed()
                            .filter(d => d?.usuarioInterno === true)
                            .reduce((array, item) => {
                                if (tiposBusca.includes(item?.tipo) && !array.some(d => d.tipo === item.tipo)) {
                                array.push(item);
                                }
                                return array;
                        }, [])
                        documentosInternos.push(certidaoSimetria)
                        let documentosInternosTexto = await Promise.all
                            (documentosInternos.map(async (d) => {
                                let teor = await extrairHtml(id, d?.id)
                                let parser = new DOMParser();
                                let teorHtml = parser.parseFromString(teor, 'text/html');
                                let teorCorpo = teorHtml 
                                    ? [...teorHtml.querySelectorAll('div.corpo')]
                                        .map(div => div.innerText.replace(/\n\s*\n/g, '\n').trim())
                                        .filter(texto => texto.length > 0) // Remove eventuais blocos vazios
                                        .join('\n\n') 
                                    : ''
                                return {idDocumento: d?.id, teor: teorCorpo}
                            })
                        )

                        resultadoProcesso.push({dadosAudiencia: dado, timeline: timelineImportante, teorDocumentosPrincipais: [peticao, ...documentosInternosTexto]})
                    }
                    _baixarArquivo(JSON.stringify(resultadoProcesso, null, 2), 'audiencias.txt', 'text/plain')
                    return 'O arquivo foi baixado.'

                }
            },
            // ── 9. Audiências até data — por Sala ─────────────────
            {
                id: idg(secao, 'botao', 'audiencias_sala'),
                texto: 'Listar audiências na sala até a data — por Sala',
                inputs: [
                    {
                        id: idg(secao, 'input', 'audiencias_sala_juiz'),
                        textoEmCima: 'Nome da sala / juiz',
                        placeholder: 'Ex: FULANO DE TAL - TODAS para todas',
                        tipoInput: 'criaInput',
                    },
                    {
                        id: idg(secao, 'input', 'audiencias_sala_data'),
                        textoEmCima: 'Data limite (dd/mm/aaaa)',
                        placeholder: '31/12/2024',
                        tipoInput: 'criaInput',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let juiz = valores[0]?.trim() || ''
                    let data = valores[1]?.trim() || ''
                    let dataTransformada = _dataParaJS(data)
                    if (!juiz || !data || !dataTransformada) {
                        return 'Informe o nome da sala e a data no formato dd/mm/aaaa.'
                    }
                    let hoje = new Date()
                    console.log('%c[Rota PJE]%c hoje: ' + JSON.stringify(hoje), LOG.aviso, 'color:inherit')
                    let dias = Math.ceil((dataTransformada - hoje) / (1000 * 60 * 60 * 24))
                    let salas = await resolverSala(juiz)
                    if (!salas) return 'Sala não encontrada.'
                    if(!Array.isArray(salas)) salas = [salas]
                    let ids = [], t = [], nomesSalas = []
                    let datas = listarDatasParaSala(dias + 1)
                    for (let j = 0; j < salas.length; j++) {
                        let contagemSala = (j + 1) + '/' + salas.length
                        atualizar_contador(ancestral, contagemSala, 0 )
                        for (let i = 0; i < datas.length; i++) {
                            console.log('%c[Rota PJE]%c datas[i]: ' + JSON.stringify(datas[i]), LOG.aviso, 'color:inherit')
                            console.log('%c[Rota PJE]%c datas[i].getDay(): ' + JSON.stringify((new Date(datas[i] + 'T00:00:00')).getDay()), LOG.aviso, 'color:inherit')
                            let testeData = (new Date(datas[i] + 'T00:00:00')).getDay()
                            if (testeData == 0 || testeData == 6) continue
                            atualizar_contador(ancestral, contagemSala, (i + 1) + '/' + datas.length)
                            let r = await buscarProcessosNaSalaPorData(salas[j].id, datas[i])
                            for (let dado of r.t){
                                dado.nomeSala = salas[j].nome
                            }
                            ids.push(...r.ids); t.push(...r.t)
                        }
                    }
                    if (!ids.length) return 'Nenhum processo encontrado.'
                    let d = []
                    let formatarHora = h => h ? h.slice(0, 5).replace(':', 'h') : ''
                    let formatarData = d => d ? d.slice(0, 10).split('-').reverse().join('/') : ''
                    let limiteSimet = new Date('2025-10-19')
                    for (let i in t) {
                        let horarioRaw  = t[i]?.pautaAudienciaHorario?.horaInicial || ''
                        let dataRaw     = t[i]?.data || ''
                        let autuacaoRaw = t[i]?.processo?.autuadoEm || ''
                        let autuacaoDate = new Date(autuacaoRaw.slice(0, 10))
                        let processo    = t[i]?.nrProcesso || ''
                        d.push({
                            nomeSala:          t[i]?.nomeSala,
                            id:                t[i]?.idProcesso,
                            processo:          processo,
                            horario:           formatarHora(horarioRaw),
                            data:              formatarData(dataRaw),
                            tipo:              t[i]?.tipo?.descricao,
                            poloAtivo:         t[i]?.poloAtivo?.nome,
                            poloPassivo:       t[i]?.poloPassivo?.nome,
                            autuacao:          formatarData(autuacaoRaw),
                            simetriaOuLegado:  processo === '' ? '' : autuacaoDate > limiteSimet ? 'SIMETRIA' : 'LEGADO',
                        })
                    }
                    return d.length ? d : 'Nenhum processo encontrado.'
                }
            },

            // ── 10. Audiências por ID — por Lista ─────────────────
            {
                id: idg(secao, 'botao', 'audiencias_lista'),
                texto: 'Lista audiências a partir do ID do processo — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'audiencias_lista_ids'),
                        textoEmCima: 'IDs dos processos (um por linha)',
                        placeholder: '123456',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsRaw = valores[0] || ''
                    let ids = idsRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!ids.length) return 'Nenhum ID informado.'
                    let d = []
                    for (let i = 0; i < ids.length; i++) {
                        atualizar_contador(ancestral, 0, (i + 1) + '/' + ids.length)
                        let idProcesso = ids[i]
                        let audienciasMarcadas = await buscarAudienciasMarcadas(idProcesso)
                        let dataInicio = '-', sala = '-', processo = '-', autuacao = '-', tipo = '-'
                        if (audienciasMarcadas?.dataInicio) {
                            dataInicio = new Date(audienciasMarcadas?.dataInicio).toLocaleDateString('pt-BR')
                            sala       = audienciasMarcadas?.salaFisica?.nome
                            processo   = audienciasMarcadas?.processo?.numero
                            autuacao   = new Date(audienciasMarcadas?.processo?.autuadoEm).toLocaleDateString('pt-BR')
                            tipo       = audienciasMarcadas?.tipo?.descricao
                        }
                        d.push({
                            Id:                idProcesso,
                            Processo:          processo,
                            Sala:              sala,
                            Data_da_Audiencia: dataInicio,
                            Tipo:              tipo,
                            Data_de_Autuacao:  autuacao,
                        })
                    }
                    return d.length ? d : 'Nenhuma audiência encontrada.'
                }
            },

            // ── 11. Dados do processo por ID — por Lista ──────────
            {
                id: idg(secao, 'botao', 'dadosprocesso_lista'),
                texto: 'Lista dados do processo a partir do ID — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'dadosprocesso_lista_ids'),
                        textoEmCima: 'IDs dos processos (um por linha)',
                        placeholder: '123456',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsRaw = valores[0] || ''
                    let ids = idsRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!ids.length) return 'Nenhum ID informado.'
                    let d = []
                    for (let i = 0; i < ids.length; i++) {
                        atualizar_contador(ancestral, 0, (i + 1) + '/' + ids.length)
                        let idProcesso = ids[i]
                        let dados    = await buscarProcesso(idProcesso)
                        let processo = dados?.numero || '-'
                        let autuacao = new Date(dados?.autuadoEm).toLocaleDateString('pt-BR') || '-'
                        d.push({
                            Id:              idProcesso,
                            Processo:        processo,
                            Data_de_Autuacao: autuacao,
                        })
                    }
                    return d.length ? d : 'Nenhum processo encontrado.'
                }
            },
            {
                id: idg(secao, 'botao', 'varaOrigem_lista'),
                texto: 'Vara de Origem por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'varaOrigem_lista_ids'),
                        textoEmCima: 'IDs dos processos (um por linha)',
                        placeholder: '123456',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsRaw = valores[0] || ''
                    let ids = idsRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!ids.length) return 'Nenhum ID informado.'
                    let d = []
                    for (let i = 0; i < ids.length; i++) {
                        atualizar_contador(ancestral, 0, (i + 1) + '/' + ids.length)
                        let idProcesso = ids[i]
                        let dados    = await buscarHistoricoDeslocamentos(idProcesso)
                        let origem   = dados.find(d => d?.orgaoJulgadorOrigem?.descricao.includes('Vara do Trabalho')) || {}
                        let origemNome = origem?.orgaoJulgadorOrigem?.descricao || '-'
                        let processo =   origem?.numero || '-'
                        d.push({
                            Id:              idProcesso,
                            Processo:        processo,
                            Vara_de_Origem : origemNome,
                        })
                    }
                    return d.length ? d : 'Nenhum processo encontrado.'
                }
            },

            // ── 12. Data da sentença por ID — por Lista ───────────
            {
                id: idg(secao, 'botao', 'sentenca_lista'),
                texto: 'Lista data da sentença a partir do ID do processo — por Lista',
                inputs: [
                    {
                        id: idg(secao, 'input', 'sentenca_lista_ids'),
                        textoEmCima: 'IDs dos processos (um por linha)',
                        placeholder: '123456',
                        tipoInput: 'criaInputAnotacao',
                    }
                ],
                funcao: async (valores, ancestral) => {
                    let idsRaw = valores[0] || ''
                    let ids = idsRaw.split('\n').map(s => s.trim()).filter(Boolean)
                    if (!ids.length) return 'Nenhum ID informado.'
                    let d = []
                    for (let i = 0; i < ids.length; i++) {
                        atualizar_contador(ancestral, 0, (i + 1) + '/' + ids.length)
                        let idProcesso = ids[i]
                        let documentos   = await buscarDocumentos(idProcesso)
                        let sentenca     = documentos?.find(d => d?.tipo?.toLowerCase().includes('sentença'))
                        let dataSentenca = sentenca ? new Date(sentenca.data).toLocaleDateString('pt-BR') : '-'
                        d.push({
                            id:           idProcesso,
                            Sentenca_data: dataSentenca,
                        })
                    }
                    return d.length ? d : 'Nenhuma sentença encontrada.'
                }
            },

        ] // fim de botoes[]

        // ── Renderiza cada botão ──────────────────────────────────
        let mapaFuncoes = { criaInput, criaInputAnotacao }

        let armazenamento = (await obterArmazenamento('rota_ranking_botoesFiltro')) || {}
        let ranking = armazenamento?.rota_ranking_botoesFiltro ? armazenamento?.rota_ranking_botoesFiltro : []
        let botoesOrdenados = [...botoes].sort((a, b) => {
            let ra = ranking[idg(secao, a?.id)] || { pontos: 0, ultimoUso: 0 }
            let rb = ranking[idg(secao, b?.id)] || { pontos: 0, ultimoUso: 0 }
            if (rb.pontos !== ra.pontos) return rb.pontos - ra.pontos
            return rb.ultimoUso - ra.ultimoUso
        })

        for (let botao of botoesOrdenados) {
            let divId = idg(secao, botao?.id)
            let divBotao = criaDiv({ id: divId, ancestral: ancestral })
            criaBotaoAzul({
                id: divId + '_botao',
                texto: botao?.texto || 'OK',
                ancestral: divId,
                acao: () => criaFiltro(botao?.inputs, divId, botao?.funcao, mapaFuncoes)
            })
        }
    
    }

    // ── criaFiltro ───────────────────────────────────────────────
    async function criaFiltro(inputs, ancestral, funcao, mapaFuncoes) {
        // Remove filtro anterior se já aberto
        let idConteiner = ancestral + '_filtro'
        let remover = document.querySelector('#' + idConteiner) || null
        if (remover){
            remover.remove()
            return
        }
        let divFiltro = criaDiv({ id: idConteiner, ancestral: ancestral })

        for (let input of inputs) {
            let fn = mapaFuncoes[input.tipoInput] || criaInput
            fn({
                id: input.id,
                textoEmCima: input.textoEmCima || null,
                placeholder: input.placeholder || null,
                ancestral: idConteiner
            })
        }

        criaBotaoLaranja({
            id: idConteiner + '_executar',
            texto: 'Filtrar',
            ancestral: idConteiner,
            acao: async () => {
                let raiz = document.querySelector('#' + idg('filtros'))
                let botoesTela = [...(raiz?.querySelectorAll('button') || [])]
                botoesTela.forEach(b => b.disabled = true)

                try {
                    let armazenado = (await obterArmazenamento('rota_ranking_botoesFiltro')) || {}
                    let ranking = armazenado?.rota_ranking_botoesFiltro || {}
                    let atual = ranking[ancestral] || { pontos: 0, ultimoUso: 0 }
                    atual.pontos += 1
                    atual.ultimoUso = Date.now()
                    ranking[ancestral] = atual
                    await armazenar({ rota_ranking_botoesFiltro: ranking })

                    let resultado = await funcao(inputs.map(inp => document.querySelector('#' + inp.id)?.value), idConteiner)
                    if (Array.isArray(resultado)) {
                        apresentaResultados({array: resultado, nome: 'resultado_superFiltros'})
                    } else {
                        atualizar_contador(idConteiner, 0, resultado)
                    }
                } catch (e) {
                    console.error('[Rota PJE] erro no filtro:', e)
                    atualizar_contador(idConteiner, 0, 'Ocorreu um erro. Veja o console.')
                } finally {
                    botoesTela.forEach(b => b.disabled = false)
                }
            }
        })
    }

    // ── Helpers compartilhados ────────────────────────────────────

    function _dataParaJS(str) {
        if (!str) return null
        const [d, m, a] = str.split('/')
        if (!d || !m || !a) return null
        return new Date(a, m - 1, d)
    }

    async function _executaPjcSentencas(idsx, tx, ancestral, etapa = 0, termo) {
        let d = []
        let maximo = 0
        for (let i = 0; i < idsx.length; i++) {
            atualizar_contador(ancestral, etapa, (i + 1) + '/' + idsx.length)
            let id = idsx[i]
            let calculos = await buscarCalculos(id) || {}
            let calculo = [...new Set((calculos?.resultado || []).map(d => d?.idPjeCalc))]
            if (calculo.length !== 1) continue
            let idCalculo = (calculos?.resultado.find(d => d?.idPjeCalc == calculo[0]))?.idPJeCalcImportacao || null
            if (!idCalculo) continue
            let pjc     = await rota_download(location.origin + '/pje-comum-api/api/calculos/' + idCalculo + '/pjc')
            let acordo  = await rota_buscarDocumentoHomologatorio(id) || null
            let idsDocs = []
            if (acordo) {
                idsDocs.push(acordo)
            } else {
                let timeline   = await buscarDocumentos(id) || []
                let tituloRegex = /^TST\s*-\s*(Acórdão|Decisão)\b/i
                let sentencas  = timeline
                    .filter(d => ['Sentença', 'Acórdão'].includes(d?.tipo) || tituloRegex.test(d?.titulo || ''))
                    .map(d => d?.id) || []
                idsDocs.push(...sentencas)
            }
            let encontrado = false
            let conteudos  = []
            for (let idDoc of idsDocs) {
                let conteudo    = await rota_extrairTeorDocumento(id, idDoc) || ''
                conteudo = normalizarTeor(conteudo)
                let termoEncontrado = termo.split(',').some(d => buscaEmTextoMalFormatado(conteudo, d.trim(), 0, 0)?.trechos)
                if (termoEncontrado) encontrado = true
                conteudos.push(idDoc + ': ' + conteudo)
            }
            if (pjc && encontrado) {
                maximo++
                d.push({
                    Id:       id || '',
                    Numero:   tx[i]?.numero || '',
                    PJC:      await blobParaBase64(pjc),
                    Conteudo: conteudos.join(''),
                })
            }
            if (maximo === 50) break
        }
        let json = JSON.stringify(d)
        const blob = new Blob([json], { type: 'application/json' })
        const a = document.createElement('a')
        a.href = URL.createObjectURL(blob)
        a.download = 'calculos.json'
        a.click()
        return d.map(t => ({ Id: t?.Id, Numero: t?.Numero }))
    }

    async function _executaSimetriaSemGig(ids, t, ancestral, etapa = 0) {
        let d = []
        let numeros = t.map(tt => tt.numero)
        for (let idx = 0; idx < numeros.length; idx++) {
            atualizar_contador(ancestral, etapa, (idx + 1) + '/' + numeros.length)
            let numero     = numeros[idx]
            let gigs       = await buscarGigs(numero)
            let ativos     = gigs.filter(gig => gig.statusAtividade !== 'Concluído')
            let concluidos = gigs.filter(gig => gig.statusAtividade === 'Concluído')
            let temAtivoGab = ativos.some(gig => /GAB.*JU.*/i.test(gig?.tipoAtividade?.descricao || ''))
            if (temAtivoGab) continue
            let gigConcluido = concluidos
                .find(gig => /GAB.*JU.*/i.test(gig?.tipoAtividade?.descricao || ''))
                ?.tipoAtividade?.descricao ?? 'Não foi encontrado GIG de Gabinete concluído.'
            d.push({
                processo:                numero,
                gig_concluido_encontrado: gigConcluido,
            })
        }
        return d.length ? d : 'Nenhum processo encontrado sem GIG de Gabinete ativo.'
    }

    async function _executaSemPjc(ids, t, ancestral, etapa = 0) {
        let d = []
        for (let idx = 0; idx < ids.length; idx++) {
            atualizar_contador(ancestral, etapa, (idx + 1) + '/' + ids.length)
            let calculos = await buscarCalculos(ids[idx])
            if (calculos?.totalRegistros === 0) {
                d.push({
                    processo: t[idx]?.numero || '',
                    autor:    t[idx]?.autor  || '',
                    reu:      t[idx]?.reu    || '',
                    oj:       t[idx]?.descricaoOrgaoJulgador || '',
                    tarefa:   t[idx]?.nomeTarefa || '',
                })
            }
        }
        return d.length ? d : 'Nenhum processo encontrado sem PJC.'
    }

    async function _executaRecebimentoTRT(ids, t, ancestral, etapa = 0) {
        let d = []
        for (let idx = 0; idx < ids.length; idx++) {
            atualizar_contador(ancestral, etapa, (idx + 1) + '/' + ids.length)
            let acordo_ou_improcedencia = ''
            let documentosemovimentos   = await buscarDocumentosEMovimentos(ids[idx])

            if (documentosemovimentos.some(doc => /julgado\(s\) improcedente/i.test(doc.titulo))) {
                acordo_ou_improcedencia = 'Improcedência'
            }
            if (!acordo_ou_improcedencia) {
                if (documentosemovimentos.some(doc =>
                    /acordo(?!\s*coletivo)/i.test(doc.titulo) ||
                    /acordo(?!\s*coletivo)/i.test(doc.tipo)
                )) {
                    acordo_ou_improcedencia = 'Acordo'
                }
            }
            if (!acordo_ou_improcedencia) acordo_ou_improcedencia = 'Não'

            d.push({
                processo:   t[idx]?.numero                  || '',
                autor:      t[idx]?.autor                   || '',
                reu:        t[idx]?.reu                     || '',
                oj:         t[idx]?.descricaoOrgaoJulgador  || '',
                tarefa:     t[idx]?.nomeTarefa              || '',
                encontrado: acordo_ou_improcedencia,
            })
        }
        return d.length ? d : 'Nenhum processo encontrado.'
    }
}



function arrayParaTsv(array){
    if (!array.length) return ''
    let cabecalho = Object.keys(array[0])
    let linhas = [cabecalho.join('\t')]
    for (let objeto of array) {
        linhas.push(cabecalho.map(chave => objeto[chave] ?? '').join('\t'))
    }
    return linhas.join('\n')
}

// 'application/json'
// 'text/plain'

function _baixarArquivo(conteudo, nomeArquivo, tipo){
    const blob = new Blob([conteudo], { type: tipo })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = nomeArquivo
    a.click()
}