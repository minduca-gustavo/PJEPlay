// ============================================================
// funcoes-da-planilha.js
//
// Funções-base disponíveis nos scripts das células da planilha.
// Cada célula (coluna B da planilha) contém um "script" em JS
// executado com as seguintes variáveis no escopo:
//
//   i → ID interno do processo (número)
//   t → objeto já buscado pela porta-de-entrada (pode ser null
//       quando o modo for Lista — verifique antes de usar)
//
// Funções disponíveis:
//   buscarIdPeloNumeroCNJ(i)             → dados básicos do processo (pje-consulta-api)
//   buscarCalculos(i)                 → cálculos do processo
//   buscarDocumentos(i)               → documentos da timeline (documento===true)
//   buscarDocumentosEMovimentos(i)    → toda a timeline (documentos + movimentos)
//   buscarChips(i)                    → etiquetas/chips do processo
//   buscarGigs(numProc)               → gigs do processo (recebe número, ex: '0011486-22...')
//   buscarMovimentos(i)               → movimentos da timeline (documento===false)
//   buscarProcesso(i, path)           → endpoint genérico: /pje-comum-api/api/processos/id/:i + path
//
// O script deve retornar string, número, array ou null/undefined.
// Arrays são joinados com tab. Objetos genéricos têm seus valores joinados.
//
// Exemplo de script em célula (aproveita t vindo da tarefa):
//   if(t) return t.numeroProcesso + '\t' + t.nomeTarefa
//   let base = await b(i)
//   return base?.numeroProcesso || ''
// ============================================================


// ── BUSCA DADOS BÁSICOS ───────────────────────────────────────

async function buscarIdPeloNumeroCNJ(qualquerFormatoDeNumero) {
    let numLimpo = qualquerFormatoDeNumero.replace(/[.\-]/g, '')
    if (numLimpo.length !== 20) return null
    let numero = numLimpo.replace(
        /^(\d{7})(\d{2})(\d{4})(\d{1})(\d{2})(\d{4})$/,
        '$1-$2.$3.$4.$5.$6'
    )
    let dados = (await rota_fetch(
        location.origin + '/pje-administracao-api/api/consultaprocessosadm?pagina=1&numero=' + numero
    ))?.resultado || await rota_fetch(
        location.origin + '/pje-consulta-api/api/processos/dadosbasicos/' + numero
    )
    if (Array.isArray(dados?.resultado)) return dados.resultado[0] || null
    if (Array.isArray(dados))            return dados[0] || null
    return dados || null
}

// https://pje-web-hm.trt15.jus.br/pje-comum-api/api/agrupamentotarefas/processos?numero=0010001-50.2026.5.15.0144

// Abre a tarefa mais recente do processo
async function buscarTarefaMaisRecente(idProcesso = '') {
    const id = idProcesso || _acao_idProcesso()
    if (!id) return

    const url     = `${location.origin}/pje-comum-api/api/processos/id/${id}/tarefas?maisRecente=true`
    const dados   = await rota_fetch(url)
    const tarefa  = Array.isArray(dados) ? dados[0] : dados
    const idTarefa = tarefa?.idTarefa

    if (!idTarefa) return relatar('acao_navegacao_tarefa: tarefa não encontrada', '', 'erro')

    return dados
}

// ── BUSCA CÁLCULOS ────────────────────────────────────────────

async function buscarCalculos(i) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/calculos/processo?pagina=1&tamanhoPagina=10' +
		'&ordenacaoCrescente=true&idProcesso=' + i + '&incluirCalculosHomologados=true'
	)
	if (!Array.isArray(dados)) dados = dados || []
	relatar('dados de cálculos: ' + JSON.stringify(dados), '', 'teste')
	return dados
}


// ── BUSCA DOCUMENTOS ─────────────────────────────────────────

async function buscarDocumentos(i) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + i + '/timeline?somenteDocumentosAssinados=true&buscarMovimentos=false&buscarDocumentos=true'
	) || null
	if (!dados) return null
	if (!Array.isArray(dados)) dados = dados?.conteudo || dados?.content || []
	return dados.filter(entry => entry.documento === true)
}

async function buscarMinutas(i) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + i + '/documentos/minutas'
	) || null
	return dados
}
//https://pje-web-hm.trt15.jus.br/pje-comum-api/api/processos/id/4882519/documentos/minutas

// ── BUSCA DOCUMENTOS E MOVIMENTOS ─────────────────────────────────────────

async function buscarDocumentosEMovimentos(i) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + i + '/timeline'
	)
	if (!Array.isArray(dados)) dados = dados?.conteudo || dados?.content || []
	return dados
}


// ── BUSCA ETIQUETAS/CHIPS ────────────────────────────────────

async function buscarChips(i) {
	let dados = await rota_fetch(
		location.origin + '/pje-etiquetas-api/api/processos/' + i + '/etiquetas'
	)
	if (!Array.isArray(dados)) dados = dados?.conteudo || dados?.content || []
	return dados
}

//async function rota_extrairTeorDocumento(idProcesso, idDocumento) {
//    let url = `${location.origin}/pje-comum-api/api/processos/id/${idProcesso}/documentos/id/${idDocumento}/conteudo?incluirCapa=false&incluirAssinatura=true`
//    
//    let res = await fetch(url, { credentials: 'include' })
//    if (!res.ok) throw new Error(`HTTP ${res.status}`)
//    relatar('res', res, 'teste')
//    let buf  = await res.arrayBuffer()
//    let resp = await NAVEGADOR.runtime.sendMessage({
//        tipo: 'EXTRAIR_PDF', bytes: Array.from(new Uint8Array(buf))
//    })
//	relatar('resp', resp, 'teste')
//    if (!resp.ok) throw new Error(resp.erro)
//    return resp.texto
//}

function normalizarTeor(teor) {
    return (typeof teor === 'string' && teor.startsWith('data:application/pdf')) ? 'Documento de imagem' : teor
}


async function rota_extrairTeorDocumento(idProcesso, idDocumento, pdfParaTexto = true) {
    let url = `${location.origin}/pje-comum-api/api/processos/id/${idProcesso}/documentos/id/${idDocumento}/conteudo?incluirCapa=false&incluirAssinatura=true`
    let res = await rota_fetchBruto(url, { headers: rota_cabecalhos('*/*') })
    if (!res) return null

    try {
        let contentType = res.headers.get('content-type') || ''

        if (/^(audio|video)\//.test(contentType)) {
            relatar('tipo sem teor extraível: ' + contentType, url, 'aviso')
            return null
        }

        let bytes
        if (contentType.includes('application/json')) {
            let b64 = ((await res.json())?.conteudoBase64 || '').trim()
            if (!b64) { relatar('conteudoBase64 vazio', url, 'erro'); return null }
            bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0))
        } else {
            bytes = new Uint8Array(await res.arrayBuffer())
        }

        if (_ehPdf(bytes)) {
            if (!pdfParaTexto) return await _bytesParaDataUrl(bytes, 'application/pdf')

            let texto = await _extrairPdf(Array.from(bytes), url)
            if (_temTextoUtil(texto)) return texto
            return await _bytesParaDataUrl(bytes, 'application/pdf')
        }

        let texto = _decodificarTexto(bytes)
        if (/<\s*(html|body|p|div|span|table)\b/i.test(texto)) return _htmlParaTexto(texto)
        return texto
    } catch (e) {
        relatar('erro ao extrair teor: ' + e.message, url, 'erro')
        return null
    }
}

function _ehPdf(bytes) {
    return bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46 // %PDF
}

function _temTextoUtil(texto, minimo = 50) {
    return !!texto && texto.replace(/\s/g, '').length > minimo
}

function _decodificarTexto(bytes) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes) }
    catch { return new TextDecoder('iso-8859-1').decode(bytes) }
}

function _htmlParaTexto(html) {
    let doc = new DOMParser().parseFromString(html, 'text/html')
    doc.querySelectorAll('script, style').forEach(el => el.remove())
    doc.querySelectorAll('br').forEach(el => el.replaceWith('\n'))
    doc.querySelectorAll('p, div, li, tr, h1, h2, h3, h4, h5, h6')
       .forEach(el => el.append('\n'))
    return doc.body.textContent.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim()
}

function _bytesParaDataUrl(bytes, mime) {
    return new Promise((resolve, reject) => {
        let leitor = new FileReader()
        leitor.onload  = () => resolve(leitor.result)
        leitor.onerror = () => reject(leitor.error)
        leitor.readAsDataURL(new Blob([bytes], { type: mime }))
    })
}

async function _extrairPdf(bytes, url) {
	let resp = await NAVEGADOR.runtime.sendMessage({ tipo: 'EXTRAIR_PDF', bytes })
	if (!resp?.ok) { relatar('EXTRAIR_PDF falhou: ' + (resp?.erro || 'sem resposta'), url, 'erro'); return null }
	return resp.texto
}

async function extrairHtml(idProcesso, idDocumento) {
    let url  = `${location.origin}/pje-comum-api/api/processos/id/${idProcesso}/documentos/id/${idDocumento}/html`
    let pesquisa = await rota_fetch(url).then(d=> d?.modeloDocumento) || ''
    return pesquisa
}

async function extrairTextoTeste(idProcesso, idDocumento) {
    let url = `${location.origin}/pje-comum-api/api/processos/id/${idProcesso}/documentos/id/${idDocumento}/conteudo?incluirCapa=false&incluirAssinatura=true`
    let res  = await fetch(url, { credentials: 'include' })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)

    let contentType = res.headers.get('content-type') || ''
    let bytes

    if (contentType.includes('application/pdf')) {
        bytes = Array.from(new Uint8Array(await res.arrayBuffer()))
    } else if (contentType.includes('application/json')) {
        let json   = await res.json()
        // Loga pra ver a estrutura uma vez só
        let b64    = json.conteudo ?? json.content ?? json.data ?? json
        let binStr = atob(b64.trim())
        bytes      = Array.from({ length: binStr.length }, (_, i) => binStr.charCodeAt(i))
    } else {
        // Fallback: tenta base64 puro
        let b64    = (await res.text()).trim()
        let binStr = atob(b64)
        bytes      = Array.from({ length: binStr.length }, (_, i) => binStr.charCodeAt(i))
    }

    let resp = await NAVEGADOR.runtime.sendMessage({ tipo: 'EXTRAIR_PDF', bytes })
    if (!resp.ok) throw new Error(resp.erro)
    return resp.texto
}


// ── BUSCA GIGS ───────────────────────────────────────────────
// concluida=false → gigs abertas; concluida=true → gigs concluídas
// https://pje.trt15.jus.br/pje-gigs-api/api/relatorioatividades/?&numeroProcesso=0011486-22.2023.5.15.0005


async function buscarGigs(numProc) {
	
	let dados = await rota_fetch(
		location.origin + '/pje-gigs-api/api/relatorioatividades/?&tamanhoPagina=500&numeroProcesso=' + numProc
	)
	if (!Array.isArray(dados)) dados = dados?.resultado || []
	return dados
}
async function buscarGigsPorId(id) {
	
	let dados = await rota_fetch(
		location.origin + '/pje-gigs-api/api/atividade/processo/' + id
	)
	return dados
}

async function buscarHistoricoDeslocamentos(id) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + id + '/historicodeslocamentos'
	)
	//if (Array.isArray(dados)) dados = dados[0] || {}
	return dados
}

// ── BUSCA AUDIENCIAS ─────────────────────────────────────────

async function buscarAudienciasMarcadas(id) {
	
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + id + '/audiencias?status=M'
	)
	if (Array.isArray(dados)) dados = dados[0] || {}
	return dados
}
//pje-comum-api/api/processos/id/4696341/audiencias?status=M

// ── BUSCA MOVIMENTOS ─────────────────────────────────────────

async function buscarMovimentos(i) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + i + '/timeline?somenteDocumentosAssinados=true&buscarMovimentos=true&buscarDocumentos=false'
	)
	if (!Array.isArray(dados)) dados = dados?.conteudo || dados?.content || []
	return dados.filter(entry => entry.documento === false)
}


// ── ENDPOINT GENÉRICO DE PROCESSO ────────────────────────────
// p(i)         → /pje-comum-api/api/processos/id/:i
// p(i, '/partes') → /pje-comum-api/api/processos/id/:i/partes

async function buscarProcesso(i, path = '') {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/processos/id/' + i + path
	)
	if (Array.isArray(dados)) return dados[0] || null
	return dados || null
}

async function buscarSalas(idOrgaoJulgador) {
	let dados = await rota_fetch(
		location.origin + '/pje-comum-api/api/salasaudiencias?idOrgaoJulgador=' + idOrgaoJulgador
	)
	return dados || null
}

async function buscarSalasHorariosVagos(idSala) {
	let url = location.origin + '/pje-comum-api/api/pautasaudiencias/horariosvagos?idSalaFisica=' + idSala
	let dados = await rota_fetch(
		url
	)
	return dados || null
}


// ── POOL DE CONCORRÊNCIA ──────────────────────────────────────
//
// Executa uma lista de tarefas async com no máximo `concorrencia`
// simultâneas, com retry automático e callback de progresso.
//
// Uso:
//   let resultados = await sf_pool(ids, async (id, idx, total) => {
//       return await p(id, '/partes')
//   }, { concorrencia: 5, tentativas: 2, pausaMs: 200 })

async function sf_pool(itens, fn, opcoes = {}) {
	let {
		concorrencia = 5,
		tentativas   = 2,
		pausaMs      = 100,
		onProgresso  = null,   // callback(feitos, total, item)
	} = opcoes

	let total      = itens.length
	let feitos     = 0
	let resultados = new Array(total)
	let fila       = itens.map((item, idx) => ({ item, idx }))
	let ativas     = 0
	let posicao    = 0

	async function _executar({ item, idx }) {
		let tentativa = 0
		while (true) {
			try {
				let r = await fn(item, idx, total)
				resultados[idx] = r
				break
			} catch (err) {
				tentativa++
				if (tentativa >= tentativas) {
					relatar('sf_pool erro [' + idx + ']: ' + err.message, '', 'erro')
					resultados[idx] = null
					break
				}
				await suspender(500 * tentativa)
			}
		}
		feitos++
		if (onProgresso) onProgresso(feitos, total, item)
		console.log('[SF] ' + feitos + ' / ' + total)
	}

	// Processa com pool de concorrência
	await new Promise(resolver => {
		function proxima() {
			while (ativas < concorrencia && posicao < fila.length) {
				let tarefa = fila[posicao++]
				ativas++
				suspender(pausaMs).then(() => _executar(tarefa)).then(() => {
					ativas--
					if (posicao < fila.length) {
						proxima()
					} else if (ativas === 0) {
						resolver()
					}
				})
			}
			if (fila.length === 0) resolver()
		}
		proxima()
	})

	return resultados
}
